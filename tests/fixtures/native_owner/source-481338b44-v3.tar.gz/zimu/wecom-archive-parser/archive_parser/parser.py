"""Loss-aware extraction of saved originals, independent of sender classification."""
import hashlib
import json

VERSION = "archive-content-v1"
MAX_TEXT = 2_000_000


def parse_record(record, read_media, extractor):
    parts, issues = [], list(record.get("source_issues", []))

    def issue(code, path):
        issues.append({"code": code, "path": path})

    def add(text, path, kind, metadata=None):
        if not isinstance(text, str):
            issue("INVALID_TEXT", path)
            return
        if sum(len(p["text"]) for p in parts) + len(text) + len(parts) > MAX_TEXT:
            issue("CONTENT_LIMIT", path)
            return
        parts.append({"path": path, "type": kind, "text": text, **(metadata or {})})

    if record.get("recalled"):
        return {"input_hash": record["input_hash"], "parser_version": VERSION,
                "status": "RECALLED", "content_text": "", "parts": [], "issues": []}
    expected = {e["source_path"]: e for e in record.get("expected_media", [])}
    saved = {m["media_id"]: m for m in record.get("media", [])}
    visited = set()

    def media(path, kind):
        evidence = expected.get(path)
        if evidence is None:
            issue("UNREGISTERED_MEDIA", path)
            return
        visited.add(path)
        item = saved.get(evidence["media_id"])
        if not item or item.get("download_status") != "AVAILABLE":
            issue("MEDIA_NOT_AVAILABLE", path)
            return
        try:
            content = read_media(item["id"])
            if len(content) != item.get("size_bytes") or hashlib.sha256(content).hexdigest() != item.get("content_hash"):
                issue("MEDIA_INTEGRITY_FAILED", path)
                return
            if extractor is None:
                issue("EXTRACTOR_NOT_CONFIGURED", path)
                return
            result = extractor.extract(kind, content, evidence.get("filename", ""))
            add(result["text"], path, kind, {"media_id": evidence["media_id"],
                "content_hash": item["content_hash"], "engine": result.get("engine", "")})
            for problem in result.get("issues", []):
                issue(problem["code"], path + problem.get("path", ""))
        except Exception:
            # Never include file bytes, transcripts, provider errors, paths or credentials in logs/issues.
            issue("EXTRACTION_FAILED", path)

    def decode(value, path):
        if isinstance(value, str) and value.lstrip().startswith("{"):
            try:
                value = json.loads(value)
            except (ValueError, RecursionError):
                issue("MALFORMED_EMBEDDED_JSON", path)
                return None
        return value

    def walk(kind, value, path, depth=0, metadata=None):
        if depth > 40:
            issue("NESTING_LIMIT", path)
            return
        kind = kind.removeprefix("ChatRecord").lower()
        value = decode(value, path)
        if value is None:
            issue("MISSING_CONTENT", path)
            return
        if kind == "text":
            if isinstance(value, dict) and ("content" not in value or not isinstance(value["content"], str)):
                issue("MISSING_TEXT_CONTENT", path)
                return
            add(value["content"] if isinstance(value, dict) else value, path, kind, metadata)
        elif kind in {"image", "voice", "file", "video"}:
            media(path, kind)
        elif kind in {"mixed", "chatrecord"}:
            if not isinstance(value, dict) or not isinstance(value.get("item"), list):
                issue("INVALID_CONTAINER", path)
                return
            if not value["item"]:
                issue("EMPTY_CONTAINER", path)
                return
            for index, item in enumerate(value["item"]):
                if not isinstance(item, dict):
                    issue("INVALID_ITEM", path)
                    continue
                item_path = f"{path}.item[{index}].content"
                meta = {k: item[k] for k in ("msgtime", "from_chatroom", "from") if k in item}
                walk(str(item.get("type", "")), item.get("content"), item_path, depth + 1, meta)
        elif kind in {"link", "weapp", "location", "card"}:
            if not isinstance(value, dict):
                issue("INVALID_STRUCTURED_CONTENT", path)
                return
            # Preserve all official fields; no URL fetching or inferred identity.
            add(json.dumps(value, ensure_ascii=False, sort_keys=True), path, kind, metadata)
        elif kind in {"revoke", "switch", "agree", "disagree"}:
            add(json.dumps(value, ensure_ascii=False), path, kind, metadata)
        else:
            issue("UNSUPPORTED_MESSAGE_TYPE", path)

    original = record["original"]
    kind = original.get("msgtype", "")
    walk(kind, original.get(kind), "$." + kind)
    for path in expected.keys() - visited:
        # Nested media remains visible even when an unknown container cannot be rendered.
        media(path, expected[path]["media_type"])
    return {"input_hash": record["input_hash"], "parser_version": VERSION,
            "status": "PARTIAL" if issues else "COMPLETE",
            "content_text": "\n".join(p["text"] for p in parts), "parts": parts, "issues": issues}
