#!/usr/bin/env python3
"""Fixed native connector input resolver; no tool, URL or identity from the model."""
import hmac
import json
import os
from pathlib import Path
import sqlite3
import stat
import sys
from urllib.parse import quote

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from ops.enterprise_agent.source_factory import build_original_reader,validate_original_binding
    from ops.enterprise_agent.understanding import signed_input, validate_goal_catalog
    from ops.enterprise_agent.source_goals import catalog_identity, source_goals, validate_goal_scopes, require_verified_binding
else:
    from .source_factory import build_original_reader,validate_original_binding
    from .understanding import signed_input, validate_goal_catalog
    from .source_goals import catalog_identity, source_goals, validate_goal_scopes, require_verified_binding


def read_private(path, limit=65536, *, metadata_only=False):
    if not isinstance(path, (str, Path)) or not Path(path).is_absolute():
        raise ValueError("private_input_configuration_required")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ValueError("private_input_configuration_required")
        if metadata_only:
            return b""
        raw = stream.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("private_input_configuration_required")
    return raw


def validate_reader_bindings(sources):
    """Pure reader binding shape; actual file ownership/contents stay runtime checks."""
    if not isinstance(sources, list) or len(sources) > 20:
        raise ValueError("private_input_configuration_required")
    for binding in sources:
        validate_original_binding(binding)
    if len({item["source"] for item in sources}) != len(sources):
        raise ValueError("private_input_configuration_required")


def reader_configuration(path):
    config = json.loads(read_private(path))
    if (set(config) - {"goal_scopes", "readonly_business", "source_document"} != {"version", "owner_uid", "state", "input_key_file", "sources", "goals"}
            or config["version"] != 1 or config["owner_uid"] != os.getuid()
            or not isinstance(config["sources"], list) or len(config["sources"]) > 20):
        raise ValueError("private_input_configuration_required")
    validate_reader_bindings(config["sources"])
    if 'readonly_business' in config:
        if __package__ in {None, ''}:
            from ops.enterprise_agent.readonly_queries import validate_readonly_business
        else:
            from .readonly_queries import validate_readonly_business
        validate_readonly_business(config['readonly_business'],sources={(s['source'],s['scope']) for s in config['sources']})
    if 'source_document' in config:
        if __package__ in {None, ''}:
            from ops.enterprise_agent.source_document_queries import validate_source_document
        else:
            from .source_document_queries import validate_source_document
        validate_source_document(config['source_document'],sources={(s['source'],s['scope']) for s in config['sources']})
    validate_goal_catalog(config["goals"])
    scopes = validate_goal_scopes(config["goals"], config.get("goal_scopes"))
    if scopes is not None and set(scopes) != {(s["source"], s["scope"]) for s in config["sources"]}:
        raise ValueError("private_input_configuration_required")
    key = read_private(config["input_key_file"], 512)
    if len(key) < 32:
        raise ValueError("private_input_configuration_required")
    return config, key


def resolve_input(config_path, request):
    """Verify a real outstanding host action before any owner-body read."""
    if isinstance(request, dict) and request.get("mode") == "analysis":
        return resolve_analysis(config_path, request)
    try:
        config, key = reader_configuration(config_path)
        if (set(request) - {"previous"} != {"envelope", "signature", "agent", "workspace", "channel", "origin", "content", "stage"}
                or request["stage"] not in {"dispatch", "result"}):
            raise ValueError()
        envelope = request["envelope"]
        if (not isinstance(request["signature"], str)
                or not hmac.compare_digest(request["signature"], signed_input(envelope, key))
                or any(envelope[k] != request[k] for k in ("agent", "workspace", "channel"))):
            raise ValueError()
        # The ledger is read-only; a connector cannot enqueue, admit or advance it.
        read_private(config["state"], metadata_only=True)
        with sqlite3.connect("file:" + quote(config["state"], safe="/") + "?mode=ro", uri=True) as db:
            state = json.loads(db.execute("SELECT value FROM state WHERE id=1").fetchone()[0])
        require_verified_binding(state)
        action = state["outbox"][envelope["action"]]
        candidate = state["producer"]["candidates"][envelope["candidate"]]
        content = json.loads(action["message"]["payload"]["content"])
        allowed_statuses = {"pending", "sent", "delivery_unknown"} | ({"completed"} if request["stage"] == "result" else set())
        if (action["status"] not in allowed_statuses
                or action.get("subject_type") != "proposal" or action["stage"] != "understand"
                or action["candidate"] != candidate["id"]
                or candidate["understanding"]["action"] != action["id"]
                or action["judgment_version"] != candidate["understanding"]["version"]
                or action["agent"] != envelope["agent"] or action["matter"] != envelope["channel"]
                or state["configuration"]["workspace"] != envelope["workspace"]
                or state["configuration"]["coordinator"] != envelope["agent"]
                or action["message"]["source"] != "system:enterprise-agent-1324"
                or request["origin"].get("source") != "system:enterprise-agent-1324"
                or request["origin"].get("delivery_key") != action["id"]
                or not isinstance(request["origin"].get("id"), str) or not request["origin"]["id"]
                or (action.get("remote_id") and request["origin"]["id"] != action["remote_id"])
                or content["understand_input"] != envelope or content["input_signature"] != request["signature"]
                or action["message"]["payload"]["content"] != request["content"]
                or state["producer"]["goal_catalog"] != catalog_identity(config["goals"], config.get("goal_scopes"))
                or any(c["source"] == candidate["source"]
                       and c["change"]["record"] == candidate["change"]["record"]
                       and c["change"]["sequence"] > candidate["change"]["sequence"]
                       for c in state["producer"]["candidates"].values())):
            raise ValueError()
        bindings = [s for s in config["sources"] if s["source"] == envelope["source"]
                    and s["scope"] == envelope["scope"] and s["workspace"] == envelope["workspace"]]
        if len(bindings) != 1:
            raise ValueError()
        binding = bindings[0]
        source = build_original_reader(binding,token=read_private(binding['token_file'],4096).decode().strip(),stage=request['stage'])
        grant = source.authorize(source.source, request["stage"], envelope["agent"])
        if {k: grant[k] for k in ("source", "scope", "principal", "revision")} != candidate["authority"]:
            raise ValueError()
        event = dict(source=source.source, scope=source.scope,
                     evidence=envelope["reference"], version=envelope["source_version"])
        def current_judgment():
            # Owner I/O may overlap trusted reconsideration or a new source
            # version. Recheck this action's exact judgment after the read.
            read_private(config["state"], metadata_only=True)
            with sqlite3.connect("file:" + quote(config["state"], safe="/") + "?mode=ro", uri=True) as db:
                latest = json.loads(db.execute("SELECT value FROM state WHERE id=1").fetchone()[0])
            require_verified_binding(latest)
            current = latest["producer"]["candidates"][candidate["id"]]
            pending = latest["outbox"][action["id"]]
            if (pending["status"] not in allowed_statuses
                    or pending["message"] != action["message"]
                    or current["understanding"]["action"] != action["id"]
                    or current["understanding"]["version"] != envelope["judgment_version"]
                    or current["authority"] != candidate["authority"]
                    or latest["producer"]["goal_catalog"] != catalog_identity(config["goals"], config.get("goal_scopes"))
                    or any(c["source"] == candidate["source"]
                        and c["change"]["record"] == candidate["change"]["record"]
                        and c["change"]["sequence"] > candidate["change"]["sequence"]
                        for c in latest["producer"]["candidates"].values())):
                raise ValueError()
            return latest

        if request["stage"] == "result":
            source.authorize_evidence(event, "result", envelope["agent"])
            current_judgment()
            return {"qualified": True}
        if __package__ in {None, ''}:
            from ops.enterprise_agent.source_document_queries import understanding_original
        else:
            from .source_document_queries import understanding_original
        selected_goals=source_goals(config['goals'],config.get('goal_scopes'),envelope['source'],envelope['scope'])
        original,input_digest,window=understanding_original(source,event,agent=envelope['agent'],goals=selected_goals,
            config=config.get('source_document'))
        latest = current_judgment()
        result = dict(original=original, goal_catalog=source_goals(config["goals"], config.get("goal_scopes"),
                      envelope["source"], envelope["scope"]),
                      input_hash=input_digest,input_hash_kind="source_document_window_v1" if window else "full_text_utf8_sha256")
        if window is not None:
            result.update(source_documents=[window],document_complete=False)
        previous = request.get("previous")
        if previous is not None:
            old_content = json.loads(previous["content"])
            old = old_content["understand_input"]
            if (previous["channel"] != request["channel"]
                    or not hmac.compare_digest(old_content["input_signature"], signed_input(old, key))
                    or any(old[k] != envelope[k] for k in ("source", "scope", "workspace", "agent", "channel"))):
                raise ValueError()
            prior = latest["producer"]["candidates"][old["candidate"]]
            prior_action = latest["outbox"][old["action"]]
            if (prior_action["candidate"] != prior["id"]
                    or prior_action["message"]["payload"]["content"] != previous["content"]
                    or prior_action["matter"] != request["channel"]
                    or previous["message"]["senderName"] != "system:enterprise-agent-1324"
                    or previous["message"]["metadata"]["delivery_key"] != prior_action["id"]
                    or previous["message"]["messageId"] != prior_action["remote_id"]):
                raise ValueError()
            if old["candidate"] != candidate["id"]:
                if (prior["source"] != candidate["source"] or prior["scope"] != candidate["scope"]
                        or prior["change"]["record"] != candidate["change"]["record"]
                        or prior["change"]["sequence"] >= candidate["change"]["sequence"]):
                    raise ValueError()
                result["supersedes"] = prior_action["id"]
            else:
                prior_action = latest["outbox"][old["action"]]
                receipts = [j for j in latest["producer"]["candidates"][candidate["id"]].get("judgment_history", []) if j["action"] == old["action"]
                            and j["version"] == old["judgment_version"]]
                if prior_action["status"] == "completed" and len(receipts) == 1:
                    receipt = receipts[0]
                    if (isinstance(receipt.get("native_response_key"), str) and receipt.get("result_reference")
                            and receipt.get("response_hash") and isinstance(receipt.get("result"), dict)):
                        result["settled_response"] = dict(action=old["action"], key=receipt["native_response_key"],
                            content_hash=receipt["response_hash"], reference=receipt["result_reference"])
        if len(json.dumps(result,ensure_ascii=False).encode())+1>262144:
            raise ValueError()
        return result
    except (ValueError, TypeError, KeyError, OSError, sqlite3.Error, AttributeError):
        raise ValueError("input_unavailable") from None


def resolve_analysis(config_path, request):
    """Materialize current read-only task originals for a bound lab service.

    The exact native origin and immutable action payload are the capability;
    neither a model-selected URL nor a forged source reference is accepted.
    """
    try:
        config, _ = reader_configuration(config_path)
        if (set(request) != {"mode", "content", "agent", "workspace", "channel", "origin", "stage"}
                or request["stage"] not in {"dispatch", "result"}
                or request["origin"].get("source") != "system:enterprise-agent-1324"):
            raise ValueError()

        inspection={}
        def current():
            read_private(config["state"], metadata_only=True)
            with sqlite3.connect("file:" + quote(config["state"], safe="/") + "?mode=ro", uri=True) as db:
                state = json.loads(db.execute("SELECT value FROM state WHERE id=1").fetchone()[0])
            require_verified_binding(state)
            action = state["outbox"][request["origin"]["delivery_key"]]
            matter = state["matters"][action["matter"]]
            statuses = {"pending", "sent", "delivery_unknown"} | ({"completed"} if request["stage"] == "result" else set())
            if (action["status"] not in statuses or action["stage"] not in {"main", "assistant"}
                    or action.get("subject_type") == "proposal" or action["agent"] != request["agent"]
                    or state["configuration"]["workspace"] != request["workspace"]
                    or action["matter"] != request["channel"] or matter["revision"] != action["revision"]
                    or action.get("run_id", matter.get("current_run_id")) != matter.get("current_run_id")
                    or action["message"]["source"] != request["origin"]["source"]
                    or action["message"]["payload"]["content"] != request["content"]
                    or action["message"]["metadata"]["delivery_key"] != action["id"]
                    or not isinstance(request["origin"].get("id"), str) or not request["origin"]["id"]
                    or action.get("remote_id") and action["remote_id"] != request["origin"]["id"]):
                raise ValueError()
            latest = {}
            for event in matter["evidence"]:
                key = (event["source"], event["record"])
                if key not in latest or event["sequence"] > latest[key]["sequence"]:
                    latest[key] = event
            if not latest or len(latest) > 20:
                raise ValueError()
            inspection.update(state=state,action=action)
            return matter, list(latest.values())

        matter, events = current()
        originals, grants, source_clients = [], [], {}
        for event in events:
            bindings = [s for s in config["sources"] if s["source"] == event["source"]
                        and s["scope"] == event["scope"] and s["workspace"] == request["workspace"]]
            if len(bindings) != 1:
                raise ValueError()
            binding = bindings[0]
            source = build_original_reader(binding,token=read_private(binding['token_file'],4096).decode().strip(),stage=request['stage'])
            source_clients[event["source"]]=source
            grant = source.authorize_evidence(event, request["stage"], request["agent"])
            if {k: grant[k] for k in ("principal", "revision", "scope")} != {
                    k: matter["authorities"][event["source"]][k] for k in ("principal", "revision", "scope")}:
                raise ValueError()
            grants.append((source, event, grant))
            if request["stage"] == "dispatch" and "source_document_input" not in inspection["action"]:
                originals.append(dict(source.read_original(event, agent=request["agent"]),
                    source=event["source"], record=event["record"], business_at=event["business_at"],
                    sequence=event["sequence"]))
        if len(json.dumps(originals, ensure_ascii=False).encode()) > 32768:
            raise ValueError()
        if __package__ in {None, ''}:
            from ops.enterprise_agent.readonly_queries import private_business_context
        else:
            from .readonly_queries import private_business_context
        business=private_business_context(config.get('readonly_business'),inspection['state'],inspection['action'])
        if __package__ in {None, ''}:
            from ops.enterprise_agent.source_document_queries import private_source_context
        else:
            from .source_document_queries import private_source_context
        document=private_source_context(config.get('source_document'),inspection['state'],inspection['action'],sources=source_clients,stage=request['stage'])
        if document:
            tools=business.get('readonly_tools',[])+document.pop('readonly_tools')
            business.update(document,readonly_tools=tools,readonly_query_contract=dict(
                decision='readonly_query',tool='one authorized name from readonly_tools',
                arguments="JSON object matching that tool's inputSchema"))
            originals=[dict(reference=d['reference'],version=d['version'],
                content=''.join(p['content'] for p in d['segments'] if p['stream']=='text'),coverage=d['coverage'],
                complete=False) for d in business['source_documents']]

        if current() != (matter, events):
            raise ValueError()
        for source, event, grant in grants:
            if source.authorize_evidence(event, request["stage"], request["agent"]) != grant:
                raise ValueError()
        result={"qualified": True} if request["stage"] == "result" else {"originals": originals,**business}
        if len(json.dumps(result,ensure_ascii=False).encode())+1 > 262144:
            raise ValueError()
        return result
    except (ValueError, TypeError, KeyError, OSError, sqlite3.Error, AttributeError):
        raise ValueError("input_unavailable") from None


def main():
    try:
        if len(sys.argv) != 2:
            raise ValueError()
        raw = sys.stdin.buffer.read(32769)
        if len(raw) > 32768:
            raise ValueError()
        result = resolve_input(sys.argv[1], json.loads(raw))
        print(json.dumps(result, ensure_ascii=False))
        return 0
    except (ValueError, OSError):
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
