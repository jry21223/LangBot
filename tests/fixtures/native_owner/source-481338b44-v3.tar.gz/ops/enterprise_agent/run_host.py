"""Explicit observation-only host. No schedule, service installation or authority."""
import argparse
from dataclasses import replace
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
from threading import Event
import time

from .host import Host, Limits
from .dingtalk_projection import SavedApproval
from .wechat_projection import SavedWechat
from .openagents import OpenAgents
from .producer import Producer, ExactGoalRule
from .rechecks import Rechecks, Rule
from .source_http import ReadOnlyGd
from .source_factory import (validate_source_binding,build_source,reader_identity,validate_reader_separation,source_flavor)
from .workflow import Workflow
from .input_reader import reader_configuration, read_private, validate_reader_bindings
from .understanding import Understanding, validate_goal_catalog
from .source_goals import validate_goal_scopes, is_observation_goal
from .readonly_queries import ReadonlyQueries, ReadonlyDispatcher, validate_readonly_business
from .source_document_queries import SourceDocumentQueries, validate_source_document


def private_json(path, *, with_digest=False):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "r", encoding="utf-8", newline="") as stream:
        info = os.fstat(stream.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ValueError("private_configuration_required")
        raw = stream.read(65537)
    if len(raw) > 65536:
        raise ValueError("invalid_host_configuration")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("invalid_host_configuration")
    return (value, sha256(raw.encode()).hexdigest()) if with_digest else value


def validate_credential_reference(name):
    if not isinstance(name, str) or not re.fullmatch(r"[A-Z][A-Z0-9_]{0,100}", name):
        raise ValueError("credential_reference_required")


def credential(name):
    validate_credential_reference(name)
    return os.environ.get(name, "")


def runtime_grant(config, *, timeout, expected_digest):
    """Consume #1323's existing effective authority; never substitute a flag."""
    _, digest = private_json(config["connector_config"], with_digest=True)
    if digest != expected_digest:
        raise ValueError("configuration_drift")
    script = Path(__file__).resolve().parents[1] / "openagents" / "host-preflight.cjs"
    result = subprocess.run(["node", str(script), config["connector_config"], config["workspace"],
                             config["workspace_endpoint"], expected_digest, config["coordinator"], *config["assistants"]],
                            env={"PATH": os.environ.get("PATH", "")}, stdin=subprocess.DEVNULL,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=timeout)
    if result.returncode != 0:
        raise ValueError("runtime_authority_unavailable")


class SourceGoalRule:
    """Retain personal-source admission without lending it another source's GD owner."""
    def __init__(self, personal, exact):
        self.personal, self.exact = frozenset(personal), exact

    def __call__(self, candidate):
        key = (candidate["source"], candidate["scope"])
        if key in self.personal:
            return None
        if self.exact is None or key not in self.exact.allowed_owners:
            raise ValueError("source_unavailable")
        return self.exact(candidate)

    def requalify(self, candidate, decision):
        key = (candidate["source"], candidate["scope"])
        if self.exact is None or key not in self.exact.allowed_owners:
            raise ValueError("source_unavailable")
        return self.exact.requalify(candidate, decision)


def validate_source_admission(config, reader_config=None):
    """Pure source/catalog qualification shared by startup and staged migration.

    This validates bindings only: no credentials, state, source reads, model or
    runtime authority are acquired. Those current checks still belong to startup.
    """
    items = config.get("sources")
    if not isinstance(items, list) or not 1 <= len(items) <= 20:
        raise ValueError("invalid_source_configuration")
    for item in items:
        if (not isinstance(item, dict)
                or set(item) - {"kind", "admission_mode", "native_ingress"} != {"endpoint", "source", "scope", "principal", "token_env", "goal_assignee_ids"}
                or item.get("kind", "wecom") not in {"wecom", "dingtalk", "personal-wechat"}
                or item.get('admission_mode', 'exact_gd') not in {'exact_gd', 'readonly_observation'}
                or item.get('admission_mode') == 'readonly_observation' and item.get('kind', 'wecom') != 'wecom'
                or item.get("kind") == "dingtalk" and item["source"] not in {"dingtalk-expenses", "dingtalk-payments"}):
            raise ValueError("invalid_source_configuration")
        validate_credential_reference(item["token_env"])
        if not isinstance(item["endpoint"], str):
            raise ValueError("invalid_read_endpoint")
        validate_source_binding(item,workspace=config['workspace'])
    if len({item["source"] for item in items}) != len(items):
        raise ValueError("unique_sources_required")
    validate_readonly_business(config.get('readonly_business'),agents=config.get('assistants'),
                              sources={(item['source'],item['scope']) for item in items})
    validate_source_document(config.get('source_document'),agents=config.get('assistants'),
        sources={(item['source'],item['scope']) for item in items
                 if item.get('kind','wecom')=='wecom' or source_flavor(item)=='native_wechat'})
    personal = {(item["source"], item["scope"]) for item in items if item.get("kind") == "personal-wechat"}
    observation = {(item['source'], item['scope']) for item in items
                   if item.get('admission_mode') == 'readonly_observation'}
    if observation and config.get('understanding', {}).get('enabled') is not True:
        raise ValueError('source_observation_understanding_required')
    source_only = personal | observation
    if any(item["goal_assignee_ids"] != [] for item in items if (item['source'],item['scope']) in source_only):
        raise ValueError("invalid_goal_configuration")
    owners = {(item["source"], item["scope"]): item["goal_assignee_ids"] for item in items
              if (item['source'],item['scope']) not in source_only}
    gd = config.get("gd")
    text_only_lab = (gd is None and not owners
                     and config.get("rechecks", {"enabled": False}) == {"enabled": False})
    if not text_only_lab and (not isinstance(gd, dict) or set(gd) != {"endpoint", "token_env"}):
        raise ValueError("invalid_goal_configuration")
    if gd is not None:
        validate_credential_reference(gd["token_env"])
        if not isinstance(gd["endpoint"], str):
            raise ValueError("invalid_read_endpoint")
        ReadOnlyGd(gd["endpoint"], "static-validation-placeholder-not-a-real-token")
    if owners:
        # Constructor validation is pure and preserves ExactGoalRule's owner
        # vocabulary; it does not call the supplied GD reader.
        ExactGoalRule(None, version=config["rule_version"], allowed_owners=owners)
    if reader_config is not None:
        if reader_config.get('source_document') != config.get('source_document'):
            raise ValueError('source_document_reader_binding_mismatch')
        if reader_config.get('readonly_business') != config.get('readonly_business'):
            raise ValueError('readonly_business_reader_binding_mismatch')
        validate_reader_bindings(reader_config["sources"])
        validate_goal_catalog(reader_config["goals"])
        configured_sources = [{**{k: item[k] for k in ("source", "scope", "workspace", "principal", "endpoint")},
            **({'flavor':'native_wechat'} if item.get('flavor')=='native_wechat' else {})} for item in reader_config['sources']]
        actual_sources = [reader_identity(item,workspace=config['workspace']) for item in items]
        if sorted(configured_sources, key=lambda s: s["source"]) != sorted(actual_sources, key=lambda s: s["source"]):
            raise ValueError("input_reader_binding_mismatch")
        for item in items:
            binding=next(b for b in reader_config['sources'] if b['source']==item['source'])
            validate_reader_separation(item,binding)
        scoped_goals = validate_goal_scopes(reader_config["goals"], reader_config.get("goal_scopes"))
        if scoped_goals is None:
            if observation or len(items) != 1 or any(("gd_code" in goal) != (items[0].get("kind") != "personal-wechat")
                                      for goal in reader_config["goals"]):
                raise ValueError("invalid_source_goal_catalog")
        elif (set(scoped_goals) != {(item["source"], item["scope"]) for item in items}
                or any(scoped_goals[(item["source"], item["scope"])]["require_gd"]
                       != ((item['source'],item['scope']) not in source_only) for item in items)):
            raise ValueError("invalid_source_goal_catalog")
        for source, scope in observation:
            selected = scoped_goals[(source,scope)]['goal_ids']
            goals = [g for g in reader_config['goals'] if g['id'] in selected]
            if len(goals) != 1 or not is_observation_goal(goals[0],source,scope):
                raise ValueError('invalid_source_observation_goal')
    return source_only, owners, text_only_lab


def open_host(config):
    required = {"version", "enabled", "mode", "owner_uid", "state", "workspace", "workspace_endpoint",
                "workspace_token_env", "coordinator", "assistants", "connector_config", "rule_version",
                "model_version", "sources", "gd", "limits"}
    if (set(config) - {"rechecks", "understanding", "readonly_business", "source_document"} != required or config["version"] != 1 or config["enabled"] is not True
            or config["mode"] != "observe" or config["owner_uid"] != os.getuid()
            or not isinstance(config["assistants"], list) or not 1 <= len(config["assistants"]) <= 20
            or len(set(config["assistants"])) != len(config["assistants"])
            or config["coordinator"] in config["assistants"]
            or any(not isinstance(v, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,100}", v)
                   for v in [config["workspace"], config["coordinator"], *config["assistants"]])
            or not isinstance(config["sources"], list) or not 1 <= len(config["sources"]) <= 20):
        raise ValueError("invalid_host_configuration")
    limits = Limits(**config["limits"])
    state = Path(config["state"])
    parent = state.parent
    if (not state.is_absolute() or parent.is_symlink() or not parent.is_dir()
            or parent.stat().st_uid != os.getuid() or parent.stat().st_mode & 0o077):
        raise ValueError("private_state_directory_required")
    connector, connector_digest = private_json(config["connector_config"], with_digest=True)
    if validate_source_document(config.get('source_document')):
        validate_source_document(config['source_document'],private_root=connector.get('stateRoot',''))
    if validate_readonly_business(config.get('readonly_business')):
        if not isinstance(connector.get('stateRoot'),str):
            raise ValueError('readonly_business_private_root_mismatch')
        validate_readonly_business(config['readonly_business'],private_root=connector['stateRoot'])
    if (connector.get("workspace") != config["workspace"]
            or connector.get("endpoint") != config["workspace_endpoint"]
            or connector.get("model") != config["model_version"]):
        raise ValueError("runtime_configuration_mismatch")
    sources = []
    projectors = {}
    personal, owners, text_only_lab = validate_source_admission(config)
    semantic_preflight=config.get('understanding',{'enabled':False})
    if isinstance(semantic_preflight,dict) and semantic_preflight.get('enabled') is True:
        preflight_reader,_=reader_configuration(semantic_preflight['reader_config'])
        validate_source_admission(config,preflight_reader)
    for item in config["sources"]:
        kind = item.get("kind", "wecom")
        if kind == "dingtalk":
            projectors[item["source"]] = SavedApproval()
        if kind == "personal-wechat":
            if source_flavor(item)=='native_wechat':
                from .wechat_native_projection import SavedNativeWechat
                projectors[item['source']]=SavedNativeWechat()
            else:
                projectors[item["source"]] = SavedWechat()
        sources.append(build_source(item,workspace=config['workspace'],token=credential(item['token_env'])))
    by_source = {source.source: source for source in sources}
    if len(by_source) != len(sources):
        raise ValueError("unique_sources_required")

    def authorize(source, stage, agent=None):
        if source not in by_source:
            raise ValueError("source_unavailable")
        return by_source[source].authorize(source, stage, agent)

    def authorize_evidence(event, stage, agent=None):
        if event["source"] not in by_source:
            raise ValueError("source_unavailable")
        return by_source[event["source"]].authorize_evidence(event, stage, agent)

    gd = config["gd"]
    reader = None if text_only_lab else ReadOnlyGd(gd["endpoint"], credential(gd["token_env"]))
    native = OpenAgents(config["workspace_endpoint"], config["workspace"], credential(config["workspace_token_env"]))
    app = Workflow(state, workspace=config["workspace"], coordinator=config["coordinator"],
                   assistants=config["assistants"], authorize=authorize, authorize_evidence=authorize_evidence)
    try:
        producer = Producer(app, rule_version=config["rule_version"], model_version=config["model_version"], projectors=projectors)
        binding = sha256(json.dumps([config, connector], sort_keys=True).encode()).hexdigest()
        with app._transaction() as data:
            if data["producer"].setdefault("host_binding", binding) != binding:
                raise ValueError("configuration_drift")
        exact_goal_rule = (None if not owners else
                          ExactGoalRule(reader, version=config["rule_version"], allowed_owners=owners,
                                        project=producer.project))
        admission_rule = SourceGoalRule(personal, exact_goal_rule)
        semantic = config.get("understanding", {"enabled": False})
        if (not isinstance(semantic, dict) or type(semantic.get("enabled")) is not bool
                or set(semantic) != ({"enabled", "reader_config", "reviewers"} if semantic["enabled"] else {"enabled"})):
            raise ValueError("invalid_understanding_configuration")
        understanding = None
        if semantic["enabled"]:
            input_config, input_key = reader_configuration(semantic["reader_config"])
            goal_scopes = input_config.get("goal_scopes")
            validate_source_admission(config, input_config)
            expected_reader = str(Path(__file__).resolve().with_name("input_reader.py"))
            if (input_config["state"] != str(state)
                    or connector.get("originalReader") != dict(executable=expected_reader, config=semantic["reader_config"])):
                raise ValueError("input_reader_binding_mismatch")
            input_digest = sha256(read_private(semantic["reader_config"]) + input_key).hexdigest()

            def qualify_input():
                _, current_key = reader_configuration(semantic["reader_config"])
                if sha256(read_private(semantic["reader_config"]) + current_key).hexdigest() != input_digest:
                    raise ValueError("input_configuration_drift")

            understanding = Understanding(producer, sources=by_source, goals=input_config["goals"],
                input_key=input_key, reviewers=semantic["reviewers"], exact_goal_rule=admission_rule,
                qualify_input=qualify_input, project=producer.project, goal_scopes=goal_scopes, source_document=config.get("source_document"))
        checks = config.get("rechecks", {"enabled": False})
        if (not isinstance(checks, dict) or type(checks.get("enabled")) is not bool
                or set(checks) != ({"enabled", "rules"} if checks["enabled"] else {"enabled"})):
            raise ValueError("invalid_check_configuration")
        rechecks = None
        if checks["enabled"]:
            if not isinstance(checks["rules"], list) or not 1 <= len(checks["rules"]) <= 20:
                raise ValueError("invalid_check_configuration")
            rechecks = Rechecks(app, reader=reader, rules=[Rule(**value) for value in checks["rules"]], allowed_owners=owners)
        host = Host(producer, sources=sources, workspace=native,
                    admit=admission_rule,
                    rechecks=rechecks, understanding=understanding)
        business=(ReadonlyQueries(app,config['readonly_business'])
            if validate_readonly_business(config.get('readonly_business')) else None)
        if validate_source_document(config.get('source_document')):
            documents=SourceDocumentQueries(app,config['source_document'],sources=by_source)
            ReadonlyDispatcher(app,business=business,documents=documents)
        host.runtime_digest = connector_digest
        return host, limits
    except BaseException:
        app.close()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, type=Path)
    parser.add_argument("--serve", action="store_true", help="Repeat bounded steps until SIGINT/SIGTERM")
    parser.add_argument("--interval", type=int, default=30)
    args = parser.parse_args()
    stopped = Event()
    host = None
    try:
        config = private_json(args.config)
        if config.get("version") != 1 or type(config.get("enabled")) is not bool:
            raise ValueError("invalid_host_configuration")
        if config["enabled"] is False:
            print(json.dumps({"status": "disabled"}))
            return 0
        if not 1 <= args.interval <= 3600:
            raise ValueError("invalid_host_interval")
        host, limits = open_host(config)
        for signum in (signal.SIGTERM, signal.SIGINT):
            signal.signal(signum, lambda *_: stopped.set())
        while not stopped.is_set():
            started = time.monotonic()
            runtime_grant(config, timeout=limits.seconds, expected_digest=host.runtime_digest)
            remaining = limits.seconds - (time.monotonic() - started)
            if remaining <= 0:
                raise ValueError("host_budget_expired")
            report = host.step(now=datetime.now(timezone.utc).isoformat(), limits=replace(limits, seconds=remaining))
            print(json.dumps(report), flush=True)
            if not args.serve:
                break
            stopped.wait(args.interval)
        return 0
    except (OSError, ValueError, TypeError, KeyError, subprocess.SubprocessError):
        print(json.dumps({"status": "host_unavailable"}), flush=True)
        return 1
    finally:
        if host is not None:
            host.close()
            host.workflow.close()


if __name__ == "__main__":
    raise SystemExit(main())
