"""Source-owner document reads in the existing outbox; no business credential."""

from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import re
import time

from .readonly_private import read_record, write_record
from .readonly_queries import read_bound_proposal
from .source_documents import _manifest, manifest_sha256
from .workflow import action_identity, identity

TOOL = "source_document.read_chunk"
DEFINITION = dict(
    name=TOOL,
    description="Read one current source document chunk; partial coverage is not full reading.",
    inputSchema=dict(
        type="object",
        additionalProperties=False,
        required=["reference", "stream", "index"],
        properties=dict(
            reference=dict(type="string"),
            stream=dict(type="string", enum=["text", "parts"]),
            index=dict(type="integer", minimum=0),
        ),
    ),
    annotations=dict(readOnlyHint=True),
)


def validate_source_document(config, *, agents=None, sources=None, private_root=None):
    if config is None or config == {"enabled": False}:
        return False
    if (
        not isinstance(config, dict)
        or set(config)
        != {"enabled", "private_root", "agents", "sources", "max_queries", "max_bytes"}
        or config["enabled"] is not True
        or not isinstance(config["private_root"], str)
        or not Path(config["private_root"]).is_absolute()
        or "\x00" in config["private_root"]
        or not isinstance(config["agents"], list)
        or not 1 <= len(config["agents"]) <= 20
        or any(
            not isinstance(a, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", a)
            for a in config["agents"]
        )
        or len(set(config["agents"])) != len(config["agents"])
        or not isinstance(config["sources"], list)
        or not 1 <= len(config["sources"]) <= 20
        or any(
            not isinstance(s, dict)
            or set(s) != {"source", "scope"}
            or any(
                not isinstance(s[k], str)
                or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,200}", s[k])
                for k in ("source", "scope")
            )
            for s in config["sources"]
        )
        or len({(s["source"], s["scope"]) for s in config["sources"]})
        != len(config["sources"])
        or type(config["max_queries"]) is not int
        or not 1 <= config["max_queries"] <= 8192
        or type(config["max_bytes"]) is not int
        or not 8192 <= config["max_bytes"] <= 64_000_000
    ):
        raise ValueError("source_document_configuration_invalid")
    if agents is not None and not set(config["agents"]) <= set(agents):
        raise ValueError("source_document_agent_denied")
    if sources is not None and not {
        (s["source"], s["scope"]) for s in config["sources"]
    } <= set(sources):
        raise ValueError("source_document_scope_denied")
    if private_root is not None and config["private_root"] != private_root:
        raise ValueError("source_document_private_root_mismatch")
    return True


def _receipt(root, descriptor):
    if (
        not isinstance(descriptor, dict)
        or set(descriptor) != {"key", "sha256"}
        or not isinstance(descriptor["sha256"], str)
        or not re.fullmatch(r"[a-f0-9]{64}", descriptor["sha256"])
    ):
        raise ValueError("source_document_receipt_invalid")
    return read_record(
        root, "readonly-results", descriptor["key"], expected_hash=descriptor["sha256"]
    )[0]


def _events(matter):
    latest = {}
    for event in matter["evidence"]:
        key = (event["source"], event["scope"], event["record"])
        if key not in latest or latest[key]["sequence"] < event["sequence"]:
            latest[key] = event
    result = list(latest.values())
    if len({e["evidence"] for e in result}) != len(result):
        raise ValueError("source_document_reference_ambiguous")
    return result


def _source_at_stage(source, stage):
    """Bind only a trusted execution purpose, never one supplied by a proposal."""
    if stage not in {"dispatch", "result"}:
        raise ValueError("source_document_stage_invalid")
    bind = getattr(source, "at_stage", None)
    return bind(stage) if callable(bind) else source


def _checked_manifest(manifest):
    if not isinstance(manifest, dict):
        raise ValueError("source_document_manifest_invalid")
    return _manifest(
        manifest,
        dict(evidence=manifest.get("reference"), version=manifest.get("version")),
    )


def _zero_window(manifest):
    _checked_manifest(manifest)
    return dict(
        reference=manifest["reference"],
        version=manifest["version"],
        parser_version=manifest["parser_version"],
        result_sha256=manifest["result_sha256"],
        manifest_sha256=manifest_sha256(manifest),
        manifest=manifest,
        segments=[],
        coverage={
            s: dict(
                complete=False,
                bytes=0,
                chunks=0,
                total_bytes=m["bytes"],
                total_chunks=m["chunks"],
                sha256=m["sha256"],
            )
            for s, m in manifest["streams"].items()
        },
        complete=False,
    )


def _matching_run(candidate, action):
    return (
        candidate["matter"] == action["matter"]
        and candidate["revision"] == action["revision"]
        and candidate.get("run_id") == action.get("run_id")
    )


def _documents(config, state, action):
    descriptor = action["source_document_input"]
    original = state["outbox"][descriptor["key"]]
    receipt = _receipt(config["private_root"], descriptor)
    if (
        not _matching_run(original, action)
        or original["agent"] != action["agent"]
        or original.get("source_document_input") != descriptor
        or receipt.get("input_action") != original["id"]
        or receipt.get("manifests") != action["source_document_manifests"]
    ):
        raise ValueError("source_document_input_changed")
    return receipt["documents"]


def _query_receipt(config, state, query, action):
    if (
        query["stage"] != "source_read"
        or query["status"] != "completed"
        or not _matching_run(query, action)
        or query["agent"] != action["agent"]
        or query.get("source_document_manifests") != action["source_document_manifests"]
    ):
        raise ValueError("source_document_receipt_changed")
    receipt = _receipt(
        config["private_root"], dict(key=query["id"], sha256=query["receipt_sha256"])
    )
    if (
        receipt.get("query_key") != query["id"]
        or receipt.get("parent_action") != query["parent_action"]
        or receipt.get("proposal_ref") != query["proposal_ref"]
        or receipt.get("requested_by") != action["agent"]
        or receipt.get("manifests") != action["source_document_manifests"]
        or receipt.get("execution_subject") != query["execution_subject"]
    ):
        raise ValueError("source_document_receipt_changed")
    return receipt


def coverage(config, state, action, *, acknowledge=False):
    """Owner readiness, verified transport and acknowledged model delivery differ."""
    documents = _documents(config, state, action)
    pages = {
        d["reference"]: {
            stream: {} for stream in _checked_manifest(d["manifest"])["streams"]
        }
        for d in documents
    }
    for document in documents:
        for page in document["segments"]:
            if page["stream"] not in pages[document["reference"]]:
                raise ValueError("source_document_stream_invalid")
            pages[document["reference"]][page["stream"]][page["index"]] = page
    for query in state["outbox"].values():
        if (
            query["stage"] == "source_read"
            and query["status"] == "completed"
            and _matching_run(query, action)
        ):
            receipt = _query_receipt(config, state, query, action)
            page = receipt["chunk"]
            if (
                page["reference"] not in pages
                or page["stream"] not in pages[page["reference"]]
            ):
                raise ValueError("source_document_stream_invalid")
            target = pages[page["reference"]][page["stream"]]
            if (
                page["index"] in target
                and target[page["index"]]["sha256"] != page["sha256"]
            ):
                raise ValueError("source_document_chunk_conflict")
            target[page["index"]] = page
    matter = state["matters"][action["matter"]]
    delivery_binding = identity(
        action["revision"], action.get("run_id"), action["source_document_manifests"]
    )
    delivered = (
        deepcopy(matter.get("source_document_delivery", {}))
        if matter.get("source_document_delivery_binding") == delivery_binding
        else {}
    )
    if acknowledge:
        # Authenticated assistant output proves its current private input was accepted.
        for document in documents:
            for page in document["segments"]:
                delivered.setdefault(document["reference"], {}).setdefault(
                    page["stream"], {}
                )[str(page["index"])] = page["sha256"]
        if "source_document_receipt" in action:
            query = state["outbox"][action["source_document_receipt"]["key"]]
            receipt = _query_receipt(config, state, query, action)
            if query["receipt_sha256"] != action["source_document_receipt"]["sha256"]:
                raise ValueError("source_document_receipt_changed")
            page = receipt["chunk"]
            delivered.setdefault(page["reference"], {}).setdefault(page["stream"], {})[
                str(page["index"])
            ] = page["sha256"]
    result = {}
    for document in documents:
        ref = document["reference"]
        streams = {}
        for stream, metadata in document["manifest"]["streams"].items():
            found = pages[ref][stream]
            full = set(found) == set(range(metadata["chunks"]))
            if full:
                wire = b"".join(
                    found[index]["content"].encode()
                    for index in range(metadata["chunks"])
                )
                if (
                    len(wire) != metadata["bytes"]
                    or sha256(wire).hexdigest() != metadata["sha256"]
                ):
                    raise ValueError("source_document_stream_hash_invalid")
                if stream == "parts" and not isinstance(json.loads(wire), list):
                    raise ValueError("source_document_parts_invalid")
            accepted = {
                int(index)
                for index, digest in delivered.get(ref, {}).get(stream, {}).items()
                if int(index) in found and found[int(index)]["sha256"] == digest
            }
            streams[stream] = dict(
                owner=dict(complete=True, **metadata),
                transmitted=dict(
                    complete=full,
                    chunks=len(found),
                    bytes=sum(p["bytes"] for p in found.values()),
                ),
                delivered=dict(
                    complete=full and accepted == set(range(metadata["chunks"])),
                    chunks=len(accepted),
                    bytes=sum(found[index]["bytes"] for index in accepted),
                ),
            )
        result[ref] = dict(
            manifest_sha256=document["manifest_sha256"],
            streams=streams,
            complete=all(s["delivered"]["complete"] for s in streams.values()),
        )
    return result, delivered


class SourceDocumentQueries:
    def __init__(self, workflow, config, *, sources):
        validate_source_document(
            config,
            agents=workflow.assistants,
            sources={(s.source, s.scope) for s in sources.values()},
        )
        self.workflow, self.config, self.sources = workflow, deepcopy(config), sources
        self.root = config["private_root"]
        self.scopes = {(s["source"], s["scope"]) for s in config["sources"]}

    def _authorize(self, matter, action, stage):
        agent_allowed = (
            action["agent"] in self.config["agents"]
            or action["stage"] == "main"
            and action["agent"] == self.workflow.coordinator
        )
        if (
            not agent_allowed
            or not self.workflow._execution_current(matter, action)
            or not {(e["source"], e["scope"]) for e in matter["evidence"]}
            <= self.scopes
        ):
            raise ValueError("source_document_denied")
        self.workflow._authorize_matter(matter, stage, action["agent"])

    def _fresh(self, matter, action):
        self._authorize(matter, action, "result")
        for event in _events(matter):
            source = _source_at_stage(self.sources[event["source"]], "result")
            if (
                source.read_manifest(event, agent=action["agent"])
                != action["source_document_manifests"][event["evidence"]]
            ):
                raise ValueError("source_document_manifest_changed")
        self._authorize(matter, action, "result")

    def can_prepare(self, action, matter):
        return (
            action["stage"] == "assistant"
            and action["agent"] in self.config["agents"]
            or action["stage"] == "main"
            and action["agent"] == self.workflow.coordinator
        ) and {(e["source"], e["scope"]) for e in matter["evidence"]} <= self.scopes

    def prepare_task(self, action, matter):
        if not self.can_prepare(action, matter):
            return False
        self._authorize(matter, action, "dispatch")
        if "source_document_input" in action:
            self._fresh(matter, action)
            _documents(self.config, self.workflow._read(), action)
            return True
        documents = []
        manifests = {}
        for event in _events(matter):
            source = _source_at_stage(self.sources[event["source"]], "dispatch")
            if not documents:
                window = source.read_window(event, agent=action["agent"])
            else:
                window = _zero_window(
                    source.read_manifest(event, agent=action["agent"])
                )
            _checked_manifest(window["manifest"])
            manifests[event["evidence"]] = window["manifest"]
            documents.append(window)
        self._authorize(matter, action, "dispatch")
        receipt = dict(
            input_action=action["id"], manifests=manifests, documents=documents
        )
        digest = write_record(self.root, "readonly-results", action["id"], receipt)
        with self.workflow._transaction() as state:
            stored = state["outbox"][action["id"]]
            if stored != action or not self.workflow._execution_current(
                state["matters"][matter["id"]], stored
            ):
                raise ValueError("source_document_stale")
            stored.update(
                source_document_manifests=manifests,
                source_document_input=dict(key=action["id"], sha256=digest),
            )
        return True

    def _parent(self, reply):
        parent = next(
            (
                a
                for a in self.workflow._read()["outbox"].values()
                if a.get("remote_id") == reply.get("metadata", {}).get("in_reply_to")
            ),
            None,
        )
        if (
            parent is None
            or parent["stage"] != "assistant"
            or parent["status"] != "sent"
            or reply.get("source") != "openagents:" + parent["agent"]
            or reply.get("target") != "channel/" + parent["matter"]
            or reply.get("type") != "workspace.message.posted"
            or reply.get("metadata", {}).get("status_kind") != "completed"
        ):
            return None
        return parent

    def receive(self, reply):
        parent = self._parent(reply)
        if parent is None:
            return False
        content = json.loads(reply["payload"]["content"])
        if (
            set(content) != {"decision", "query_ref"}
            or content["decision"] != "readonly_query"
        ):
            raise ValueError("source_document_query_invalid")
        query = read_bound_proposal(
            self.root, self.workflow.workspace, parent, content["query_ref"]
        )
        if query["tool"] != TOOL:
            return False
        matter = self.workflow._read()["matters"][parent["matter"]]
        self._fresh(matter, parent)
        arguments = query["arguments"]
        if (
            set(arguments) != {"reference", "stream", "index"}
            or arguments["reference"] not in parent["source_document_manifests"]
            or arguments["stream"]
            not in parent["source_document_manifests"][arguments["reference"]][
                "streams"
            ]
            or type(arguments["index"]) is not int
            or not 0
            <= arguments["index"]
            < parent["source_document_manifests"][arguments["reference"]]["streams"][
                arguments["stream"]
            ]["chunks"]
        ):
            raise ValueError("source_document_arguments_invalid")
        event = next(
            e for e in _events(matter) if e["evidence"] == arguments["reference"]
        )
        key = action_identity(parent["id"], "source_read", identity(query))
        with self.workflow._transaction() as state:
            if state["outbox"][
                parent["id"]
            ] != parent or not self.workflow._execution_current(
                state["matters"][matter["id"]], parent
            ):
                raise ValueError("source_document_stale")
            previous = [
                a
                for a in state["outbox"].values()
                if a["stage"] == "source_read" and _matching_run(a, parent)
            ]
            wire_bytes = sum(
                _query_receipt(self.config, state, a, parent)["chunk"]["bytes"]
                for a in previous
                if a["status"] == "completed"
            )
            wire_bytes += sum(
                p["bytes"]
                for d in _documents(self.config, state, parent)
                for p in d["segments"]
            )
            if (
                len(previous) >= self.config["max_queries"]
                or wire_bytes
                + parent["source_document_manifests"][arguments["reference"]][
                    "chunk_bytes"
                ]
                > self.config["max_bytes"]
            ):
                self.final_status(
                    state, state["outbox"][parent["id"]], state["matters"][matter["id"]]
                )
                state["outbox"][parent["id"]]["status"] = "completed"
                state["matters"][matter["id"]].update(
                    status="read_only_incomplete",
                    source_document_failure="budget_exhausted",
                )
                return True
            report, delivered = coverage(self.config, state, parent, acknowledge=True)
            state["matters"][matter["id"]].update(
                source_document_delivery=delivered,
                source_document_coverage=report,
                source_document_delivery_binding=identity(
                    parent["revision"],
                    parent.get("run_id"),
                    parent["source_document_manifests"],
                ),
            )
            state["outbox"][parent["id"]]["status"] = "completed"
            state["outbox"][key] = dict(
                id=key,
                matter=matter["id"],
                revision=parent["revision"],
                agent=parent["agent"],
                stage="source_read",
                status="pending",
                parent_action=parent["id"],
                proposal_ref=content["query_ref"],
                source_document_manifests=parent["source_document_manifests"],
                source_document_input=parent["source_document_input"],
                requested_by=parent["agent"],
                execution_subject="source:" + self.sources[event["source"]].principal,
                **({k: parent[k] for k in ("run_id", "trigger") if k in parent}),
            )
            state["matters"][matter["id"]]["status"] = "awaiting_source_read"
        return True

    def _current(self, key):
        state = self.workflow._read()
        action = state["outbox"][key]
        matter = state["matters"][action["matter"]]
        self._fresh(matter, action)
        parent = state["outbox"][action["parent_action"]]
        if (
            parent["status"] != "completed"
            or parent["stage"] != "assistant"
            or not _matching_run(parent, action)
        ):
            raise ValueError("source_document_stale")
        return state, action, matter, parent

    def _complete(self, key):
        state, action, matter, _ = self._current(key)
        receipt, digest = read_record(self.root, "readonly-results", key)
        # Reuse exactly the same validation as recovery/private reader.
        check = dict(action, status="completed", receipt_sha256=digest)
        _query_receipt(self.config, state, check, action)
        continuation = action_identity(key, "source_continuation")
        with self.workflow._transaction() as current:
            if current["outbox"][key] != action or not self.workflow._execution_current(
                current["matters"][matter["id"]], action
            ):
                raise ValueError("source_document_stale")
            current["outbox"][key].update(status="completed", receipt_sha256=digest)
            current["outbox"].setdefault(
                continuation,
                dict(
                    id=continuation,
                    matter=matter["id"],
                    revision=action["revision"],
                    agent=action["agent"],
                    stage="assistant",
                    status="pending",
                    source_document_manifests=action["source_document_manifests"],
                    source_document_input=action["source_document_input"],
                    source_document_receipt=dict(key=key, sha256=digest),
                    **({k: action[k] for k in ("run_id", "trigger") if k in action}),
                ),
            )
            current["matters"][matter["id"]]["status"] = "awaiting_assistant"

    def step(self, *, limit=20, deadline=None):
        report = dict(completed=0, failed=0, unknown=0)
        actions = [
            a
            for a in self.workflow._read()["outbox"].values()
            if a["stage"] == "source_read"
            and a["status"] in {"pending", "running", "query_unknown"}
        ]
        for initial in actions[:limit]:
            if deadline is not None and time.monotonic() >= deadline:
                break
            attempted = False
            try:
                _, action, matter, parent = self._current(initial["id"])
                if action["status"] == "pending":
                    query = read_bound_proposal(
                        self.root,
                        self.workflow.workspace,
                        parent,
                        action["proposal_ref"],
                    )
                    args = query["arguments"]
                    event = next(
                        e for e in _events(matter) if e["evidence"] == args["reference"]
                    )
                    with self.workflow._transaction() as state:
                        if state["outbox"][action["id"]] != action:
                            raise ValueError("source_document_stale")
                        state["outbox"][action["id"]]["status"] = "running"
                    attempted = True
                    chunk = _source_at_stage(
                        self.sources[event["source"]], "dispatch"
                    ).read_chunk(
                        event,
                        agent=action["agent"],
                        manifest=action["source_document_manifests"][args["reference"]],
                        stream=args["stream"],
                        index=args["index"],
                    )
                    self._current(action["id"])
                    receipt = dict(
                        query_key=action["id"],
                        parent_action=parent["id"],
                        proposal_ref=action["proposal_ref"],
                        requested_by=action["agent"],
                        execution_subject=action["execution_subject"],
                        manifests=action["source_document_manifests"],
                        chunk=chunk,
                    )
                    write_record(self.root, "readonly-results", action["id"], receipt)
                elif not (
                    Path(self.root) / "readonly-results" / (action["id"] + ".json")
                ).exists():
                    with self.workflow._transaction() as state:
                        state["outbox"][action["id"]]["status"] = "query_unknown"
                        state["matters"][matter["id"]]["status"] = (
                            "source_query_unknown"
                        )
                    report["unknown"] += 1
                    continue
                self._complete(action["id"])
                report["completed"] += 1
            except (ValueError, OSError, KeyError, TypeError):
                with self.workflow._transaction() as state:
                    stored = state["outbox"].get(initial["id"])
                    if stored and stored["status"] in {
                        "pending",
                        "running",
                        "query_unknown",
                    }:
                        unknown = attempted or stored["status"] == "query_unknown"
                        stored.update(
                            status="query_unknown" if unknown else "failed",
                            failure="source_document_unavailable",
                        )
                        state["matters"][stored["matter"]]["status"] = (
                            "source_query_unknown" if unknown else "source_read_failed"
                        )
                report["unknown" if attempted else "failed"] += 1
        return report

    def acknowledge_reply(self, reply):
        parent = next(
            (
                a
                for a in self.workflow._read()["outbox"].values()
                if a.get("remote_id") == reply.get("metadata", {}).get("in_reply_to")
            ),
            None,
        )
        if parent is None or "source_document_input" not in parent:
            return
        with self.workflow._transaction() as state:
            self.final_status(
                state, state["outbox"][parent["id"]], state["matters"][parent["matter"]]
            )

    def final_status(self, state, action, matter):
        if "source_document_input" not in action:
            return "read_only_result"
        self._fresh(matter, action)
        report, delivered = coverage(self.config, state, action, acknowledge=True)
        matter.update(
            source_document_delivery=delivered,
            source_document_coverage=report,
            source_document_delivery_binding=identity(
                action["revision"],
                action.get("run_id"),
                action["source_document_manifests"],
            ),
        )
        return (
            "read_only_result"
            if all(d["complete"] for d in report.values())
            else "read_only_incomplete"
        )


def private_source_context(config, state, action, *, sources, stage="dispatch"):
    if not validate_source_document(config) or "source_document_input" not in action:
        return {}
    matter = state["matters"][action["matter"]]
    scopes = {(s["source"], s["scope"]) for s in config["sources"]}
    if (
        action["agent"] not in config["agents"]
        and not (
            action["stage"] == "main"
            and action["agent"] == state["configuration"]["coordinator"]
        )
    ) or not {(e["source"], e["scope"]) for e in matter["evidence"]} <= scopes:
        raise ValueError("source_document_denied")
    for event in _events(matter):
        if (
            _source_at_stage(sources[event["source"]], stage).read_manifest(
                event, agent=action["agent"]
            )
            != action["source_document_manifests"][event["evidence"]]
        ):
            raise ValueError("source_document_manifest_changed")
    documents = _documents(config, state, action)
    report, _ = coverage(config, state, action)
    definition = deepcopy(DEFINITION)
    declared_streams = {
        stream for document in documents for stream in document["manifest"]["streams"]
    }
    definition["inputSchema"]["properties"]["stream"]["enum"] = [
        stream for stream in ("text", "parts") if stream in declared_streams
    ]
    result = dict(
        source_documents=documents,
        source_document_coverage=report,
        document_complete=all(d["complete"] for d in report.values()),
        readonly_tools=[definition] if action["stage"] == "assistant" else [],
        readonly_query_contract=dict(
            decision="readonly_query",
            tool=TOOL,
            arguments="exact reference, stream, index",
        ),
    )
    if "source_document_receipt" in action:
        descriptor = action["source_document_receipt"]
        query = state["outbox"][descriptor["key"]]
        if action["id"] != action_identity(
            query["id"], "source_continuation"
        ) or descriptor["sha256"] != query.get("receipt_sha256"):
            raise ValueError("source_document_receipt_changed")
        result["source_document_result"] = _query_receipt(config, state, query, action)
    return result


def understanding_original(source, event, *, agent, goals, config):
    """Only a source-bound observation may be judged from an explicit window."""
    from .source_goals import is_observation_goal

    source = _source_at_stage(source, "dispatch")
    if (
        validate_source_document(config)
        and (event["source"], event["scope"])
        in {(s["source"], s["scope"]) for s in config["sources"]}
        and len(goals) == 1
        and is_observation_goal(goals[0], event["source"], event["scope"])
    ):
        window = source.read_window(event, agent=agent)
        original = dict(
            reference=window["reference"],
            version=window["version"],
            content="".join(
                p["content"] for p in window["segments"] if p["stream"] == "text"
            ),
            coverage=window["coverage"],
            complete=False,
        )
        digest = sha256(
            json.dumps(
                window, sort_keys=True, separators=(",", ":"), ensure_ascii=False
            ).encode()
        ).hexdigest()
        return original, digest, window
    original = source.read_original(event, agent=agent)
    return original, sha256(original["content"].encode()).hexdigest(), None
