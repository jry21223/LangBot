"""Trusted configuration selects transport and owner-original protocol separately."""

from pathlib import Path
import os
import re

from .source_http import HttpSource
from .native_core_http import NativeCoreHttp
from .native_ingress import NativeIngress

_PLACEHOLDER = "static-validation-placeholder-not-a-real-token"


def source_flavor(item):
    native = item.get("native_ingress")
    return (
        "native_wechat"
        if isinstance(native, dict)
        and native.get("enabled") is True
        and native.get("flavor") == "native_wechat"
        else "finance"
    )


def _reader_class(flavor):
    if flavor == "native_wechat":
        from .wechat_native_reader import NativeWechatSource

        return NativeWechatSource
    return HttpSource


def _native(item):
    if "native_ingress" not in item:
        return None
    native = item["native_ingress"]
    if isinstance(native, dict) and set(native) == {"enabled"} and native["enabled"] is False:
        return None
    if (
        not isinstance(native, dict)
        or set(native)
        != {"enabled", "flavor", "endpoint", "bot_uuid", "workspace", "api_key_file"}
        or native["enabled"] is not True
        or not isinstance(native["flavor"], str)
        or native["flavor"] not in {"finance", "native_wechat"}
        or (item.get("kind", "wecom"), native["flavor"])
        not in {("wecom", "finance"), ("personal-wechat", "native_wechat")}
    ):
        raise ValueError("invalid_native_source_configuration")
    NativeCoreHttp(
        **{k: native[k] for k in ("endpoint", "bot_uuid", "workspace", "api_key_file")},
        source=item["source"],
        scope=item["scope"],
        flavor=native["flavor"],
    )
    return native


def validate_source_binding(item, *, workspace):
    if (
        not isinstance(item, dict)
        or set(item) - {"kind", "admission_mode", "native_ingress"}
        != {
            "endpoint",
            "source",
            "scope",
            "principal",
            "token_env",
            "goal_assignee_ids",
        }
        or not isinstance(item.get("kind", "wecom"), str)
        or item.get("kind", "wecom") not in {"wecom", "personal-wechat", "dingtalk"}
        or not isinstance(item["token_env"], str)
        or not re.fullmatch(r"[A-Z][A-Z0-9_]{0,100}", item["token_env"])
    ):
        raise ValueError("invalid_source_configuration")
    _native(item)
    flavor = source_flavor(item)
    _reader_class(flavor)(
        item["endpoint"],
        source=item["source"],
        scope=item["scope"],
        principal=item["principal"],
        workspace=workspace,
        token=_PLACEHOLDER,
    )
    return flavor


def reader_identity(item, *, workspace):
    identity = {k: item[k] for k in ("source", "scope", "principal", "endpoint")}
    identity["workspace"] = workspace
    if source_flavor(item) == "native_wechat":
        identity["flavor"] = "native_wechat"
    return identity


def validate_original_binding(binding):
    if (
        not isinstance(binding, dict)
        or set(binding) - {"flavor"}
        != {"source", "scope", "workspace", "principal", "endpoint", "token_file"}
        or "flavor" in binding
        and binding["flavor"] != "native_wechat"
        or not isinstance(binding["token_file"], str)
        or not Path(binding["token_file"]).is_absolute()
        or not Path(binding["token_file"]).name
        or "\x00" in binding["token_file"]
    ):
        raise ValueError("private_input_configuration_required")
    _reader_class(binding.get("flavor", "finance"))(
        binding["endpoint"],
        source=binding["source"],
        scope=binding["scope"],
        workspace=binding["workspace"],
        principal=binding["principal"],
        token=_PLACEHOLDER,
    )


def build_original_reader(binding, *, token, stage="dispatch"):
    validate_original_binding(binding)
    reader = _reader_class(binding.get("flavor", "finance"))(
        binding["endpoint"],
        source=binding["source"],
        scope=binding["scope"],
        workspace=binding["workspace"],
        principal=binding["principal"],
        token=token,
    )
    if binding.get("flavor") == "native_wechat":
        reader = reader.at_stage(stage)
    return reader


def validate_reader_separation(item, binding):
    native = _native(item)
    if native is not None and os.path.normpath(
        native["api_key_file"]
    ) == os.path.normpath(binding["token_file"]):
        raise ValueError("source_credential_refs_overlap")


def build_source(item, *, workspace, token):
    flavor = validate_source_binding(item, workspace=workspace)
    owner = _reader_class(flavor)(
        item["endpoint"],
        source=item["source"],
        scope=item["scope"],
        principal=item["principal"],
        workspace=workspace,
        token=token,
    )
    native = _native(item)
    if native is None:
        return owner
    transport = NativeCoreHttp(
        **{k: native[k] for k in ("endpoint", "bot_uuid", "workspace", "api_key_file")},
        source=item["source"],
        scope=item["scope"],
        flavor=native["flavor"],
    )
    # These are the two configured credentials for this source, not a global scan.
    if transport._key() == token:
        raise ValueError("source_credential_planes_must_differ")
    return NativeIngress(owner, transport=transport, flavor=native["flavor"])
