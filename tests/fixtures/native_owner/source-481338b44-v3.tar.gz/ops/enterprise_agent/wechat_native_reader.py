"""Explicit native-WeChat owner reader; no Finance identity or worker capabilities."""

from copy import copy
from datetime import datetime
from hashlib import sha256
import re

from .source_http import HttpSource, SourceUnavailable
from .source_documents import _budget, manifest_sha256

FORMAT = "wechat-native-text-v1"
CHUNK_BYTES = 16384
MAX_BYTES = 8_000_000
REF = re.compile(r"wechat-native:message/([a-f0-9]{64})/([a-f0-9]{64})")
GRANT = {
    "source",
    "scope",
    "principal",
    "workspace",
    "agent",
    "active",
    "read_only",
    "workspace_allowed",
    "revision",
}
ORIGINAL = {
    "reference",
    "version",
    "native_version",
    "recalled",
    "input_hash",
    "parser_version",
    "result_sha256",
    "available",
    "dispatch_eligible",
}


def _fail(status="invalid_document"):
    raise SourceUnavailable(status)


def _sha(value):
    return isinstance(value, str) and re.fullmatch(r"[a-f0-9]{64}", value) is not None


def _word(value, limit=512):
    return (
        isinstance(value, str)
        and 0 < len(value) <= limit
        and all(ord(c) >= 33 for c in value)
    )


def _wire(text):
    if not isinstance(text, str):
        _fail()
    try:
        return text.encode("utf-8")
    except UnicodeError:
        _fail()


class NativeWechatSource(HttpSource):
    def __init__(
        self, endpoint, *, source, scope, workspace, principal, token, timeout=10
    ):
        super().__init__(
            endpoint,
            source=source,
            scope=scope,
            workspace=workspace,
            principal=principal,
            token=token,
            timeout=timeout,
        )
        if self.endpoint.path.rstrip("/") != "/native" or type(timeout) not in {
            int,
            float,
        }:
            raise ValueError("invalid_native_read_endpoint")
        self._body_stage = "dispatch"

    def at_stage(self, stage):
        if not isinstance(stage, str) or stage not in {"dispatch", "result", "display"}:
            _fail("permission_denied")
        reader = copy(self)
        reader._body_stage = stage
        return reader

    def _stage(self, stage):
        stage = self._body_stage if stage is None else stage
        if not isinstance(stage, str) or stage not in {"dispatch", "result", "display"}:
            _fail("permission_denied")
        return stage

    def _event(self, event, agent=None):
        if (
            not isinstance(event, dict)
            or event.get("source") != self.source
            or event.get("scope") != self.scope
            or not isinstance(event.get("evidence"), str)
            or not REF.fullmatch(event["evidence"])
            or not _sha(event.get("version"))
            or event["evidence"].rsplit("/", 1)[1] != event["version"]
            or agent is not None
            and not _word(agent, 200)
        ):
            _fail("permission_denied")
        if "record" in event and (
            not _sha(event["record"])
            or event["record"] != event["evidence"].split("/")[1]
        ):
            _fail("permission_denied")

    def _authority(self, stage, agent, event=None):
        if (
            not isinstance(stage, str)
            or stage not in {"ingest", "dispatch", "result", "display"}
            or (stage == "ingest" and agent is not None)
            or (stage != "ingest" and not _word(agent, 200))
        ):
            _fail("permission_denied")
        if event is not None:
            self._event(event, agent)
        value = self._request(
            "/authority",
            stage=stage,
            agent=agent,
            audience_workspace=self.workspace,
            reference=event["evidence"] if event else None,
            version=event["version"] if event else None,
        )
        if (
            not {"grant", "binding"} <= set(value)
            or set(value) - {"grant", "binding", "original", "collector"}
            or not isinstance(value["grant"], dict)
            or set(value["grant"]) != GRANT
            or not _sha(value["grant"].get("revision"))
        ):
            _fail("permission_denied")
        self._checked_grant(value["grant"], agent)
        binding = value["binding"]
        if (
            not isinstance(binding, dict)
            or set(binding) != {"account", "thread", "revision"}
            or not _word(binding["account"])
            or not _word(binding["thread"])
            or not _sha(binding["revision"])
        ):
            _fail("permission_denied")
        collector = value.get("collector")
        if collector is not None:
            if (
                not isinstance(collector, dict)
                or set(collector)
                != {
                    "account",
                    "authenticated",
                    "connection",
                    "incoming_transport",
                    "contact_sync_ready",
                    "observed_at",
                }
                or collector["account"] != binding["account"]
                or type(collector["authenticated"]) is not bool
                or type(collector["contact_sync_ready"]) is not bool
                or not isinstance(collector["connection"], str)
                or collector["connection"]
                not in {"online", "reconnecting", "disconnected"}
                or not isinstance(collector["incoming_transport"], str)
                or collector["incoming_transport"]
                not in {"native_push", "heartbeat_polling", "disconnected"}
                or not _word(collector["observed_at"], 100)
            ):
                _fail()
            try:
                if (
                    datetime.fromisoformat(
                        collector["observed_at"].replace("Z", "+00:00")
                    ).utcoffset()
                    is None
                ):
                    _fail()
            except ValueError:
                _fail()
        if event is None:
            if "original" in value:
                _fail()
        else:
            original = value.get("original")
            if (
                not isinstance(original, dict)
                or set(original) != ORIGINAL
                or original["reference"] != event["evidence"]
                or original["version"] != event["version"]
                or not _word(original["native_version"])
                or not _sha(original["input_hash"])
                or not _word(original["parser_version"], 128)
                or original["result_sha256"] is not None
                and not _sha(original["result_sha256"])
                or any(
                    type(original[k]) is not bool
                    for k in ("recalled", "available", "dispatch_eligible")
                )
            ):
                _fail()
            if stage != "ingest" and (
                original["recalled"]
                or not original["available"]
                or stage in {"dispatch", "result"}
                and not original["dispatch_eligible"]
                or collector is None
                or collector["authenticated"] is not True
                or collector["contact_sync_ready"] is not True
                or collector["connection"] != "online"
                or collector["incoming_transport"] != "native_push"
            ):
                _fail("permission_denied")
        return value

    @staticmethod
    def _pin(authority):
        # Collector observation time and profile-wide generation are not message revisions.
        original = authority.get("original")
        return {
            "grant": authority["grant"],
            "binding": authority["binding"],
            "original": {k: v for k, v in original.items() if k != "native_version"}
            if original
            else None,
        }

    def authorize(self, source, stage, agent=None):
        if source != self.source:
            _fail("permission_denied")
        # Workflow service listings have no agent. This proves metadata access,
        # never agent original-text display; body methods still require an agent.
        if stage == "display" and agent is None:
            return self._authority("ingest", None)["grant"]
        return self._authority(stage, agent)["grant"]

    def authorize_evidence(self, event, stage, agent=None):
        if stage == "display" and agent is None:
            # Strict current-ref metadata remains visible even when recalled.
            # No original availability claim or owner message read is involved.
            self._event(event)
            with _budget(self):
                before = self._authority("ingest", None)
                self.read_descriptor(event, include_history=False)
                if self._pin(self._authority("ingest", None)) != self._pin(before):
                    _fail("permission_denied")
                return before["grant"]
        return self._authority(stage, agent, event)["grant"]

    def read_source_binding(self):
        with _budget(self):
            before = self._authority("ingest", None)
            value = self._request("/binding")
            if (
                set(value)
                != {
                    "source",
                    "scope",
                    "principal",
                    "workspace",
                    "revision",
                    "account",
                    "thread",
                    "origin",
                }
                or any(
                    value[k] != before["grant"][k]
                    for k in ("source", "scope", "principal", "workspace", "revision")
                )
                or value["account"] != before["binding"]["account"]
                or value["thread"] != before["binding"]["thread"]
                or value["origin"] != "owner_source_binding"
                or self._pin(self._authority("ingest", None)) != self._pin(before)
            ):
                _fail()
            return value

    def read_changes(self, cursor=None, limit=100):
        if type(limit) is not int or not 1 <= limit <= 100:
            _fail()
        with _budget(self):
            before = self._authority("ingest", None)
            value = self._request("/changes", cursor=cursor, limit=limit)
            if (
                value.get("source") != self.source
                or value.get("scope") != self.scope
                or self._pin(self._authority("ingest", None)) != self._pin(before)
            ):
                _fail()
            return value

    def read_descriptor(self, event, *, include_history=False):
        self._event(event)
        if type(include_history) is not bool:
            _fail()
        with _budget(self):
            before = self._authority("ingest", None)
            value = self._request(
                "/descriptor",
                reference=event["evidence"],
                version=event["version"],
                include_history=str(include_history).lower(),
            )
            if (
                set(value)
                != {
                    "reference",
                    "version",
                    "projection_hash",
                    "kind",
                    "original_available",
                }
                or value["reference"] != event["evidence"]
                or value["version"] != event["version"]
                or not _sha(value["projection_hash"])
                or not isinstance(value["kind"], str)
                or value["kind"]
                not in {
                    "created",
                    "baseline",
                    "changed",
                    "attachments_changed",
                    "recalled",
                }
                or type(value["original_available"]) is not bool
                or self._pin(self._authority("ingest", None)) != self._pin(before)
            ):
                _fail()
            return value

    def _manifest(self, event, agent, stage):
        self._event(event, agent)
        before = self._authority(stage, agent, event)
        value = self._request(
            "/manifest",
            reference=event["evidence"],
            version=event["version"],
            stage=stage,
            agent=agent,
        )
        if (
            set(value)
            != {"reference", "version", "kind", "byte_length", "sha256", "parts"}
            or value["reference"] != event["evidence"]
            or value["version"] != event["version"]
            or value["kind"] != "text"
            or type(value["byte_length"]) is not int
            or not 0 <= value["byte_length"] <= MAX_BYTES
            or not _sha(value["sha256"])
            or type(value["parts"]) is not int
            or not max(1, (value["byte_length"] + CHUNK_BYTES - 1) // CHUNK_BYTES)
            <= value["parts"]
            <= max(1, (value["byte_length"] + CHUNK_BYTES - 4) // (CHUNK_BYTES - 3))
        ):
            _fail()
        if self._pin(self._authority(stage, agent, event)) != self._pin(before):
            _fail("permission_denied")
        original = before["original"]
        return dict(
            format=FORMAT,
            reference=event["evidence"],
            version=event["version"],
            parser_version=original["parser_version"],
            result_sha256=original["result_sha256"],
            chunk_bytes=CHUNK_BYTES,
            streams={
                "text": dict(
                    bytes=value["byte_length"],
                    sha256=value["sha256"],
                    chunks=value["parts"],
                )
            },
        )

    def read_manifest(self, event, *, agent, stage=None):
        with _budget(self):
            return self._manifest(event, agent, self._stage(stage))

    def _chunk(self, event, agent, stage, manifest, stream, index):
        if (
            stream != "text"
            or type(index) is not int
            or manifest != self._manifest(event, agent, stage)
            or not 0 <= index < manifest["streams"]["text"]["chunks"]
        ):
            _fail()
        before = self._authority(stage, agent, event)
        value = self._request(
            "/chunk",
            reference=event["evidence"],
            version=event["version"],
            stage=stage,
            agent=agent,
            part_index=index,
        )
        if (
            set(value) != {"reference", "version", "part_index", "text", "has_more"}
            or value["reference"] != event["evidence"]
            or value["version"] != event["version"]
            or type(value["part_index"]) is not int
            or value["part_index"] != index
            or type(value["has_more"]) is not bool
        ):
            _fail()
        wire = _wire(value["text"])
        metadata = manifest["streams"]["text"]
        more = index + 1 < metadata["chunks"]
        if (
            len(wire) > CHUNK_BYTES
            or len(wire) > metadata["bytes"]
            or value["has_more"] != more
            or more
            and len(wire) < CHUNK_BYTES - 3
            or metadata["chunks"] == 1
            and (
                len(wire) != metadata["bytes"]
                or sha256(wire).hexdigest() != metadata["sha256"]
            )
        ):
            _fail()
        if self._manifest(event, agent, stage) != manifest or self._pin(
            self._authority(stage, agent, event)
        ) != self._pin(before):
            _fail("permission_denied")
        return dict(
            reference=event["evidence"],
            version=event["version"],
            stream=stream,
            index=index,
            content=value["text"],
            bytes=len(wire),
            sha256=sha256(wire).hexdigest(),
            has_more=more,
            next_index=index + 1 if more else None,
        )

    def read_chunk(self, event, *, agent, manifest, stream, index, stage=None):
        with _budget(self):
            return self._chunk(
                event, agent, self._stage(stage), manifest, stream, index
            )

    def read_original(self, event, *, agent, stage=None):
        stage = self._stage(stage)
        with _budget(self):
            before = self._authority(stage, agent, event)
            manifest = self._manifest(event, agent, stage)
            if manifest["streams"]["text"]["bytes"] > CHUNK_BYTES:
                _fail("document_budget_exceeded")
            value = self._request(
                "/original",
                reference=event["evidence"],
                version=event["version"],
                stage=stage,
                agent=agent,
            )
            if (
                set(value) != {"reference", "version", "text"}
                or value["reference"] != event["evidence"]
                or value["version"] != event["version"]
            ):
                _fail()
            wire = _wire(value["text"])
            metadata = manifest["streams"]["text"]
            if (
                len(wire) != metadata["bytes"]
                or sha256(wire).hexdigest() != metadata["sha256"]
                or self._manifest(event, agent, stage) != manifest
                or self._pin(self._authority(stage, agent, event)) != self._pin(before)
            ):
                _fail()
            return dict(
                reference=event["evidence"],
                version=event["version"],
                content=value["text"],
            )

    def read_window(self, event, *, agent, stage=None):
        stage = self._stage(stage)
        with _budget(self):
            before = self._authority(stage, agent, event)
            manifest = self._manifest(event, agent, stage)
            page = self._chunk(event, agent, stage, manifest, "text", 0)
            if self._pin(self._authority(stage, agent, event)) != self._pin(before):
                _fail("permission_denied")
            meta = manifest["streams"]["text"]
            return dict(
                reference=manifest["reference"],
                version=manifest["version"],
                parser_version=manifest["parser_version"],
                result_sha256=manifest["result_sha256"],
                manifest_sha256=manifest_sha256(manifest),
                manifest=manifest,
                segments=[
                    {
                        k: page[k]
                        for k in ("stream", "index", "content", "bytes", "sha256")
                    }
                ],
                coverage={
                    "text": dict(
                        complete=meta["chunks"] == 1,
                        bytes=page["bytes"],
                        chunks=1,
                        total_bytes=meta["bytes"],
                        total_chunks=meta["chunks"],
                        sha256=meta["sha256"],
                    )
                },
                complete=meta["chunks"] == 1,
            )

    def read_stream(
        self,
        event,
        *,
        agent,
        manifest,
        stream,
        max_chunks=100,
        max_bytes=1_000_000,
        stage=None,
    ):
        stage = self._stage(stage)
        with _budget(self):
            if stream != "text" or manifest != self._manifest(event, agent, stage):
                _fail()
            metadata = manifest["streams"]["text"]
            if (
                type(max_chunks) is not int
                or type(max_bytes) is not int
                or not 1 <= max_chunks <= 4000
                or not 0 <= max_bytes <= MAX_BYTES
            ):
                _fail()
            if metadata["chunks"] > max_chunks or metadata["bytes"] > max_bytes:
                _fail("document_budget_exceeded")
            before = self._authority(stage, agent, event)
            wire = b"".join(
                _wire(self._chunk(event, agent, stage, manifest, stream, i)["content"])
                for i in range(metadata["chunks"])
            )
            if (
                len(wire) != metadata["bytes"]
                or sha256(wire).hexdigest() != metadata["sha256"]
                or self._pin(self._authority(stage, agent, event)) != self._pin(before)
            ):
                _fail()
            return wire.decode("utf-8")
