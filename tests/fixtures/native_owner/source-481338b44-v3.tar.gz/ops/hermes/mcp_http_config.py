"""子牧 MCP 客户端统一配置：Streamable HTTP + Authorization Bearer Key。"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from urllib.parse import urlparse


def validate_authenticated_http_server(server: dict, name: str = "MCP server") -> None:
    endpoint = server.get("url", "")
    parsed = urlparse(endpoint.strip()) if isinstance(endpoint, str) else None
    if parsed is None or parsed.scheme not in {"http", "https"} or not parsed.netloc:
        raise ValueError(f"{name} must use an absolute HTTP(S) URL")
    if parsed.scheme == "http" and parsed.hostname not in {"127.0.0.1", "localhost", "::1"}:
        raise ValueError(f"{name} must use HTTPS unless the endpoint is loopback")
    authorization = server.get("headers", {}).get("Authorization", "")
    key = authorization[7:].strip() if isinstance(authorization, str) and authorization.startswith("Bearer ") else ""
    if len(key) < 32 or "\n" in key or "\r" in key:
        raise ValueError(f"{name} must use Authorization: Bearer <Key>")
    if any(field in server for field in ("command", "args", "env")):
        raise ValueError(f"{name} cannot mix HTTP and stdio transports")


def authenticated_http_server(
    endpoint: str,
    api_key: str,
    *,
    tools: list[str] | None = None,
    enabled: bool = True,
    lazy: bool = True,
    profile_scoped: bool = False,
) -> dict:
    """生成 Hermes 可直接分享的统一 MCP 连接形状，不包含 stdio 或宿主命令。"""
    server = {
        "url": endpoint.strip(),
        "headers": {"Authorization": f"Bearer {api_key.strip()}"},
        "lazy": lazy,
        "enabled": enabled,
    }
    if profile_scoped:
        server["profile_scoped"] = True
    if tools is not None:
        server["tools"] = {"include": list(tools)}
    validate_authenticated_http_server(server)
    return server


def rpc(endpoint: str, api_key: str, method: str, params: dict, *, opener=urllib.request.urlopen) -> dict:
    server = authenticated_http_server(endpoint, api_key)
    request = urllib.request.Request(
        server["url"],
        data=json.dumps({"jsonrpc": "2.0", "id": "verify", "method": method, "params": params}).encode(),
        headers={"Content-Type": "application/json", "Accept": "application/json", **server["headers"]},
        method="POST",
    )
    try:
        with opener(request, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (OSError, urllib.error.URLError, ValueError, TypeError):
        raise RuntimeError("MCP Key preflight failed") from None
    if not isinstance(payload, dict) or "error" in payload or not isinstance(payload.get("result"), dict):
        raise RuntimeError("MCP Key preflight returned an invalid response")
    return payload["result"]


def _tool_payload(result: dict) -> dict:
    texts = [item.get("text") for item in result.get("content", []) if item.get("type") == "text"]
    if len(texts) != 1:
        raise RuntimeError("MCP Key preflight returned malformed tool content")
    try:
        payload = json.loads(texts[0])
    except (ValueError, TypeError):
        raise RuntimeError("MCP Key preflight returned malformed tool content") from None
    if not isinstance(payload, dict):
        raise RuntimeError("MCP Key preflight returned malformed tool content")
    return payload


def verify_key_binding(
    endpoint: str,
    api_key: str,
    expected_identity: str,
    expected_write_tools: list[str],
    *,
    call=rpc,
) -> None:
    listed = call(endpoint, api_key, "tools/list", {})
    visible_names = {
        tool.get("name") for tool in listed.get("tools", []) if isinstance(tool, dict)
    }
    inventory = _tool_payload(call(
        endpoint, api_key, "tools/call", {"name": "list_agent_tools", "arguments": {}}))
    actual_writes = {
        tool["name"]
        for tool in inventory.get("tools", [])
        if isinstance(tool, dict) and tool.get("readOnly") is False and tool.get("name") in visible_names
    }
    if actual_writes != set(expected_write_tools):
        raise RuntimeError("MCP Key is bound to a different write-tool set")

    self_audit = _tool_payload(call(
        endpoint,
        api_key,
        "tools/call",
        {"name": "list_my_write_operations", "arguments": {"limit": 1}},
    ))
    if self_audit.get("identity") != expected_identity:
        raise RuntimeError("MCP Key is bound to a different audit identity")


def verify_tools_excluded(
    endpoint: str,
    api_key: str,
    forbidden_tools: set[str],
    *,
    call=rpc,
) -> None:
    listed = call(endpoint, api_key, "tools/list", {})
    names = {tool.get("name") for tool in listed.get("tools", []) if isinstance(tool, dict)}
    if names & forbidden_tools:
        raise RuntimeError("MCP Key exposes tools that are forbidden for this client")


def verify_server_identity(
    endpoint: str,
    api_key: str,
    expected_server: str,
    expected_profile: str,
    *,
    call=rpc,
) -> None:
    initialized = call(
        endpoint,
        api_key,
        "initialize",
        {
            "protocolVersion": "2025-03-26",
            "capabilities": {},
            "clientInfo": {"name": "zimu-mcp-key-preflight", "version": "1"},
        },
    )
    server = initialized.get("serverInfo")
    if not isinstance(server, dict):
        raise RuntimeError("MCP Key preflight did not return server identity")
    if server.get("name") != expected_server or server.get("profileId") != expected_profile:
        raise RuntimeError("MCP Key is bound to a different server or profile")
