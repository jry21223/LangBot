"""Optional private YAML runtime; never substitutes or aliases a YAML parser."""
from pathlib import Path
import os
import stat
import sys

DIRECTORY = '.production-reminders-deps'


def dependency_path(script: Path) -> Path | None:
    path = script.resolve().parent / DIRECTORY
    if not path.exists() and not path.is_symlink():
        return None  # Native PYTHONPATH remains supported.
    info = path.lstat()
    if (not stat.S_ISDIR(info.st_mode) or stat.S_IMODE(info.st_mode) != 0o700
            or (hasattr(os, 'getuid') and info.st_uid != os.getuid())):
        raise RuntimeError('Reminder dependencies must be an owned private directory')
    return path


def activate(script: Path) -> None:
    path = dependency_path(script)
    if path is not None:
        sys.path.insert(0, str(path))
