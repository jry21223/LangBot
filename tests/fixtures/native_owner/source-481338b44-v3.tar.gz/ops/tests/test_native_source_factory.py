"""Trusted source configuration selects ingress and original-reader identities."""

from pathlib import Path
import sys
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def binding(tmp_path, kind="personal-wechat"):
    return dict(
        kind=kind,
        source="wx-test" if kind == "personal-wechat" else "wecom-test",
        scope="test-only",
        endpoint="http://127.0.0.1:1/native"
        if kind == "personal-wechat"
        else "https://finance.example.invalid/owner",
        principal="original",
        token_env="OA_SOURCE_TOKEN",
        goal_assignee_ids=[],
        native_ingress=dict(
            enabled=True,
            flavor="native_wechat" if kind == "personal-wechat" else "finance",
            endpoint="https://core.example.invalid",
            bot_uuid="4f8736ca-57d8-450a-859e-a7ce9e3d34a8",
            workspace="independent-core-workspace",
            api_key_file=str(tmp_path / "core-key-not-created"),
        ),
    )


def test_explicit_native_config_builds_real_ingress_and_native_reader_without_borrowing_core_identity(
    tmp_path,
):
    from enterprise_agent.source_factory import (
        validate_source_binding,
        build_source,
        build_original_reader,
        reader_identity,
    )
    from enterprise_agent.native_ingress import NativeIngress
    from enterprise_agent.wechat_native_reader import NativeWechatSource

    cfg = binding(tmp_path)
    assert validate_source_binding(cfg, workspace="oa-workspace") == "native_wechat"
    key = Path(cfg["native_ingress"]["api_key_file"])
    key.write_text("normal-core-key-0123456789abcdef")
    key.chmod(0o600)
    source = build_source(
        cfg, workspace="oa-workspace", token="oa-original-token-0123456789abcdef"
    )
    assert isinstance(source, NativeIngress) and isinstance(
        source.finance, NativeWechatSource
    )
    assert source.finance.workspace == "oa-workspace"
    assert source.transport.workspace == "independent-core-workspace"
    ref = dict(
        reader_identity(cfg, workspace="oa-workspace"),
        token_file=str(tmp_path / "oa-token"),
    )
    reader = build_original_reader(
        ref, token="oa-original-token-0123456789abcdef", stage="result"
    )
    assert isinstance(reader, NativeWechatSource) and reader._body_stage == "result"
    assert not hasattr(reader, "transport")


@pytest.mark.parametrize("off", [None, {"enabled": False}])
def test_absent_or_disabled_native_config_preserves_legacy_http_source(tmp_path, off):
    from enterprise_agent.source_factory import build_source
    from enterprise_agent.source_http import HttpSource

    cfg = binding(tmp_path)
    if off is None:
        cfg.pop("native_ingress")
    else:
        cfg["native_ingress"] = off
    source = build_source(
        cfg, workspace="oa-workspace", token="legacy-source-token-0123456789abcdef"
    )
    assert type(source) is HttpSource


@pytest.mark.parametrize(
    "fault", ["kind_flavor", "extra", "core_workspace_missing", "relative_key", "bad_flavor_type", "bad_kind_type"]
)
def test_native_configuration_is_explicit_pure_and_exact(tmp_path, fault):
    from enterprise_agent.source_factory import validate_source_binding

    cfg = binding(tmp_path)
    if fault == "kind_flavor":
        cfg["native_ingress"]["flavor"] = "finance"
    elif fault == "extra":
        cfg["native_ingress"]["upstream_account_token"] = "forbidden"
    elif fault == "core_workspace_missing":
        cfg["native_ingress"].pop("workspace")
    elif fault == "relative_key":
        cfg["native_ingress"]["api_key_file"] = "relative.key"
    elif fault == "bad_flavor_type":
        cfg["native_ingress"]["flavor"] = []
    else:
        cfg["kind"] = []
    with pytest.raises(ValueError):
        validate_source_binding(cfg, workspace="oa-workspace")
    assert not (tmp_path / "core-key-not-created").exists()


def test_same_value_core_and_oa_credentials_are_not_independent(tmp_path):
    from enterprise_agent.source_factory import build_source

    cfg = binding(tmp_path)
    key = Path(cfg["native_ingress"]["api_key_file"])
    key.write_text("same-credential-0123456789abcdef")
    key.chmod(0o600)
    with pytest.raises(ValueError, match="credential"):
        build_source(cfg, workspace="oa-workspace", token=key.read_text())


def test_disabled_native_requires_actual_false_not_numeric_zero(tmp_path):
    from enterprise_agent.source_factory import validate_source_binding

    cfg = binding(tmp_path)
    cfg["native_ingress"] = {"enabled": 0}
    with pytest.raises(ValueError, match="invalid_native"):
        validate_source_binding(cfg, workspace="oa-workspace")
