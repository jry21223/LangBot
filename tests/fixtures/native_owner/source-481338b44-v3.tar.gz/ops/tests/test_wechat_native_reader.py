"""Native original reader against the real same-process scoped Source HTTP."""

from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path

import pytest
from test_wechat_native_http import scoped as scoped


def client(scoped, principal="original"):
    from enterprise_agent.wechat_native_reader import NativeWechatSource

    _, _, change, config, _ = scoped
    profile = next(
        p for p in config["native"]["readers"] if p["principal"] == principal
    )
    source = NativeWechatSource(
        f"http://127.0.0.1:{config['listen_port']}/native",
        source="wx-test",
        scope="test-only",
        workspace=profile["workspace"],
        principal=principal,
        token=Path(profile["token_file"]).read_text(),
        timeout=5,
    )
    event = dict(
        source="wx-test",
        scope="test-only",
        evidence=change["original"],
        version=change["version"],
    )
    return source, event


def test_native_nested_authority_binding_descriptor_and_original(scoped):
    source, event = client(scoped)
    grant = source.authorize("wx-test", "dispatch", "analysis-lab")
    assert set(grant) == {
        "source",
        "scope",
        "principal",
        "workspace",
        "agent",
        "active",
        "read_only",
        "workspace_allowed",
        "revision",
    }
    assert source.read_source_binding()["thread"] == "test@chatroom"
    assert source.read_descriptor(event)["reference"] == event["evidence"]
    assert source.read_original(event, agent="analysis-lab") == dict(
        reference=event["evidence"],
        version=event["version"],
        content="PRIVATE ORIGINAL",
    )


def test_metadata_reader_has_no_original_capability(scoped):
    from enterprise_agent.source_http import SourceUnavailable

    source, event = client(scoped, "metadata")
    assert source.authorize("wx-test", "ingest")["agent"] is None
    assert source.read_source_binding()["account"] == "account"
    assert source.read_descriptor(event)["version"] == event["version"]
    with pytest.raises(SourceUnavailable):
        source.read_original(event, agent="analysis-lab")
    assert scoped[1].calls == []


def test_large_native_text_chunks_have_real_manifest_and_complete_integrity(scoped):
    from enterprise_agent.wechat_native_store import NativeWechatStore
    from enterprise_agent.source_http import SourceUnavailable

    source, _ = client(scoped)
    _, owner, _, config, _ = scoped
    text = "中文🙂" * 7000
    owner.message_data = dict(owner.message_data, body=text)
    store = NativeWechatStore(
        config["database"],
        account="account",
        thread="test@chatroom",
        source="wx-test",
        scope="test-only",
        parser_version="parser-1",
        sequence_floor=0,
    )
    change = store.commit_native(
        owner.message_data, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )["change"]
    store.close()
    event = dict(
        source="wx-test",
        scope="test-only",
        evidence=change["original"],
        version=change["version"],
    )
    with pytest.raises(SourceUnavailable):
        source.read_original(event, agent="analysis-lab")
    manifest = source.read_manifest(event, agent="analysis-lab")
    assert (
        manifest["format"] == "wechat-native-text-v1"
        and manifest["chunk_bytes"] == 16384
    )
    assert set(manifest["streams"]) == {"text"} and manifest["result_sha256"] is None
    assert manifest["streams"]["text"]["sha256"] == sha256(text.encode()).hexdigest()
    window = source.read_window(event, agent="analysis-lab")
    assert window["coverage"]["text"]["complete"] is False
    assert len(window["segments"][0]["content"].encode()) <= 16384
    assert (
        source.read_stream(
            event, agent="analysis-lab", manifest=manifest, stream="text"
        )
        == text
    )
    with pytest.raises(SourceUnavailable):
        source.read_stream(
            event, agent="analysis-lab", manifest=manifest, stream="parts"
        )


@pytest.mark.parametrize(
    "field",
    ["source", "scope", "principal", "workspace", "agent", "revision", "active"],
)
def test_nested_grant_identity_or_activity_is_never_trusted(scoped, field):
    from enterprise_agent.source_http import SourceUnavailable

    source, _ = client(scoped)
    request = source._request

    def tampered(route, **params):
        value = deepcopy(request(route, **params))
        if route == "/authority":
            value["grant"][field] = False if field == "active" else "wrong"
        return value

    source._request = tampered
    with pytest.raises(SourceUnavailable):
        source.authorize("wx-test", "dispatch", "analysis-lab")


def test_native_stage_and_agent_are_actual_request_capabilities(scoped):
    from enterprise_agent.source_http import SourceUnavailable

    source, event = client(scoped)
    stages = []
    request = source._request

    def tracked(route, **params):
        if route in {"/authority", "/manifest", "/original", "/chunk"}:
            stages.append(params.get("stage"))
        return request(route, **params)

    source._request = tracked
    bound = source.at_stage("result")
    assert (
        bound.read_original(event, agent="analysis-lab")["content"]
        == "PRIVATE ORIGINAL"
    )
    assert stages and set(stages) == {"result"}
    with pytest.raises(SourceUnavailable):
        source.read_original(event, agent="unregistered")
    with pytest.raises(SourceUnavailable):
        source.at_stage("materialize")
    with pytest.raises(SourceUnavailable):
        source.authorize("wx-test", "ingest", "analysis-lab")


def test_current_recall_revokes_original_without_reviving_historical_reference(scoped):
    from enterprise_agent.wechat_native_store import NativeWechatStore
    from enterprise_agent.source_http import SourceUnavailable

    source, event = client(scoped)
    _, owner, _, config, _ = scoped
    owner.message_data = dict(owner.message_data, recalled=True)
    store = NativeWechatStore(
        config["database"],
        account="account",
        thread="test@chatroom",
        source="wx-test",
        scope="test-only",
        parser_version="parser-1",
        sequence_floor=0,
    )
    store.commit_native(
        owner.message_data, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )
    store.close()
    assert (
        source.read_descriptor(event, include_history=True)["original_available"]
        is False
    )
    with pytest.raises(SourceUnavailable):
        source.read_original(event, agent="analysis-lab")
    assert owner.calls == []


def test_revision_change_between_read_proofs_is_rejected(scoped):
    from enterprise_agent.source_http import SourceUnavailable

    source, event = client(scoped)
    request = source._request
    count = 0

    def drift(route, **params):
        nonlocal count
        value = deepcopy(request(route, **params))
        if route == "/authority":
            count += 1
            if count > 1:
                value["grant"]["revision"] = "f" * 64
        return value

    source._request = drift
    with pytest.raises(SourceUnavailable):
        source.read_original(event, agent="analysis-lab")


def test_tampered_manifest_or_wrong_identity_and_reference_never_returns_content(
    scoped,
):
    from enterprise_agent.source_http import SourceUnavailable

    source, event = client(scoped)
    request = source._request

    def corrupt(route, **params):
        value = deepcopy(request(route, **params))
        if route == "/manifest":
            value["sha256"] = "f" * 64
        return value

    source._request = corrupt
    with pytest.raises(SourceUnavailable):
        source.read_original(event, agent="analysis-lab")
    with pytest.raises(SourceUnavailable):
        source.read_original(dict(event, version="f" * 64), agent="analysis-lab")
    with pytest.raises(SourceUnavailable):
        source.read_original(dict(event, scope="wrong"), agent="analysis-lab")
    assert json.dumps(event).find("PRIVATE ORIGINAL") == -1


@pytest.mark.parametrize(
    "fault", ["flat", "binding", "collector", "original_input", "original_result"]
)
def test_authority_schema_and_current_original_facts_are_strict(scoped, fault):
    from enterprise_agent.source_http import SourceUnavailable

    source, event = client(scoped)
    request = source._request

    def malformed(route, **params):
        value = deepcopy(request(route, **params))
        if route == "/authority":
            if fault == "flat":
                return value["grant"]
            if fault == "binding":
                value["binding"]["revision"] = "not-sha"
            elif fault == "collector":
                value["collector"]["connection"] = []
            elif "original" in value and fault == "original_input":
                value["original"]["input_hash"] = None
            elif "original" in value and fault == "original_result":
                value["original"]["result_sha256"] = "guessed-result"
        return value

    source._request = malformed
    with pytest.raises(SourceUnavailable):
        source.read_original(event, agent="analysis-lab")


def test_source_configuration_revocation_during_original_read_is_not_returned(scoped):
    from enterprise_agent.source_http import SourceUnavailable

    source, event = client(scoped)
    _, owner, _, config, path = scoped
    read = owner.message

    def revoke(message_id):
        value = read(message_id)
        config["native"]["readers"][1]["revision"] = "revoked"
        path.write_text(json.dumps(config))
        return value

    owner.message = revoke
    with pytest.raises(SourceUnavailable):
        source.read_original(event, agent="analysis-lab")


def test_optional_native_record_is_exact_and_never_remapped(scoped):
    from enterprise_agent.source_http import SourceUnavailable

    source, event = client(scoped)
    record = event["evidence"].split("/")[1]
    assert (
        source.read_original(dict(event, record=record), agent="analysis-lab")[
            "content"
        ]
        == "PRIVATE ORIGINAL"
    )
    scoped[1].calls.clear()
    for wrong in [None, "not-sha", ("0" if record[0] != "0" else "1") + record[1:]]:
        with pytest.raises(SourceUnavailable):
            source.read_original(dict(event, record=wrong), agent="analysis-lab")
    assert scoped[1].calls == []


def test_workflow_service_metadata_listing_is_not_agent_body_display(scoped, tmp_path):
    from enterprise_agent.workflow import Workflow
    from enterprise_agent.source_http import SourceUnavailable
    from test_enterprise_agent_1324 import event as make_event

    source, event = client(scoped)
    app = Workflow(
        tmp_path / "native-reader-workflow.sqlite",
        workspace=source.workspace,
        coordinator="analysis-lab",
        assistants=[],
        authorize=source.authorize,
        authorize_evidence=source.authorize_evidence,
    )
    try:
        app.ingest(
            make_event(
                **event,
                record=event["evidence"].split("/")[1],
                approval_status="not_applicable",
            ),
            cursor="native:1",
            previous_cursor=None,
        )
        assert app.actions() and app.available_matters()
        assert scoped[1].calls == []
        with pytest.raises(SourceUnavailable):
            source.at_stage("display").read_original(event, agent=None)
        assert scoped[1].calls == []
        assert (
            source.read_original(event, agent="analysis-lab")["content"]
            == "PRIVATE ORIGINAL"
        )
    finally:
        app.close()


def test_current_recall_remains_visible_to_service_metadata_only(scoped, tmp_path):
    from enterprise_agent.wechat_native_store import NativeWechatStore
    from enterprise_agent.workflow import Workflow
    from enterprise_agent.source_http import SourceUnavailable
    from test_enterprise_agent_1324 import event as make_event

    source, _ = client(scoped)
    _, owner, _, config, _ = scoped
    owner.message_data = dict(owner.message_data, recalled=True)
    store = NativeWechatStore(
        config["database"],
        account="account",
        thread="test@chatroom",
        source="wx-test",
        scope="test-only",
        parser_version="parser-1",
        sequence_floor=0,
    )
    change = store.commit_native(
        owner.message_data, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )["change"]
    store.close()
    event = dict(
        source=source.source,
        scope=source.scope,
        evidence=change["original"],
        version=change["version"],
        record=change["record"],
    )
    app = Workflow(
        tmp_path / "native-recalled-metadata.sqlite",
        workspace=source.workspace,
        coordinator="analysis-lab",
        assistants=[],
        authorize=source.authorize,
        authorize_evidence=source.authorize_evidence,
    )
    try:
        app.ingest(
            make_event(
                **event,
                sequence=change["sequence"],
                intent="reference",
                approval_status="not_applicable",
            ),
            cursor="native:2",
            previous_cursor=None,
        )
        assert app.actions() == [] and app.available_matters()
        descriptor = source.read_descriptor(event)
        assert (
            descriptor["kind"] == "recalled"
            and descriptor["original_available"] is False
        )
        assert source.authorize_evidence(event, "display", None)["agent"] is None
        with pytest.raises(SourceUnavailable):
            source.read_original(event, agent="analysis-lab")
        assert owner.calls == []
    finally:
        app.close()
