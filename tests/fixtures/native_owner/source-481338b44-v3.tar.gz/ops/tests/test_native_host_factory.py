"""Formal open_host entry: real scoped owner HTTP, Core contract HTTP, and OA HTTP."""

from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import socket
import sqlite3
import sys
from threading import Thread
from urllib.parse import parse_qs, urlsplit

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import test_wechat_native_http as native_owner_fixtures
import test_native_core_http as core_fixtures
from enterprise_agent.native_ingress import sourcepage_digest
from enterprise_agent.input_reader import resolve_input
from enterprise_agent.run_host import open_host
from test_enterprise_agent_1324 import response

scoped = native_owner_fixtures.scoped
protected_core = core_fixtures.protected_core


@pytest.fixture
def original_http(scoped, tmp_path):
    from enterprise_agent.wechat_source import WechatJournal, source_server

    _, owner, change, old, _ = scoped
    config = deepcopy(old)
    database = tmp_path / "formal-original.sqlite"
    source_db = sqlite3.connect(old["database"])
    destination = sqlite3.connect(database)
    source_db.backup(destination)
    destination.close()
    source_db.close()
    database.chmod(0o600)
    config["database"] = str(database)
    for reader in config["native"]["readers"]:
        if reader["principal"] == "original":
            reader["agents"] = ["router", "analysis-lab"]
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        config["listen_port"] = sock.getsockname()[1]
    path = tmp_path / "formal-original.json"
    path.write_text(json.dumps(config))
    path.chmod(0o600)
    journal = WechatJournal(
        database, account="account", thread="test@chatroom", start_cursor=0
    )
    server = source_server(str(path), journal, native_owner=owner)
    # Observe actual owner authorization purposes without replacing their decisions.
    owner.formal_authorizations = []
    authorize = server.native_service.authorize

    def traced_authorize(method, route, headers, arguments):
        owner.formal_authorizations.append((route, arguments.get("stage"), arguments.get("agent")))
        return authorize(method, route, headers, arguments)

    server.native_service.authorize = traced_authorize
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield (
            f"http://127.0.0.1:{config['listen_port']}/native",
            owner,
            change,
            config,
            database,
        )
    finally:
        server.shutdown()
        server.server_close()
        thread.join()
        journal.close()


@pytest.fixture
def oa_http():
    events = []
    channels = []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def answer(self, data):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps(dict(data=data)).encode())

        def do_GET(self):
            assert (
                self.headers["X-Workspace-Token"]
                == "oa-workspace-token-0123456789abcdef"
            )
            path = urlsplit(self.path)
            if path.path.endswith("delivery-capabilities"):
                value = dict(idempotent_messages=True)
            elif path.path == "/v1/discover":
                value = dict(channels=channels, agents=[])
            else:
                query = parse_qs(path.query)
                after = int(query.get("after", ["0"])[0])
                value = dict(
                    events=[
                        e
                        for e in events
                        if int(e["id"]) > after
                        and e["target"] == "channel/" + query["channel"][0]
                    ],
                    next_cursor=str(len(events)),
                )
            self.answer(value)

        def do_POST(self):
            assert (
                self.headers["X-Workspace-Token"]
                == "oa-workspace-token-0123456789abcdef"
            )
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            if body["type"] == "network.channel.create":
                channels.append(
                    dict(
                        address=body["target"],
                        created_by=body["source"],
                        status="active",
                        master=body["payload"]["master"],
                        participants=body["payload"]["participants"],
                    )
                )
                self.answer(dict(id="channel-created"))
                return
            existing = next(
                (
                    e
                    for e in events
                    if e.get("idempotency_key") == body.get("idempotency_key")
                ),
                None,
            )
            if existing is None:
                existing = dict(body, id=str(len(events) + 1))
                events.append(existing)
            self.answer(dict(id=existing["id"]))

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_port}", events
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


@pytest.fixture
def formal_host(tmp_path, original_http, protected_core, oa_http, monkeypatch):
    endpoint, owner, change, source_config, database = original_http
    client, core, _, core_key = protected_core
    oa_endpoint, events = oa_http
    core["page"] = dict(
        page_id="native-page-1",
        source="wx-test",
        scope="test-only",
        complete_page=True,
        previous_cursor=None,
        next_cursor="core:1",
        gaps=[],
        items=[dict(event_id="native-event-1", envelope=change)],
    )
    core["page"]["page_sha256"] = sourcepage_digest(core["page"])
    profile = next(
        r for r in source_config["native"]["readers"] if r["principal"] == "original"
    )
    monkeypatch.setenv("OA_SOURCE_TOKEN", Path(profile["token_file"]).read_text())
    monkeypatch.setenv("EA_WORKSPACE_TOKEN", "oa-workspace-token-0123456789abcdef")
    config = json.loads(
        (Path(__file__).parents[1] / "enterprise_agent/host.example.json").read_text()
    )
    reader_path = tmp_path / "reader.json"
    connector_path = tmp_path / "connector.json"
    key = tmp_path / "input.key"
    key.write_bytes(b"x" * 32)
    key.chmod(0o600)
    config.update(
        enabled=True,
        owner_uid=os.getuid(),
        state=str(tmp_path / "formal-host.sqlite"),
        workspace="oa-workspace",
        workspace_endpoint=oa_endpoint,
        coordinator="router",
        assistants=["analysis-lab"],
        connector_config=str(connector_path),
        gd=None,
        understanding=dict(enabled=True, reader_config=str(reader_path), reviewers=[]),
        sources=[
            dict(
                kind="personal-wechat",
                source="wx-test",
                scope="test-only",
                endpoint=endpoint,
                principal="original",
                token_env="OA_SOURCE_TOKEN",
                goal_assignee_ids=[],
                native_ingress=dict(
                    enabled=True,
                    flavor="native_wechat",
                    endpoint=client.endpoint.geturl(),
                    bot_uuid=core_fixtures.BOT,
                    workspace=core_fixtures.WORKSPACE,
                    api_key_file=str(core_key),
                ),
            )
        ],
    )
    reader = dict(
        version=1,
        owner_uid=os.getuid(),
        state=config["state"],
        input_key_file=str(key),
        goals=[
            dict(
                id="research:native",
                kind="research",
                status="OPEN",
                clues=dict(supplier="PRIVATE", product="ORIGINAL"),
                reporters=[],
            )
        ],
        sources=[
            dict(
                source="wx-test",
                scope="test-only",
                endpoint=endpoint,
                principal="original",
                workspace="oa-workspace",
                token_file=profile["token_file"],
                flavor="native_wechat",
            )
        ],
    )
    connector = dict(
        workspace=config["workspace"],
        endpoint=oa_endpoint,
        model=config["model_version"],
        originalReader=dict(
            executable=str(
                Path(__file__).parents[1].resolve() / "enterprise_agent/input_reader.py"
            ),
            config=str(reader_path),
        ),
    )
    for path, data in [(reader_path, reader), (connector_path, connector)]:
        path.write_text(json.dumps(data))
        path.chmod(0o600)
    host = None
    try:
        yield config, reader, reader_path, owner, core, events, change, database
    finally:
        if host is not None:
            host.close()
            host.workflow.close()


def request(action, config, *, understand=False, stage="dispatch"):
    common = dict(
        stage=stage,
        content=action["message"]["payload"]["content"],
        agent=action["agent"],
        workspace=config["workspace"],
        channel=action["matter"],
        origin=dict(
            source="system:enterprise-agent-1324",
            id=action["remote_id"],
            delivery_key=action["id"],
        ),
    )
    if understand:
        body = json.loads(common["content"])
        return dict(
            common, envelope=body["understand_input"], signature=body["input_signature"]
        )
    return dict(common, mode="analysis")


def test_formal_open_host_constructs_native_ingress_projector_and_private_reader_then_recalls_old_work(
    formal_host,
):
    from enterprise_agent.native_ingress import NativeIngress
    from enterprise_agent.wechat_native_reader import NativeWechatSource
    from enterprise_agent.wechat_native_projection import SavedNativeWechat
    from enterprise_agent.wechat_native_store import NativeWechatStore

    config, reader, reader_path, owner, core, events, change, database = formal_host
    host, limits = open_host(config)
    try:
        ingress = host.sources["wx-test"]
        assert isinstance(ingress, NativeIngress) and isinstance(
            ingress.finance, NativeWechatSource
        )
        assert isinstance(host.producer.projectors["wx-test"], SavedNativeWechat)
        host.step(now="2026-11-10T00:00:00Z", limits=limits)
        app = host.workflow
        understanding = next(a for a in app.actions() if a["stage"] == "understand")
        private = resolve_input(
            reader_path, request(understanding, config, understand=True)
        )
        assert private["original"]["content"] == "PRIVATE ORIGINAL"
        assert app.receive(
            response(
                understanding,
                json.dumps(
                    dict(
                        intent="action",
                        kind="research",
                        goals=["research:native"],
                        clues=["supplier", "product"],
                        evidence=[change["original"]],
                        ambiguities=[],
                    )
                ),
            )
        )
        host.understanding.admit_ready()
        app.dispatch(host.workspace)
        main = next(a for a in app.actions() if a["stage"] == "main")
        assert (
            resolve_input(reader_path, request(main, config))["originals"][0]["content"]
            == "PRIVATE ORIGINAL"
        )
        app.receive(
            response(main, '{"decision":"delegate","assistant":"analysis-lab"}')
        )
        app.dispatch(host.workspace)
        assistant = next(a for a in app.actions() if a["stage"] == "assistant")
        assert (
            resolve_input(reader_path, request(assistant, config))["originals"][0][
                "content"
            ]
            == "PRIVATE ORIGINAL"
        )
        assert resolve_input(
            reader_path, request(assistant, config, stage="result")
        ) == dict(qualified=True)
        recalled = deepcopy(owner.message_data)
        recalled.update(recalled=True, native_version="native-2")
        store = NativeWechatStore(
            database,
            account="account",
            thread="test@chatroom",
            source="wx-test",
            scope="test-only",
            parser_version="parser-1",
        )
        try:
            updated = store.commit_native(
                recalled, event_cursor="2", observed_at="2026-11-10T00:00:00Z"
            )["change"]
        finally:
            store.close()
        owner.message_data = recalled
        core["page"].update(
            page_id="native-recall-page",
            previous_cursor="core:1",
            next_cursor="core:2",
            items=[dict(event_id="native-recall-event", envelope=updated)],
        )
        core["page"]["page_sha256"] = sourcepage_digest(core["page"])
        count = len(events)
        host.step(now="2026-11-10T00:00:01Z", limits=limits)
        state = app._read()
        matter = next(iter(state["matters"].values()))
        assert matter["status"] == "recorded"
        assert (
            matter["event"]["evidence_details"]["recalled_message_id"]
            == updated["record"]
        )
        assert state["outbox"][assistant["id"]]["status"] == "superseded"
        assert len(events) == count
        with pytest.raises(ValueError, match="input_unavailable"):
            resolve_input(reader_path, request(assistant, config))
        assert "PRIVATE ORIGINAL" not in json.dumps(events)
        assert all(
            "original" not in (call["authorization"] or "") for call in core["calls"]
        )
    finally:
        host.close()
        host.workflow.close()


@pytest.mark.parametrize(
    "fault", ["reader_flavor_missing", "core_key_ref_is_oa_ref", "kind_flavor_mismatch"]
)
def test_formal_startup_rejects_protocol_or_credential_plane_mismatch_before_creating_ledger(
    formal_host, fault
):
    config, reader, reader_path, _, core, _, _, _ = formal_host
    if fault == "reader_flavor_missing":
        reader["sources"][0].pop("flavor")
    elif fault == "core_key_ref_is_oa_ref":
        reader["sources"][0]["token_file"] = config["sources"][0]["native_ingress"][
            "api_key_file"
        ]
    else:
        config["sources"][0]["native_ingress"]["flavor"] = "finance"
    reader_path.write_text(json.dumps(reader))
    with pytest.raises(ValueError):
        open_host(config)
    assert not Path(config["state"]).exists()
    assert core["calls"] == []


def test_existing_legacy_projector_ledger_cannot_silently_switch_to_native_mode(
    formal_host,
):
    config, reader, reader_path, _, core, _, _, _ = formal_host
    legacy = deepcopy(config)
    legacy["sources"][0].pop("native_ingress")
    legacy_reader = deepcopy(reader)
    legacy_reader["sources"][0].pop("flavor")
    reader_path.write_text(json.dumps(legacy_reader))
    old, _ = open_host(legacy)
    before = old.workflow._read()
    old.close()
    old.workflow.close()
    reader_path.write_text(json.dumps(reader))
    with pytest.raises(ValueError, match="configuration_drift"):
        open_host(config)
    with sqlite3.connect(config["state"]) as db:
        after = json.loads(
            db.execute("SELECT value FROM state WHERE id=1").fetchone()[0]
        )
    assert before == after and core["calls"] == []


@pytest.mark.parametrize("reason", ["pending_media", "unknown_sender"])
def test_formal_native_owner_state_hook_holds_unreadable_or_unknown_first_message_without_model_dispatch(
    formal_host, reason
):
    from enterprise_agent.wechat_native_store import NativeWechatStore

    config, _, _, owner, core, events, _, database = formal_host
    incoming = deepcopy(owner.message_data)
    incoming["native_version"] = "native-pending"
    if reason == "pending_media":
        incoming.update(message_type="image", body="", media=[])
    else:
        incoming["sender_id"] = None
    store = NativeWechatStore(
        database,
        account="account",
        thread="test@chatroom",
        source="wx-test",
        scope="test-only",
        parser_version="parser-1",
    )
    try:
        change = store.commit_native(
            incoming, event_cursor="2", observed_at="2026-11-10T00:00:00Z"
        )["change"]
    finally:
        store.close()
    owner.message_data = incoming
    core["page"]["items"] = [dict(event_id="pending-native-event", envelope=change)]
    core["page"]["page_sha256"] = sourcepage_digest(core["page"])
    host, limits = open_host(config)
    try:
        host.step(now="2026-11-10T00:00:00Z", limits=limits)
        candidate = host.producer.candidates()[0]
        assert (
            candidate["status"] == "needs_review"
            and candidate["reason"] == "owner_incomplete"
        )
        assert host.workflow._read()["outbox"] == {} and events == []
        assert (
            host.producer.coverage("wx-test")["native_ingress"]["ack_pending"] is False
        )
    finally:
        host.close()
        host.workflow.close()


def enable_documents(config, reader, reader_path):
    from hashlib import sha256
    from enterprise_agent.source_goals import observation_goal_id

    root = reader_path.parent / "private-native-documents"
    root.mkdir(mode=0o700)
    bound = root / (sha256(b"oa-workspace/analysis-lab").hexdigest() + ".binding")
    bound.write_text("a" * 64)
    bound.chmod(0o600)
    config["source_document"] = dict(
        enabled=True,
        private_root=str(root),
        agents=["analysis-lab"],
        sources=[dict(source="wx-test", scope="test-only")],
        max_queries=20,
        max_bytes=200_000,
    )
    reader["source_document"] = deepcopy(config["source_document"])
    reader["goals"] = [dict(
        id=observation_goal_id("wx-test", "test-only"),
        kind="research", status="OPEN", clues={}, reporters=[],
        observation_source=dict(source="wx-test", scope="test-only"),
    )]
    reader_path.write_text(json.dumps(reader))
    connector_path = Path(config["connector_config"])
    connector = json.loads(connector_path.read_text())
    connector["stateRoot"] = str(root)
    connector_path.write_text(json.dumps(connector))
    return root


def test_formal_native_large_chinese_document_signed_window_query_continuation_and_result(
    formal_host,
):
    from hashlib import sha256
    from enterprise_agent.readonly_private import write_record
    from enterprise_agent.source_document_queries import SourceDocumentQueries
    from enterprise_agent.wechat_native_store import NativeWechatStore

    config, reader, reader_path, owner, core, events, _, database = formal_host
    root = enable_documents(config, reader, reader_path)
    text = "这是获准读取的长中文记录。" * 1900 + "后缀问题：请分析库存差异。"
    assert len(text.encode()) > 16384
    incoming = deepcopy(owner.message_data)
    incoming.update(body=text, native_version="native-large")
    store = NativeWechatStore(database, account="account", thread="test@chatroom",
        source="wx-test", scope="test-only", parser_version="parser-1")
    try:
        change = store.commit_native(incoming, event_cursor="2",
            observed_at="2026-11-10T00:00:00Z")["change"]
    finally:
        store.close()
    owner.message_data = incoming
    core["page"]["items"] = [dict(event_id="native-large-event", envelope=change)]
    core["page"]["page_sha256"] = sourcepage_digest(core["page"])
    host, limits = open_host(config)
    try:
        app = host.workflow
        assert isinstance(app.readonly_queries.documents, SourceDocumentQueries)
        host.step(now="2026-11-10T00:00:00Z", limits=limits)
        understanding = next(a for a in app.actions() if a["stage"] == "understand")
        private = resolve_input(reader_path, request(understanding, config, understand=True))
        assert private["document_complete"] is False
        assert private["input_hash_kind"] == "source_document_window_v1"
        assert private["original"]["content"] != text
        assert private["original"]["content"] == text[:len(private["original"]["content"])]
        # A harmless prefix cannot suppress the unread suffix's question.
        app.receive(response(understanding, json.dumps(dict(intent="chat", kind="research",
            goals=[], clues=[], evidence=[change["original"]], ambiguities=[]))))
        host.understanding.admit_ready()
        app.dispatch(host.workspace)
        main = next(a for a in app.actions() if a["stage"] == "main")
        assert resolve_input(reader_path, request(main, config))["document_complete"] is False
        app.receive(response(main, '{"decision":"delegate","assistant":"analysis-lab"}'))
        app.dispatch(host.workspace)
        assistant = next(a for a in app.actions() if a["stage"] == "assistant")
        context = resolve_input(reader_path, request(assistant, config))
        manifest = context["source_documents"][0]["manifest"]
        assert manifest["streams"]["text"]["bytes"] == len(text.encode())
        assert manifest["streams"]["text"]["chunks"] > 1
        assert set(manifest["streams"]) == {"text"}
        received = [page["content"] for page in context["source_documents"][0]["segments"]]
        for index in range(1, manifest["streams"]["text"]["chunks"]):
            proposal = dict(version=1, namespace="a" * 64, agent="analysis-lab",
                workspace=config["workspace"], channel=assistant["matter"],
                trigger=dict(id=assistant["remote_id"], source="system:enterprise-agent-1324",
                    delivery_key=assistant["id"]),
                query=dict(tool="source_document.read_chunk", arguments=dict(
                    reference=change["original"], stream="text", index=index)))
            digest = sha256(json.dumps(proposal, sort_keys=True, separators=(",", ":"),
                ensure_ascii=False).encode()).hexdigest()
            write_record(root, "readonly-proposals", digest, proposal)
            assert app.receive(response(assistant, json.dumps(dict(decision="readonly_query",
                query_ref="readonly:proposal/" + digest))))
            assert app.readonly_queries.step()["completed"] == 1
            app.dispatch(host.workspace)
            assistant = [a for a in app.actions() if a["stage"] == "assistant"][-1]
            context = resolve_input(reader_path, request(assistant, config))
            chunk = context["source_document_result"]["chunk"]
            assert chunk["index"] == index and chunk["stream"] == "text"
            received.append(chunk["content"])
            assert context["source_document_result"]["requested_by"] == "analysis-lab"
        assert "".join(received) == text
        owner.formal_authorizations.clear()
        assert resolve_input(reader_path, request(assistant, config, stage="result")) == dict(qualified=True)
        body_calls = [call for call in owner.formal_authorizations
            if call[0] in {"/native/manifest", "/native/chunk", "/native/original", "/native/derived"}]
        assert body_calls and all(stage == "result" and agent == "analysis-lab"
            for _, stage, agent in body_calls)
        assert app.receive(response(assistant, "已读获准中文全文，已识别后缀库存问题。"))
        matter = app.matters()[0]
        assert matter["status"] == "read_only_result"
        report = matter["source_document_coverage"][change["original"]]
        assert report["complete"] is True
        assert set(report["streams"]) == {"text"}
        assert report["streams"]["text"]["transmitted"]["bytes"] == len(text.encode())
        assert text not in json.dumps(events, ensure_ascii=False)
    finally:
        host.close()
        host.workflow.close()


@pytest.mark.parametrize("native", [None, {"enabled": False}, "wrong_flavor"])
def test_formal_document_scope_does_not_grant_legacy_or_wrong_flavor_personal_source(formal_host, native):
    config, reader, reader_path, _, core, _, _, _ = formal_host
    enable_documents(config, reader, reader_path)
    if native is None:
        config["sources"][0].pop("native_ingress")
    elif native == "wrong_flavor":
        config["sources"][0]["native_ingress"]["flavor"] = "finance"
    else:
        config["sources"][0]["native_ingress"] = native
    with pytest.raises(ValueError):
        open_host(config)
    assert core["calls"] == [] and not Path(config["state"]).exists()
