"""Native text-only document boundary; no fabricated Finance parts or hashes."""

from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from enterprise_agent.source_documents import _manifest
from enterprise_agent.source_http import SourceUnavailable


def native_manifest(text="汉🙂" * 3000):
    version = "b" * 64
    reference = "wechat-native:message/" + "a" * 64 + "/" + version
    wire = text.encode()
    return dict(
        format="wechat-native-text-v1",
        reference=reference,
        version=version,
        parser_version="parser-1",
        result_sha256=None,
        chunk_bytes=16384,
        streams={
            "text": dict(
                bytes=len(wire),
                sha256=sha256(wire).hexdigest(),
                chunks=max(1, (len(wire) + 16380) // 16381),
            )
        },
    )


def test_native_text_manifest_keeps_real_byte_contract_without_fabricated_parts():
    manifest = native_manifest()
    event = dict(evidence=manifest["reference"], version=manifest["version"])
    assert _manifest(manifest, event) is manifest
    assert set(manifest["streams"]) == {"text"}
    assert manifest["chunk_bytes"] == 16384
    assert manifest["result_sha256"] is None


@pytest.mark.parametrize(
    "fault",
    [
        "finance_reference",
        "wrong_version",
        "fake_parts",
        "wrong_chunk_size",
        "unknown_format",
        "empty_streams",
    ],
)
def test_native_manifest_cannot_relax_finance_or_claim_unavailable_streams(fault):
    manifest = native_manifest()
    event = dict(evidence=manifest["reference"], version=manifest["version"])
    if fault == "finance_reference":
        manifest["reference"] = event["evidence"] = "wecom:message/abc/wr-3"
    elif fault == "wrong_version":
        manifest["version"] = event["version"] = "c" * 64
    elif fault == "fake_parts":
        manifest["streams"]["parts"] = deepcopy(manifest["streams"]["text"])
    elif fault == "wrong_chunk_size":
        manifest["chunk_bytes"] = 8192
    elif fault == "unknown_format":
        manifest["format"] = "future-unapproved"
    else:
        manifest["streams"] = {}
    with pytest.raises(SourceUnavailable):
        _manifest(manifest, event)


@pytest.fixture
def native_flow(tmp_path, monkeypatch):
    """Reuse the real source HTTP fixture with an explicitly registered coordinator."""
    import json
    from enterprise_agent import wechat_source
    from enterprise_agent.wechat_native_reader import NativeWechatSource
    from enterprise_agent.wechat_native_store import NativeWechatStore
    from enterprise_agent.workflow import Workflow
    from enterprise_agent.source_document_queries import SourceDocumentQueries
    from enterprise_agent.readonly_private import write_record
    from test_enterprise_agent_1324 import Workspace, event, response
    from test_wechat_native_http import scoped

    original_server = wechat_source.source_server

    def source_with_coordinator(path, journal, **kwargs):
        config = json.loads(Path(path).read_text())
        for reader in config["native"]["readers"]:
            if reader["principal"] == "original":
                reader["agents"].append("main-agent")
        Path(path).write_text(json.dumps(config))
        return original_server(path, journal, **kwargs)

    monkeypatch.setattr(wechat_source, "source_server", source_with_coordinator)
    fixture = scoped.__wrapped__(tmp_path)
    get, owner, _, _, profile_path = next(fixture)
    config = get.service.config
    authorizations = []
    authorize = get.service.authorize

    def traced_authorize(method, route, headers, args):
        authorizations.append((route, args.get("stage"), args.get("agent")))
        return authorize(method, route, headers, args)

    get.service.authorize = traced_authorize
    text = "汉🙂段落" * 6000
    owner.message_data["body"] = text
    store = NativeWechatStore(
        config["database"],
        account=config["account"],
        thread=config["thread"],
        source=config["source"],
        scope=config["scope"],
        parser_version="parser-1",
        sequence_floor=0,
    )
    try:
        item = store.commit_native(
            owner.message_data, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
        )
    finally:
        store.close()
    reader = next(
        r for r in config["native"]["readers"] if r["principal"] == "original"
    )
    source = NativeWechatSource(
        f"http://127.0.0.1:{config['listen_port']}/native",
        source=config["source"],
        scope=config["scope"],
        workspace=reader["workspace"],
        principal=reader["principal"],
        token=Path(reader["token_file"]).read_text(),
    )
    private = tmp_path / "documents"
    private.mkdir(mode=0o700)
    binding = private / (sha256(b"oa-workspace/analysis-lab").hexdigest() + ".binding")
    binding.write_text("a" * 64)
    binding.chmod(0o600)
    app = Workflow(
        tmp_path / "documents.sqlite",
        workspace="oa-workspace",
        coordinator="main-agent",
        assistants=["analysis-lab"],
        authorize=source.authorize,
        authorize_evidence=source.authorize_evidence,
    )
    settings = dict(
        enabled=True,
        private_root=str(private),
        agents=["analysis-lab"],
        sources=[dict(source=source.source, scope=source.scope)],
        max_queries=20,
        max_bytes=100_000,
    )
    controller = SourceDocumentQueries(app, settings, sources={source.source: source})
    app.readonly_queries = controller
    workspace = Workspace()
    change = item["change"]
    evidence = event(
        source=source.source,
        scope=source.scope,
        record=change["record"],
        version=change["version"],
        sequence=change["sequence"],
        evidence=change["original"],
        approval_status="not_applicable",
    )
    app.ingest(evidence, cursor="native:1", previous_cursor=None)
    app.dispatch(workspace)
    app.receive(
        response(
            app.actions()[-1], '{"decision":"delegate","assistant":"analysis-lab"}'
        )
    )
    app.dispatch(workspace)

    def propose(stream="text", index=1):
        action = app.actions()[-1]
        record = dict(
            version=1,
            namespace="a" * 64,
            agent="analysis-lab",
            workspace="oa-workspace",
            channel=action["matter"],
            trigger=dict(
                id=action["remote_id"],
                source="system:enterprise-agent-1324",
                delivery_key=action["id"],
            ),
            query=dict(
                tool="source_document.read_chunk",
                arguments=dict(
                    reference=change["original"], stream=stream, index=index
                ),
            ),
        )
        raw = json.dumps(
            record, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ).encode()
        digest = sha256(raw).hexdigest()
        write_record(private, "readonly-proposals", digest, record)
        return response(
            action,
            json.dumps(
                dict(decision="readonly_query", query_ref="readonly:proposal/" + digest)
            ),
        )

    try:
        yield dict(
            app=app,
            controller=controller,
            config=settings,
            source=source,
            text=text,
            event=evidence,
            owner=owner,
            propose=propose,
            workspace=workspace,
            response=response,
            profile_path=profile_path,
            authorizations=authorizations,
        )
    finally:
        app.close()
        try:
            next(fixture)
        except StopIteration:
            pass


def test_native_large_utf8_stream_keeps_real_hash_and_missing_parts_capability(
    native_flow,
):
    flow = native_flow
    manifest = flow["source"].read_manifest(flow["event"], agent="analysis-lab")
    assert manifest["chunk_bytes"] == 16384
    assert set(manifest["streams"]) == {"text"}
    assert (
        flow["source"].read_stream(
            flow["event"], agent="analysis-lab", manifest=manifest, stream="text"
        )
        == flow["text"]
    )
    with pytest.raises(SourceUnavailable):
        flow["source"].read_stream(
            flow["event"], agent="analysis-lab", manifest=manifest, stream="parts"
        )
    with pytest.raises(ValueError, match="source_document_arguments_invalid"):
        flow["controller"].receive(flow["propose"]("parts", 0))


def test_native_query_reserves_actual_16384_bytes_not_finance_8192(native_flow):
    flow = native_flow
    flow["controller"].config["max_bytes"] = 25_000
    assert flow["app"].receive(flow["propose"]())
    assert not [a for a in flow["app"].actions() if a["stage"] == "source_read"]
    assert flow["app"].matters()[0]["status"] == "read_only_incomplete"


def test_native_all_text_chunks_need_authenticated_delivery_ack_without_fake_parts(
    native_flow,
):
    from enterprise_agent.source_document_queries import coverage

    flow = native_flow
    app = flow["app"]
    manifest = flow["source"].read_manifest(flow["event"], agent="analysis-lab")
    for index in range(1, manifest["streams"]["text"]["chunks"]):
        assert app.receive(flow["propose"]("text", index))
        assert flow["controller"].step()["completed"] == 1
        app.dispatch(flow["workspace"])
    action = app.actions()[-1]
    report, _ = coverage(flow["controller"].config, app._read(), action)
    assert set(report[flow["event"]["evidence"]]["streams"]) == {"text"}
    assert report[flow["event"]["evidence"]]["complete"] is False
    assert app.receive(flow["response"](action, "已覆盖当前全部文本片段。"))
    assert app.matters()[0]["status"] == "read_only_result"


@pytest.mark.parametrize("change", ["recall", "version", "grant"])
def test_native_fresh_owner_changes_never_make_a_query_receipt(native_flow, change):
    import json

    flow = native_flow
    reply = flow["propose"]()
    if change == "recall":
        flow["owner"].message_data["recalled"] = True
    elif change == "version":
        flow["owner"].message_data["body"] = "另一个当前版本"
    else:
        config = json.loads(flow["profile_path"].read_text())
        for reader in config["native"]["readers"]:
            if reader["principal"] == "original":
                reader["sharing_approved"] = False
        flow["profile_path"].write_text(json.dumps(config))
    with pytest.raises(ValueError):
        flow["controller"].receive(reply)
    assert not [
        a for a in flow["app"]._read()["outbox"].values() if a["stage"] == "source_read"
    ]


def test_native_private_result_context_uses_result_purpose_and_only_actual_streams(
    native_flow,
):
    from enterprise_agent.source_document_queries import private_source_context

    flow = native_flow
    action = flow["app"].actions()[-1]
    flow["authorizations"].clear()
    context = private_source_context(
        flow["config"],
        flow["app"]._read(),
        action,
        sources={flow["source"].source: flow["source"]},
        stage="result",
    )
    assert context["readonly_tools"][0]["inputSchema"]["properties"]["stream"][
        "enum"
    ] == ["text"]
    body_routes = {
        "/native/manifest",
        "/native/chunk",
        "/native/original",
        "/native/derived",
    }
    calls = [call for call in flow["authorizations"] if call[0] in body_routes]
    assert calls and all(
        stage == "result" and agent == "analysis-lab" for _, stage, agent in calls
    )
