'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { Boundary } = require('../connector-policy');
const upstream = process.env.OPENAGENTS_TEST_SOURCE;
const nativeTest = upstream ? test : test.skip;
const http = require('node:http');

function fixture(t) {
  const root = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), 'oa-1323-')));
  t.after(() => fs.rmSync(root, { recursive: true, force: true }));
  fs.mkdirSync(path.join(root, 'profiles/employee-test'), { recursive: true });
  const authority = path.join(root, 'authority.cjs');
  fs.writeFileSync(authority, `#!/usr/bin/env node
let s=''; process.stdin.on('data', d=>s+=d); process.stdin.on('end',()=>{
 const r=JSON.parse(s); const state=JSON.parse(require('fs').readFileSync(${JSON.stringify(path.join(root, 'grant.json'))}));
 console.log(JSON.stringify({...r, ...state}));
});\n`, { mode: 0o700 });
  const grant = { active: true, readOnly: true, isolated: true, enforcement: 'fixture-boundary-v1' };
  fs.writeFileSync(path.join(root, 'grant.json'), JSON.stringify(grant));
  const config = { version: 1, enabled: true, workspace: 'test-workspace', endpoint: 'http://127.0.0.1:18765',
    profileRoot: path.join(root, 'profiles'), stateRoot: path.join(root, 'state'), ownerUid: process.getuid(),
    hermesBinary: process.execPath, authority, model: 'fixture-model', modelEndpoint: 'http://127.0.0.1:18766',
    credentialRef: 'fixture-no-key', maxTurns: 3, timeoutMs: 5000, maxConcurrent: 1,
    mappings: [{ agent: 'test-assistant', employee: 'employee-001', profile: 'employee-test', revision: 'r1',
      executionPolicy: 'fixture-boundary-v1', role: 'employee' }] };
  const file = path.join(root, 'config.json');
  fs.writeFileSync(file, JSON.stringify(config));
  const open = () => new Boundary(file, 'test-workspace', 'test-assistant', config.endpoint);
  return { root, config, file, open, grant, save() { fs.writeFileSync(file, JSON.stringify(config)); },
    grantSave() { fs.writeFileSync(path.join(root, 'grant.json'), JSON.stringify(grant)); } };
}

test('an explicit active mapping authorizes launch, but live revocation blocks result exposure', async t => {
  const f = fixture(t);
  const boundary = f.open();
  await boundary.authorize('launch');
  f.grant.active = false; f.grantSave();
  await assert.rejects(boundary.authorize('result'), /authorization unavailable/);
});

test('a lab Workspace service principal is explicit and cannot masquerade as an employee', async t => {
  const f = fixture(t);
  delete f.config.mappings[0].employee;
  Object.assign(f.config.mappings[0], { principalType: 'workspace-service', principalId: 'test-assistant',
    executionPolicy: 'hermes-no-tools-lab-v1' });
  f.config.runtimeMode = 'workspace-service-lab';
  f.grant.enforcement = 'hermes-no-tools-lab-v1'; f.grantSave(); f.save();
  const boundary = f.open();
  await boundary.authorize('launch');
  assert.equal(boundary.tuple.principalType, 'workspace-service');
  assert.equal(Object.hasOwn(boundary.tuple, 'employee'), false);
  f.config.mappings[0].employee = 'invented-employee'; f.save();
  assert.throws(f.open, /authorization unavailable/);
  delete f.config.mappings[0].employee;
  f.config.runtimeMode = 'production'; f.save();
  assert.throws(f.open, /authorization unavailable/);
});

test('understand input fails closed without an explicit original reader and never passes through raw result text', async t => {
  const f = fixture(t);
  const boundary = f.open();
  const content = JSON.stringify({ understand_input: { stage: 'understand' }, input_signature: 'forged' });
  await assert.rejects(boundary.materializeInput(content, 'proposal', {}), /authorization unavailable/);
  assert.throws(() => boundary.validateResult(content, 'PRIVATE ORIGINAL BODY'), /authorization unavailable/);
  assert.equal(await boundary.materializeInput('ordinary read-only query', 'thread', {}), 'ordinary read-only query');
  await assert.rejects(boundary.authorizeDelivery({ channel: 'wrong-channel', metadata: { in_reply_to: 'trigger-A' },
    inputAuthority: { channel: 'proposal-A', content, message: { messageId: 'trigger-A' } } }), /authorization unavailable/);
});

nativeTest('native adapter refuses missing policy rather than discovering a default profile', () => {
  const { createAdapter } = require(path.join(upstream, 'src/adapters'));
  assert.throws(() => createAdapter('hermes', { workspaceId: 'test-workspace', agentName: 'test-assistant',
    endpoint: 'http://127.0.0.1:18765', token: 'fixture-secret', boundaryRequired: true }), /authorization unavailable/);
});

for (const [name, change] of [
  ['wrong runtime owner', f => { f.config.ownerUid = process.getuid() + 1; }],
  ['disabled deployment', f => { f.config.enabled = false; }],
  ['default profile', f => { f.config.mappings[0].profile = 'default'; }],
  ['duplicate agent', f => { f.config.mappings.push({ ...f.config.mappings[0] }); }],
  ['missing employee', f => { delete f.config.mappings[0].employee; }],
  ['missing profile', f => { f.config.mappings[0].profile = 'absent'; }],
  ['escaped profile', f => { fs.rmSync(path.join(f.root, 'profiles/employee-test'), { recursive: true });
    fs.symlinkSync(os.tmpdir(), path.join(f.root, 'profiles/employee-test')); }],
  ['aliased employee profile', f => { fs.mkdirSync(path.join(f.root, 'profiles/other-employee'));
    fs.rmSync(path.join(f.root, 'profiles/employee-test'), { recursive: true });
    fs.symlinkSync(path.join(f.root, 'profiles/other-employee'), path.join(f.root, 'profiles/employee-test')); }],
  ['unbounded turns', f => { f.config.maxTurns = 1000; }],
]) {
  test(`rejects ${name} without launching Hermes`, t => {
    const f = fixture(t); change(f); f.save();
    assert.throws(f.open, /authorization unavailable/);
  });
}

test('binding drift is not silently resumed, and separate threads have separate work directories', t => {
  const f = fixture(t); const original = f.open();
  assert.notEqual(original.workdir('thread-1'), original.workdir('thread-2'));
  assert.equal(f.open().namespace, original.namespace);
  f.config.mappings[0].revision = 'r2'; f.save();
  assert.throws(f.open, /authorization unavailable/);
});

test('configuration drift and ineffective runtime restrictions fail before capability use', async t => {
  const f = fixture(t); const boundary = f.open();
  f.grant.readOnly = false; f.grantSave();
  await assert.rejects(boundary.authorize('launch'), /authorization unavailable/);
  f.grant.readOnly = true; f.grantSave();
  f.config.endpoint = 'https://unapproved.invalid'; f.save();
  await assert.rejects(boundary.authorize('launch'), /authorization unavailable/);
});

nativeTest('native adapter refuses corrupt session state instead of starting a fresh employee session', t => {
  const f = fixture(t); const boundary = f.open();
  fs.writeFileSync(path.join(boundary.directory, 'sessions.json'), '[]');
  const { createAdapter } = require(path.join(upstream, 'src/adapters'));
  assert.throws(() => createAdapter('hermes', { workspaceId: 'test-workspace', agentName: 'test-assistant',
    endpoint: f.config.endpoint, token: 'fixture-secret', boundaryConfig: f.file }), /session state corrupt/);
});

for (const serviceStdin of [false, true]) nativeTest(serviceStdin
  ? 'lab service HTTP dispatch keeps its prompt out of every child argv'
  : 'native HTTP dispatch executes the explicit profile and resumes its thread after restart', { timeout: 45000 }, async t => {
  const f = fixture(t);
  const events = [], replies = [], queries = [], completedAttempts = [];
  const delivered = new Set();
  let dropReply = true;
  let cursor = 0;
  const server = http.createServer(async (req, res) => {
    let text = ''; for await (const chunk of req) text += chunk;
    const url = new URL(req.url, 'http://localhost');
    let data = {};
    if (url.pathname === '/mcp') {
      const call = JSON.parse(text); queries.push(call.params.name);
      if (call.method !== 'tools/call' || call.params.name !== 'inventory_read') { res.statusCode = 403; }
      data = { jsonrpc: '2.0', id: call.id, result: { content: [{ type: 'text', text: 'fixture inventory: 7' }] } };
    }
    else if (url.pathname === '/v1/join') data = { session_id: 'native-fixture-join' };
    else if (url.pathname === '/v1/discover') data = { agents: [] };
    else if (url.pathname === '/v1/events/delivery-capabilities') data = { idempotent_messages: true };
    else if (url.pathname === '/v1/events' && req.method === 'POST') {
      const event = JSON.parse(text);
      if (event.metadata?.status_kind === 'completed') completedAttempts.push(event.idempotency_key);
      if (!event.idempotency_key || !delivered.has(event.idempotency_key)) {
        replies.push(event); if (event.idempotency_key) delivered.add(event.idempotency_key);
      }
      if (dropReply && event.metadata?.status_kind === 'completed') {
        dropReply = false; res.destroy(); return; // Persisted remotely, response lost.
      }
      data = { id: `reply-${replies.length}` };
    } else if (url.pathname === '/v1/events') {
      if (url.searchParams.get('target_agents')) {
        const after = Number(url.searchParams.get('after') || 0);
        data = { events: events.filter(e => Number(e.id) > after), next_cursor: String(cursor) };
      } else data = { events: [], next_cursor: String(cursor) };
    }
    res.setHeader('Content-Type', 'application/json'); res.end(JSON.stringify({ data }));
  });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => { server.closeAllConnections(); server.close(); });
  f.config.endpoint = `http://127.0.0.1:${server.address().port}`;
  const executable = path.join(f.root, 'hermes-fixture.cjs');
  const runs = path.join(f.root, 'runs.jsonl');
  fs.writeFileSync(executable, `#!/usr/bin/env node
const fs=require('fs'); const args=process.argv.slice(2);
if(args.includes('--version')) { console.log('Hermes Agent v0.21.4'); process.exit(0); }
const prompt=args.includes('--query-file')?fs.readFileSync(0,'utf8'):args[args.indexOf('-q')+1];
fs.appendFileSync(${JSON.stringify(runs)}, JSON.stringify({args,prompt,cwd:process.cwd()})+'\\n');
if(prompt?.includes('FAIL_FIXTURE')) { console.error('controlled spawn failure'); process.exit(2); }
if(prompt?.includes('TIMEOUT_FIXTURE')) { setInterval(()=>{}, 1000); } else {
fetch(${JSON.stringify(f.config.endpoint + '/mcp')}, {method:'POST',headers:{'content-type':'application/json'},
 body:JSON.stringify({jsonrpc:'2.0',id:1,method:'tools/call',params:{name:'inventory_read',arguments:{}}})})
 .then(r=>r.json()).then(value=>{
 console.log(value.data.result.content[0].text); console.error('session_id: fixture-session-001');
}).catch(()=>process.exit(2)); }
`, { mode: 0o700 });
  f.config.hermesBinary = executable; f.config.timeoutMs = 2000; f.save();
  if (serviceStdin) {
    f.config.runtimeMode = 'workspace-service-lab';
    delete f.config.mappings[0].employee;
    Object.assign(f.config.mappings[0], { principalType: 'workspace-service', principalId: 'test-assistant',
      executionPolicy: 'hermes-no-tools-lab-v1' });
    f.grant.enforcement = 'hermes-no-tools-lab-v1'; f.grantSave(); f.save();
  }
  const { createAdapter } = require(path.join(upstream, 'src/adapters'));
  const waitFor = async predicate => {
    const deadline = Date.now() + 15000;
    while (!predicate()) {
      if (Date.now() > deadline) throw new Error('native fixture timed out');
      await new Promise(resolve => setTimeout(resolve, 25));
    }
  };
  const start = () => {
    const adapter = createAdapter('hermes', { workspaceId: 'test-workspace', agentName: 'test-assistant',
      endpoint: f.config.endpoint, token: 'fixture-secret', boundaryConfig: f.file, logSink: () => {} });
    const running = adapter.run();
    return { adapter, running };
  };
  let current = start();
  t.after(async () => { current.adapter.stop(); await current.running; });
  // No event means no execution; task creation is not represented as a dispatch.
  await new Promise(resolve => setTimeout(resolve, 250));
  assert.equal(fs.existsSync(runs), false);
  const dispatch = (content, channel = 'thread-1') => {
    cursor++;
    events.push({ id: String(cursor), type: 'workspace.message.posted', source: 'human:fixture',
      target: 'channel/' + channel, payload: { content, message_type: 'chat' },
      metadata: { target_agents: ['test-assistant'] } });
  };
  dispatch('@test-assistant read inventory' + (serviceStdin ? ' PRIVATE_PIPE_8427' : ''));
  await waitFor(() => replies.some(e => e.metadata?.status_kind === 'completed'));
  if (serviceStdin) {
    current.adapter.stop(); await current.running;
    const first = fs.readFileSync(runs, 'utf8').trim().split('\n').map(JSON.parse)[0];
    assert.ok(!first.args.join(' ').includes('PRIVATE_PIPE_8427'));
    assert.ok(!first.args.includes('-q'));
    assert.deepEqual(first.args.slice(3, 5), ['--query-file', '-']);
    assert.ok(first.prompt.includes('PRIVATE_PIPE_8427'));
    return;
  }
  current.adapter.stop(); await current.running;
  current = start();
  dispatch('@test-assistant read inventory again');
  await waitFor(() => replies.filter(e => e.metadata?.status_kind === 'completed').length === 2);
  current.adapter.stop(); await current.running;
  const executed = fs.readFileSync(runs, 'utf8').trim().split('\n').map(JSON.parse);
  assert.equal(executed.length, 2);
  assert.equal(completedAttempts.length, 3, 'one lost response is retried after restart');
  assert.equal(completedAttempts[0], completedAttempts[1], 'recovery uses the same delivery key');
  assert.ok(completedAttempts[0]);
  assert.deepEqual(executed[0].args.slice(0, 3), ['-p', 'employee-test', 'chat']);
  assert.ok(!executed[0].args.includes('--yolo'));
  assert.ok(!executed[0].args.join(' ').includes('fixture-secret'));
  const resume = executed[1].args.indexOf('--resume');
  assert.equal(executed[1].args[resume + 1], 'fixture-session-001');
  assert.equal(executed[0].cwd, executed[1].cwd);
  assert.deepEqual(queries, ['inventory_read', 'inventory_read']);
  assert.ok(replies.filter(e => e.metadata?.status_kind === 'completed').every(e =>
    e.target === 'channel/thread-1' && e.payload.content === 'fixture inventory: 7'));
  assert.ok(replies.filter(e => e.metadata?.status_kind === 'completed').every(e =>
    Array.isArray(e.metadata.explicit_targets) && e.metadata.explicit_targets.length === 0),
    'boundary results must not trigger native automatic collaboration outside the durable coordinator');
  current = start();
  dispatch('@test-assistant FAIL_FIXTURE');
  await waitFor(() => replies.some(e => e.metadata?.status_kind === 'error'));
  dispatch('@test-assistant TIMEOUT_FIXTURE');
  await waitFor(() => replies.filter(e => e.metadata?.status_kind === 'error').length === 2);
  current.adapter.stop(); await current.running;
  assert.equal(replies.filter(e => e.metadata?.status_kind === 'completed').length, 2,
    'nonzero exit and timeout never become successful replies');
  assert.equal(fs.readFileSync(runs, 'utf8').trim().split('\n').length, 4,
    'failed turns are not automatically replayed in a fresh session');
  // An old native session without a proven classification must not resume;
  // an independent new read-only channel still works after the refusal.
  const legacy = f.open();
  fs.unlinkSync(path.join(legacy.workdir('thread-1'), 'input-binding.json'));
  current = start();
  dispatch('@test-assistant LEGACY_UNKNOWN_HISTORY');
  await new Promise(resolve => setTimeout(resolve, 300));
  dispatch('@test-assistant read independent inventory', 'independent-thread');
  await waitFor(() => replies.filter(e => e.metadata?.status_kind === 'completed').length === 3);
  current.adapter.stop(); await current.running;
  const afterLegacy = fs.readFileSync(runs, 'utf8').trim().split('\n').map(JSON.parse);
  assert.equal(afterLegacy.length, 5);
  assert.ok(!afterLegacy.some(r => r.args.join(' ').includes('LEGACY_UNKNOWN_HISTORY')));
});

test('owner-original UTF-8 evidence survives helper pipe chunks inside a three-byte character', async t => {
  const f = fixture(t);
  const reader = path.join(f.root, 'reader.cjs'), config = path.join(f.root, 'reader.json');
  fs.writeFileSync(config, '{}', { mode: 0o600 });
  fs.writeFileSync(reader, `#!/usr/bin/env node
process.stdin.resume();process.stdin.on('end',()=>{
 const output=Buffer.from(JSON.stringify({original:{reference:'owner:ref/v1',version:'v1',content:'牛肉'},goal_catalog:[]}));
 const split=output.indexOf(Buffer.from('牛'))+1;
 process.stdout.write(output.subarray(0,split));
 setTimeout(()=>process.stdout.end(output.subarray(split)),50);
});`, { mode: 0o700 });
  f.config.originalReader = { executable: reader, config };
  f.config.mappings[0].role = 'coordinator'; f.save();
  const content = JSON.stringify({ understand_input: { candidate: 'candidate-1', judgment_version: 1,
    reference: 'owner:ref/v1', source_version: 'v1' }, input_signature: 'fixture-signed-envelope' });
  const boundary = f.open();
  const input = JSON.parse(await boundary.materializeInput(content, 'proposal-1', {
    senderName: 'system:enterprise-agent-1324', messageId: 'trigger-1', metadata: { delivery_key: 'action-1' } }));
  assert.equal(input.owner_input.original.content, '牛肉');
  await assert.rejects(f.open().materializeInput(content, 'proposal-1', {
    senderName: 'system:enterprise-agent-1324', messageId: 'trigger-1', metadata: { delivery_key: 'action-1' } }),
    /authorization unavailable/, 'uncertain original model execution must not be repeated after restart');
  delete f.config.originalReader; f.save();
  const withoutReader = f.open();
  await assert.rejects(withoutReader.materializeInput('repeat private history', 'proposal-1', {}), /authorization unavailable/);
  fs.writeFileSync(path.join(withoutReader.workdir('proposal-1'), 'input-binding.json'), '{broken');
  await assert.rejects(f.open().materializeInput('repeat private history', 'proposal-1', {}), /authorization unavailable/);
});

for (const source of ['wechat', 'wecom', 'wechat-native']) {
test(`validated ${source} lab evidence references survive shape redaction while known secrets do not`, async t => {
  const f = fixture(t);
  const ref = source === 'wecom'
    ? 'wecom:message/' + 'a'.repeat(64) + '/wr-37'
    : source + ':message/' + 'a'.repeat(64) + '/' + 'b'.repeat(64);
  const secret = 'fixture-private-credential-0123456789abcdef';
  const reader = path.join(f.root, 'reader.cjs'), config = path.join(f.root, 'reader.json');
  fs.writeFileSync(config, '{}', { mode: 0o600 });
  fs.writeFileSync(reader, `#!/usr/bin/env node
process.stdin.resume();process.stdin.on('end',()=>console.log(JSON.stringify({original:{reference:${JSON.stringify(ref)},version:'v1',content:'test'},goal_catalog:[]})));`, { mode: 0o700 });
  f.config.originalReader = { executable: reader, config };
  f.config.runtimeMode = 'workspace-service-lab';
  delete f.config.mappings[0].employee;
  Object.assign(f.config.mappings[0], { role: 'coordinator', principalType: 'workspace-service',
    principalId: 'test-assistant', executionPolicy: 'hermes-no-tools-lab-v1' });
  f.grant.enforcement = 'hermes-no-tools-lab-v1'; f.grantSave(); f.save();
  const content = JSON.stringify({ understand_input: { candidate: 'candidate-1', judgment_version: 1,
    reference: ref, source_version: 'v1' }, input_signature: 'fixture-signed-envelope',
    candidate_goals: [{ id: 'research:test' }], reply_contract: { intent: ['action'], kind: ['research'],
      clues: ['product'], evidence: [ref] } });
  const boundary = f.open();
  await boundary.materializeInput(content, 'proposal', { senderName: 'system:enterprise-agent-1324',
    messageId: 'trigger', metadata: { delivery_key: 'action' } });
  const result = JSON.stringify({ intent: 'action', kind: 'research', goals: ['research:test'],
    clues: ['product'], evidence: [ref], ambiguities: [] });
  const redact = value => value.replaceAll(ref, '[REDACTED]').replaceAll(secret, '[REDACTED]');
  const safe = JSON.parse(boundary.redactResult('proposal', result, redact, [secret]));
  assert.deepEqual(safe.evidence, [ref]);
  assert.throws(() => boundary.redactResult('proposal', result, redact, [ref]), /authorization unavailable/);
  assert.throws(() => boundary.redactResult('proposal', result, redact, ['a'.repeat(32)]), /authorization unavailable/);
  const unrelated = result.replaceAll('a'.repeat(64), 'c'.repeat(64));
  assert.throws(() => boundary.redactResult('proposal', unrelated, redact, []), /authorization unavailable/);
  assert.equal(boundary.redactResult('ordinary', ref + ' ' + secret, redact, [secret]), '[REDACTED] [REDACTED]');
});
}

test('a lab analysis task receives owner text privately and cannot reuse it as ordinary history', async t => {
  const f = fixture(t);
  const reader = path.join(f.root, 'analysis-reader.cjs'), config = path.join(f.root, 'reader.json');
  fs.writeFileSync(config, '{}', { mode: 0o600 });
  fs.writeFileSync(reader, `#!/usr/bin/env node
let raw='';process.stdin.on('data',d=>raw+=d);process.stdin.on('end',()=>{
 const r=JSON.parse(raw);if(r.mode!=='analysis')process.exit(1);
 console.log(JSON.stringify(r.stage==='result'?{qualified:true}:{originals:[{reference:'wechat:message/test',version:'v1',content:'测试消息7392'}]}));
});`, { mode: 0o700 });
  f.config.originalReader = { executable: reader, config };
  f.config.runtimeMode = 'workspace-service-lab';
  delete f.config.mappings[0].employee;
  Object.assign(f.config.mappings[0], { principalType: 'workspace-service', principalId: 'test-assistant',
    executionPolicy: 'hermes-no-tools-lab-v1' });
  f.grant.enforcement = 'hermes-no-tools-lab-v1'; f.grantSave(); f.save();
  const boundary = f.open();
  const content = JSON.stringify({ allowed_action: 'read_only_analysis', evidence: [{ evidence: 'wechat:message/test' }] });
  const message = { senderName: 'system:enterprise-agent-1324', messageId: 'trigger', metadata: { delivery_key: 'action' } };
  const value = JSON.parse(await boundary.materializeInput(content, 'matter', message));
  assert.equal(value.owner_input.originals[0].content, '测试消息7392');
  assert.equal(boundary.resumeSession('matter', 'previous-session'), null);
  await boundary.authorizeDelivery({ channel: 'matter', metadata: { in_reply_to: 'trigger' },
    inputAuthority: boundary.inputAuthority('matter', 'trigger') });
  await assert.rejects(boundary.materializeInput('ordinary message', 'matter', message), /authorization unavailable/);
});

for (const role of ['employee', 'coordinator']) {
test(`${role} query arguments remain private and only the assistant can request a read`, async t => {
  const f = fixture(t);
  const reader = path.join(f.root, 'query-reader.cjs'), config = path.join(f.root, 'reader.json');
  fs.writeFileSync(config, '{}', { mode: 0o600 });
  fs.writeFileSync(reader, `#!/usr/bin/env node
process.stdin.resume();process.stdin.on('end',()=>console.log(JSON.stringify({originals:[{reference:'wecom:message/test',version:'wr-1',content:'fixture source'}]})));`, { mode: 0o700 });
  f.config.originalReader = { executable: reader, config };
  f.config.runtimeMode = 'workspace-service-lab';
  delete f.config.mappings[0].employee;
  Object.assign(f.config.mappings[0], { role, principalType: 'workspace-service', principalId: 'test-assistant',
    executionPolicy: 'hermes-no-tools-lab-v1' });
  f.grant.enforcement = 'hermes-no-tools-lab-v1'; f.grantSave(); f.save();
  const boundary = f.open();
  const content = JSON.stringify({ allowed_action: 'read_only_analysis', evidence: [{ evidence: 'wecom:message/test' }] });
  const message = { senderName: 'system:enterprise-agent-1324', messageId: 'native-trigger', metadata: { delivery_key: 'parent-action' } };
  await boundary.materializeInput(content, 'matter', message);
  const query = JSON.stringify({ decision: 'readonly_query', tool: 'fulfillment_query_order',
    arguments: { search: 'PRIVATE-QUERY-CONTENT' } });
  if (role === 'coordinator') {
    assert.throws(() => boundary.redactResult('matter', query, value => value, []), /authorization unavailable/);
    assert.ok(!fs.existsSync(path.join(f.config.stateRoot, 'readonly-proposals')));
    return;
  }
  const exposed = boundary.redactResult('matter', query, value => value, []);
  const receipt = JSON.parse(exposed);
  assert.deepEqual(Object.keys(receipt).sort(), ['decision', 'query_ref']);
  assert.match(receipt.query_ref, /^readonly:proposal\/[a-f0-9]{64}$/);
  assert.ok(!exposed.includes('PRIVATE-QUERY-CONTENT'));
  const directory = path.join(f.config.stateRoot, 'readonly-proposals');
  const file = path.join(directory, receipt.query_ref.split('/').at(-1) + '.json');
  const raw = fs.readFileSync(file);
  assert.equal(require('node:crypto').createHash('sha256').update(raw).digest('hex'), receipt.query_ref.split('/').at(-1));
  assert.equal(fs.statSync(file).mode & 0o777, 0o600);
  const stored = JSON.parse(raw);
  assert.equal(stored.agent, 'test-assistant');
  assert.equal(stored.namespace, boundary.namespace);
  assert.equal(stored.trigger.delivery_key, 'parent-action');
  assert.deepEqual(stored.query.arguments, { search: 'PRIVATE-QUERY-CONTENT' });
  assert.equal(boundary.redactResult('matter', query, value => value, []), exposed);
  assert.equal(fs.readdirSync(directory).length, 1);
  assert.throws(() => boundary.redactResult('ordinary-channel', query, value => value, []), /authorization unavailable/);
  assert.throws(() => boundary.redactResult('matter', query, value => value, ['PRIVATE-QUERY-CONTENT']), /authorization unavailable/);
  assert.throws(() => boundary.redactResult('matter', JSON.stringify({ decision: 'readonly_query', query_ref: receipt.query_ref }), value => value, []), /authorization unavailable/);
  assert.throws(() => boundary.redactResult('matter', '```json\n' + query + '\n```', value => value, []), /authorization unavailable/);
  const alias = path.join(directory, 'alias');
  fs.linkSync(file, alias);
  assert.throws(() => boundary.redactResult('matter', query, value => value, []), /authorization unavailable/);
  fs.unlinkSync(alias);
  fs.chmodSync(file, 0o644);
  assert.throws(() => boundary.redactResult('matter', query, value => value, []), /authorization unavailable/);
  fs.chmodSync(file, 0o600);
  const backup = directory + '-original', other = directory + '-outside';
  fs.renameSync(directory, backup);
  fs.mkdirSync(other, { mode: 0o700 });
  fs.symlinkSync(other, directory);
  assert.throws(() => boundary.redactResult('matter', query, value => value, []), /authorization unavailable/);
  assert.equal(fs.readdirSync(other).length, 0);
  fs.unlinkSync(directory);
  fs.renameSync(backup, directory);
  assert.equal(fs.readdirSync(directory).length, 1);
  const sourceQuery = { decision: 'readonly_query', tool: 'source_document.read_chunk',
    arguments: { reference: 'wecom:message/test', stream: 'text', index: 1 } };
  for (const argumentsValue of [
    { ...sourceQuery.arguments, index: true },
    { ...sourceQuery.arguments, index: -1 },
    { ...sourceQuery.arguments, index: 0.5 },
    { ...sourceQuery.arguments, stream: 'credentials' },
    { ...sourceQuery.arguments, reference: 'wecom:message/other-chat' },
    { ...sourceQuery.arguments, endpoint: 'https://example.org' },
  ]) assert.throws(() => boundary.redactResult('matter', JSON.stringify({ ...sourceQuery,
    arguments: argumentsValue }), value => value, []), /authorization unavailable/);
  const sourcePublic = boundary.redactResult('matter', JSON.stringify(sourceQuery), value => value, []);
  assert.ok(!sourcePublic.includes('wecom:message/test'));
  assert.ok(!sourcePublic.includes('read_chunk'));
  assert.equal(boundary.redactResult('matter', JSON.stringify(sourceQuery), value => value, []), sourcePublic);
  const sourceFile = path.join(directory, JSON.parse(sourcePublic).query_ref.split('/').at(-1) + '.json');
  assert.deepEqual(JSON.parse(fs.readFileSync(sourceFile)).query, {
    tool: sourceQuery.tool, arguments: sourceQuery.arguments });
});
}

for (const phase of ['prepare', 'send']) {
  for (const lateFailure of [false, true]) {
    nativeTest(`terminal audit wins over ${phase} in flight with late ${lateFailure ? 'failure' : 'success'}`, async t => {
      const { ResponseOutbox } = require(path.join(upstream, 'src/adapters/response-outbox'));
      const f = fixture(t);
      let started, release;
      const entered = new Promise(resolve => { started = resolve; });
      const gate = new Promise(resolve => { release = resolve; });
      const logs = [];
      let sends = 0;
      const finish = async () => {
        started();
        await gate;
        if (lateFailure) throw Object.assign(new Error('fixture lost acknowledgement'), { code: 'ECONNRESET' });
      };
      const outbox = new ResponseOutbox({ endpoint: f.config.endpoint, workspaceId: 'test-workspace',
        agentName: 'test-assistant', directory: path.join(f.root, 'outbox'),
        log: message => logs.push(message), onRevoked: () => {},
        prepare: async () => { if (phase === 'prepare') await finish(); return { safeRetry: true }; },
        send: async () => { sends++; if (phase === 'send') await finish(); } });
      const original = { id: '00000000-0000-4000-8000-000000000001', channel: 'protected',
        content: 'strict original reply', createdAt: Date.now(), attempts: 1, safeRetry: true,
        prepared: phase === 'send' };
      outbox.save(original);
      const flight = outbox.flush();
      await entered;
      const terminal = { ...original, blocked: true, superseded_by: 'current-host-action',
        superseded_reason: 'host_verified_receipt', verified_receipt: 'original-native-receipt' };
      outbox.save(terminal);
      release();
      await flight;
      assert.deepEqual(outbox.readEntries(), [terminal]);
      assert.equal(sends, phase === 'prepare' ? 0 : 1);
      assert.ok(!logs.some(message => message.includes('Delivered saved reply')));
      await outbox.flush();
      assert.deepEqual(outbox.readEntries(), [terminal]);
      assert.equal(sends, phase === 'prepare' ? 0 : 1);
    });
  }
}
