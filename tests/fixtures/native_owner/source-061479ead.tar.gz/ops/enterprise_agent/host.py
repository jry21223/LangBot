"""One bounded observation-only host iteration; no business/notification writer."""
from dataclasses import dataclass
from datetime import datetime
import fcntl
import os
import math
import time

from ._ledger import private_file
from .producer import Admission
from .native_ingress import NativeIngress, NativeConsumerConflict
from .source_http import GoalReadUnavailable, SourceUnavailable
from ._http_budget import current_deadline


@dataclass(frozen=True)
class Limits:
    pages: int = 1
    page_size: int = 100
    admissions: int = 20
    actions: int = 20
    checks: int = 20
    seconds: float = 30

    def __post_init__(self):
        if (any(type(v) is not int or not 1 <= v <= 100 for v in
                (self.pages, self.page_size, self.admissions, self.actions, self.checks))
                or type(self.seconds) not in (int, float) or not math.isfinite(self.seconds)
                or not 0 < self.seconds <= 300):
            raise ValueError("invalid_host_limits")


class Host:
    def __init__(self, producer, *, sources, workspace, admit, understanding=None, rechecks=None):
        self.producer, self.workflow = producer, producer.workflow
        self.sources = {source.source: source for source in sources}
        if not self.sources or len(self.sources) != len(sources):
            raise ValueError("unique_sources_required")
        self.workspace, self.admission = workspace, admit
        self.understanding = understanding
        self.rechecks = rechecks
        filename = self.workflow.db.execute("PRAGMA database_list").fetchone()[2]
        self._lock = os.fdopen(private_file(filename + ".host.lock"), "r+")

    def close(self):
        self._lock.close()

    def step(self, *, now, limits=None):
        limits = limits or Limits()
        if datetime.fromisoformat(now.replace("Z", "+00:00")).utcoffset() is None:
            raise ValueError("aware_time_required")
        try:
            fcntl.flock(self._lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return {"status": "busy"}
        budget = current_deadline.set(time.monotonic() + limits.seconds)
        try:
            deadline = current_deadline.get()
            report = {"status": "observed", "sources": {}, "admitted": 0}
            # Pure registration checks precede even scheduler state writes. A
            # wrong Core realm cannot mutate or execute the original ledger.
            for source in self.sources.values():
                if isinstance(source,NativeIngress):
                    try:
                        source.check_consumer(self.producer)
                    except NativeConsumerConflict as error:
                        report['sources'][source.source]=str(error)
                        return report
            # Reserve time for already-admitted native work even if a source or
            # target stalls. Rotate the first source across process restarts.
            source_end = time.monotonic() + limits.seconds * 0.4
            admission_end = time.monotonic() + limits.seconds * 0.8
            candidate_end = (time.monotonic() + limits.seconds * 0.6
                             if self.understanding is not None else admission_end)
            names = list(self.sources)
            for index in range(len(names)):
                remaining = source_end - time.monotonic()
                if remaining <= 0:
                    break
                name = self.workflow._window(names, "source_position", 1)[0]
                source = self.sources[name]
                source_budget = current_deadline.set(time.monotonic() + remaining / (len(names) - index))
                try:
                    for _ in range(limits.pages):
                        if time.monotonic() >= current_deadline.get():
                            break
                        cursor = (self.producer.coverage(name) or {}).get("cursor")
                        try:
                            if isinstance(source,NativeIngress):
                                result=source.poll(self.producer,limit=limits.page_size)
                                report['sources'][name]=('ack_pending' if not result['acknowledged']
                                    else self.producer.coverage(name)['status'])
                                if result['stop']:
                                    break
                                continue
                            page = source.read_changes(cursor, limits.page_size)
                            self.producer.prepare(name, page, previous_cursor=cursor)
                            report["sources"][name] = self.producer.coverage(name)["status"]
                            if not page["items"] or page["next_cursor"] == cursor:
                                break
                        except (SourceUnavailable, ValueError, OSError) as error:
                            status = (error.status if isinstance(error, SourceUnavailable) else
                                      "missing_page" if str(error) in {"incomplete_source_page", "cursor_gap"}
                                      else "sync_failed")
                            if not (isinstance(error,NativeConsumerConflict) or
                                isinstance(source,NativeIngress) and self.producer.coverage(name) is None):
                                self.producer.record_coverage(name, status)
                            report["sources"][name] = status
                            break
                finally:
                    current_deadline.reset(source_budget)
            selected = list(self.producer.pending_candidates(limit=limits.admissions, deadline=candidate_end))
            for examined, candidate in enumerate(selected):
                if time.monotonic() >= candidate_end:
                    break
                candidate_budget = current_deadline.set(min(candidate_end, time.monotonic() +
                    (candidate_end - time.monotonic()) / (len(selected) - examined)))
                try:
                    if self.producer.apply_owner_state(candidate["id"]):
                        report["owner_updates"] = report.get("owner_updates", 0) + 1
                        continue
                    raw = candidate.get("admission")
                    if raw:
                        requalify = getattr(self.admission, "requalify", None)
                        if requalify is None:
                            raise ValueError("current_target_qualification_required")
                        decision = requalify(candidate, Admission(**raw))
                    elif self.understanding is not None:
                        # Exact GD is association evidence, not semantic intent.
                        # Understanding requalifies any selected GD via its trusted rule.
                        self.understanding.start(candidate["id"])
                        continue
                    else:
                        decision = self.admission(candidate)
                    if decision is None:
                        if self.understanding is not None:
                            self.understanding.start(candidate["id"])
                        else:
                            self.producer.hold(candidate["id"], "needs_review")
                    else:
                        if self.producer.admit(candidate["id"], decision) is not None:
                            report["admitted"] += 1
                except (ValueError, OSError) as error:
                    if isinstance(error, (OSError, GoalReadUnavailable)):
                        self.producer.defer(candidate["id"])
                    else:
                        self.producer.hold(candidate["id"], "goal_readback_unavailable")
                finally:
                    current_deadline.reset(candidate_budget)
            if self.understanding is not None and time.monotonic() < admission_end:
                self.understanding.admit_ready(limit=limits.admissions, deadline=admission_end)
            if self.rechecks is not None and time.monotonic() < deadline:
                check_deadline = min(deadline, time.monotonic() + max(0, (deadline - time.monotonic()) / 2))
                report["rechecks"] = self.rechecks.step(now=now, limit=limits.checks, deadline=check_deadline)
            if time.monotonic() < deadline:
                if self.workflow.readonly_queries is not None:
                    report['readonly_queries']=self.workflow.readonly_queries.step(limit=limits.actions,deadline=deadline)
                try:
                    self.workflow.tick(self.workspace, max_actions=limits.actions,
                                       max_matters=limits.actions, deadline=deadline)
                except (ValueError, OSError):
                    report["native"] = "unavailable"
            return report
        finally:
            current_deadline.reset(budget)
            fcntl.flock(self._lock, fcntl.LOCK_UN)
