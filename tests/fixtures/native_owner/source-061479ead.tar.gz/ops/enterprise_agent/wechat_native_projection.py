"""Opt-in native evidence projection, separate from the legacy text journal."""
from copy import deepcopy
from datetime import datetime
import re


class SavedNativeWechat:
    version = 'personal-wechat-native-v1'
    supported_types = {'text', 'image', 'voice', 'file'}

    def project(self, candidate, selection):
        try:
            change, saved = candidate['change'], candidate['change']['saved']
            fields = {'account_id', 'thread_id', 'message_id', 'sender_id', 'server_id',
                      'message_type', 'direction', 'body_available'}
            if (any(not isinstance(candidate.get(k), str) or not 0 < len(candidate[k]) <= 200
                    or any(ord(c) < 32 for c in candidate[k]) for k in ('source', 'scope'))
                    or set(saved) != fields or saved['direction'] not in ('incoming', None)
                    or type(saved['body_available']) is not bool
                    or type(change.get('original_available', True)) is not bool
                    or set(selection) != {'goal', 'confirmed', 'intent', 'candidates'}
                    or type(selection['confirmed']) is not bool
                    or change['kind'] not in {'created', 'changed', 'baseline', 'baseline_snapshot',
                                               'attachments_changed', 'recalled'}):
                raise ValueError()
            for key in fields - {'body_available'}:
                value = saved[key]
                if key in {'sender_id', 'server_id', 'direction'} and value is None:
                    continue
                if not isinstance(value, str) or not 0 < len(value) <= 512 or any(ord(c) < 32 for c in value):
                    raise ValueError()
            if (not all(isinstance(change[k], str) and re.fullmatch('[a-f0-9]{64}', change[k]) for k in ('record', 'version'))
                    or change['original'] != f"wechat-native:message/{change['record']}/{change['version']}"
                    or type(change['sequence']) is not int or change['sequence'] < 1):
                raise ValueError()
            for key in ('business_at', 'observed_at'):
                if not isinstance(change[key], str) or datetime.fromisoformat(change[key].replace('Z', '+00:00')).utcoffset() is None:
                    raise ValueError()
            recalled = change['kind'] == 'recalled'
            incomplete = (saved['direction'] != 'incoming' or not saved['body_available'] or not change.get('original_available', True)
                          or not saved['sender_id'] or not saved['server_id']
                          or saved['message_type'] not in self.supported_types)
            baseline = change['kind'] in {'baseline', 'baseline_snapshot'}
            event = {k: deepcopy(change[k]) for k in ('record', 'version', 'sequence', 'business_at', 'observed_at')}
            details = deepcopy(saved)
            details.update(recalled=recalled, owner_state='recalled' if recalled else 'pending' if incomplete else 'ready')
            event.update(source=candidate['source'], scope=candidate['scope'], evidence=change['original'],
                         approval_status='not_applicable', evidence_details=details, **deepcopy(selection))
            if recalled or incomplete or baseline:
                event.update(confirmed=False, review_required=True)
            if recalled or baseline:
                event['intent'] = 'reference'
            return event
        except (ValueError, TypeError, KeyError, AttributeError):
            raise ValueError('invalid_saved_native_wechat') from None

    def owner_state(self, candidate):
        projected = self.project(candidate, dict(goal='unresolved', confirmed=False, intent='reference', candidates=[]))
        details = projected['evidence_details']
        return dict(recalled=details['recalled'], incomplete=details['owner_state'] != 'ready')
