"""Reviewed, bounded read-only checks on existing matters, using Workflow's outbox.

The rule is trusted host configuration, never a model reply or source text.
Only the existing exact GD reader is called; no business command is available.
"""
from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import datetime, timedelta
import re
import time
from zoneinfo import ZoneInfo

from ._http_budget import current_deadline
from .source_http import is_gd_edit_version
from .workflow import action_identity, identity


def _time(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.utcoffset() is None:
        raise ValueError("aware_time_required")
    return result


@dataclass(frozen=True)
class Rule:
    source: str
    scope: str
    version: str
    interval_seconds: int
    timezone: str
    basis: str
    check_kind: str = "gd_status"

    def __post_init__(self):
        if (any(not isinstance(v, str) or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,200}", v)
                for v in (self.source, self.scope, self.version, self.basis))
                or self.check_kind != "gd_status" or type(self.interval_seconds) is not int
                or not 60 <= self.interval_seconds <= 31 * 86400):
            raise ValueError("reviewed_check_rule_required")
        ZoneInfo(self.timezone)


class Rechecks:
    def __init__(self, workflow, *, reader, rules, allowed_owners):
        self.workflow, self.reader = workflow, reader
        if not isinstance(rules, list) or not rules or any(not isinstance(r, Rule) for r in rules):
            raise ValueError("reviewed_check_rule_required")
        self.rules = {(r.source, r.scope): r for r in rules}
        if len(self.rules) != len(rules):
            raise ValueError("duplicate_check_rule")
        self.allowed_owners = {key: frozenset(value) for key, value in allowed_owners.items()}
        if (any(not self.allowed_owners.get(key) for key in self.rules)
                or any(not isinstance(owner, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", owner)
                       for values in self.allowed_owners.values() for owner in values)):
            raise ValueError("goal_ownership_binding_required")
        configuration = dict(rules=[asdict(r) for r in rules], owners=[
            [*key, sorted(value)] for key, value in sorted(self.allowed_owners.items())])
        with workflow._transaction() as state:
            if state.setdefault("wake_configuration", configuration) != configuration:
                raise ValueError("configuration_drift")
            state.setdefault("wake_plans", {})
            state.setdefault("check_receipts", {})

    def plans(self):
        return self._visible("wake_plans")

    def receipts(self):
        return self._visible("check_receipts")

    def _visible(self, key):
        state = self.workflow._read()
        values = list(state[key].values())
        for value in values:
            self.workflow._authorize_matter(state["matters"][value["matter"]], "display", None)
        return deepcopy(values)

    @staticmethod
    def _unresolved(state, matter_id):
        return any(a["matter"] == matter_id and a["status"] in {"pending", "sent", "delivery_unknown"}
                   for a in state["outbox"].values())

    def _rule(self, matter):
        event = matter["event"]
        return self.rules.get((event["source"], event["scope"]))

    def _snapshot(self, matter, rule):
        self.workflow._authorize_matter(matter, "dispatch", self.workflow.coordinator)
        code = matter["event"].get("evidence_details", {}).get("goal_reference")
        if not isinstance(code, str) or not re.fullmatch(r"GD-[A-Za-z0-9-]{1,60}", code):
            raise ValueError("exact_goal_required")
        value = self.reader.get(code)
        if (not isinstance(value, dict) or set(value) != {"id", "code", "status", "edit_version", "assignee_ids"}
                or value["code"] != code or not is_gd_edit_version(value["edit_version"])
                or type(value["id"]) is bool or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", str(value["id"]))
                or value["status"] not in {"OPEN", "IN_PROGRESS", "DONE", "CANCELLED"}
                or not isinstance(value["assignee_ids"], list) or not 1 <= len(value["assignee_ids"]) <= 100
                or any(not isinstance(owner, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", owner)
                       for owner in value["assignee_ids"])
                or not self.allowed_owners[(rule.source, rule.scope)].intersection(value["assignee_ids"])):
            raise ValueError("goal_readback_unavailable")
        # A saved canonical GD link is the target; a current read cannot retarget it.
        goal = matter["event"]["goal"]
        if goal != "gd:" + str(value["id"]):
            raise ValueError("goal_readback_unavailable")
        return deepcopy(value)

    @staticmethod
    def _next(now, rule):
        return (now + timedelta(seconds=rule.interval_seconds)).astimezone(ZoneInfo(rule.timezone)).isoformat()

    def _invalidate(self, state, plan, reason):
        plan.update(status="invalidated", invalidated_reason=reason)
        for action in state["outbox"].values():
            if (action["matter"] == plan["matter"] and action.get("trigger", {}).get("plan") == plan["id"]
                    and action["status"] in {"pending", "sent", "delivery_unknown"}):
                action["status"] = "superseded"

    def step(self, *, now, limit=20, deadline=None):
        when = _time(now)
        state = self.workflow._read()
        selected = self.workflow._window(list(state["matters"].values()), "check_position", limit)
        report = {"checked": 0, "woken": 0, "unavailable": 0}
        for index, matter in enumerate(selected):
            if deadline is not None and time.monotonic() >= deadline:
                break
            budget = current_deadline.set(None if deadline is None else
                time.monotonic() + (deadline - time.monotonic()) / (len(selected) - index))
            try:
                result = self._one(matter["id"], when)
                for key in report:
                    report[key] += result.get(key, 0)
            finally:
                current_deadline.reset(budget)
        return report

    def _one(self, matter_id, now):
        state = self.workflow._read()
        matter = state["matters"][matter_id]
        rule = self._rule(matter)
        if rule is None:
            return {}
        plan = state["wake_plans"].get(matter_id)
        if plan and plan["base_revision"] != matter["revision"]:
            with self.workflow._transaction() as current:
                old = current["wake_plans"].pop(matter_id)
                self._invalidate(current, old, "new_evidence")
                current.setdefault("wake_plan_history", []).append(old)
            plan = None
        if plan and plan["status"] in {"invalidated", "closed"}:
            return {}
        if matter.get("review_required") or matter["status"] in {"recorded", "needs_review"}:
            if plan:
                with self.workflow._transaction() as current:
                    self._invalidate(current, current["wake_plans"][matter_id], "waiting_input_or_closed")
            return {}
        if self._unresolved(state, matter_id):
            return {}  # Recover the original native request before opening another round.
        if matter["status"] == "execution_failed":
            if plan:
                with self.workflow._transaction() as current:
                    current["wake_plans"][matter_id]["status"] = "execution_failed"
            return {}
        if plan and plan["status"] == "waiting_execution":
            if matter["status"] != "read_only_result":
                return {}
            with self.workflow._transaction() as current:
                p = current["wake_plans"][matter_id]
                p.update(status="closed" if p.get("terminal_observed") else "waiting_time",
                         occurrence=p["occurrence"] + 1, due_at=self._next(now, rule), run_id=None)
            return {}
        if plan and now < _time(plan.get("retry_at") or plan["due_at"]):
            return {}
        if not plan and matter["status"] != "read_only_result":
            return {}
        try:
            # Qualification and readonly network operations stay outside the short CAS.
            self.workflow._authorize_matter(matter, "dispatch", self.workflow.coordinator)
            if not plan:
                baseline = self._snapshot(matter, rule)
                with self.workflow._transaction() as current:
                    if (current["matters"][matter_id] != matter or self._unresolved(current, matter_id)):
                        raise ValueError("concurrent_state_change")
                    current["wake_plans"][matter_id] = dict(id=identity(matter_id, matter["revision"], rule.version),
                        matter=matter_id, version=rule.version, base_revision=matter["revision"],
                        check_kind=rule.check_kind, waiting_condition="awaiting_owner_progress",
                        basis={"rule": rule.basis, "evidence": matter["event"]["evidence"], "scheduled_at": now.isoformat()},
                        timezone=rule.timezone, due_at=self._next(now, rule), status="waiting_time",
                        occurrence=1, run_id=None, last_snapshot=baseline)
                    if baseline["status"] in {"DONE", "CANCELLED"}:
                        p = current["wake_plans"][matter_id]
                        run_id = identity(p["id"], "terminal_baseline")
                        receipt = dict(id=identity(run_id, "check"), matter=matter_id, run_id=run_id,
                            plan=p["id"], occurrence=0, checked_at=now.isoformat(), base_revision=matter["revision"],
                            result="completion_observed" if baseline["status"] == "DONE" else "cancelled_observed",
                            fact=baseline, reference="gd:" + str(baseline["id"]) + ":" + str(baseline["edit_version"]), mode="observe")
                        current["check_receipts"][receipt["id"]] = receipt
                        p.update(status="closed", terminal_observed=True, last_receipt=receipt["id"])
                return {"checked": int(baseline["status"] in {"DONE", "CANCELLED"})}
            with self.workflow._transaction() as current:
                p = current["wake_plans"][matter_id]
                m = current["matters"][matter_id]
                if (p != plan or m["revision"] != plan["base_revision"]
                        or m.get("review_required") or self._unresolved(current, matter_id)):
                    return {}
                run_id = identity(matter_id, plan["base_revision"], plan["id"], plan["occurrence"])
                p.update(status="checking", run_id=run_id)
                m["current_run_id"] = run_id
            snapshot = self._snapshot(matter, rule)
            # Recheck current authority after the external read, before its result can enqueue.
            self.workflow._authorize_matter(matter, "dispatch", self.workflow.coordinator)
            with self.workflow._transaction() as current:
                p = current["wake_plans"][matter_id]
                m = current["matters"][matter_id]
                if (p["status"] != "checking" or p["run_id"] != run_id
                        or m["revision"] != plan["base_revision"] or m.get("current_run_id") != run_id
                        or m.get("review_required")):
                    return {}
                changed = snapshot != plan["last_snapshot"]
                result = {"DONE": "completion_observed", "CANCELLED": "cancelled_observed"}.get(
                    snapshot["status"], "changed" if changed else "waiting")
                receipt = dict(id=identity(run_id, "check"), matter=matter_id, run_id=run_id,
                    plan=p["id"], occurrence=p["occurrence"], checked_at=now.isoformat(),
                    base_revision=plan["base_revision"], result=result, fact=snapshot,
                    reference="gd:" + str(snapshot["id"]) + ":" + str(snapshot["edit_version"]), mode="observe")
                current["check_receipts"][receipt["id"]] = receipt
                p.update(last_snapshot=snapshot, last_receipt=receipt["id"], terminal_observed=snapshot["status"] in {"DONE", "CANCELLED"})
                p.pop("retry_at", None)
                if changed:
                    key = action_identity(matter_id, run_id, "main")
                    trigger = {k: receipt[k] for k in ("plan", "occurrence", "result", "fact", "reference")}
                    trigger.update(kind="recheck", base_revision=m["revision"], rule=rule.version)
                    current["outbox"][key] = dict(id=key, matter=matter_id, revision=m["revision"],
                        run_id=run_id, agent=self.workflow.coordinator, stage="main", status="pending", trigger=trigger)
                    if "result" in m:
                        m.setdefault("result_history", []).append(m.pop("result"))
                    m.update(status="awaiting_main")
                    p["status"] = "waiting_execution"
                else:
                    p.update(status="closed" if p["terminal_observed"] else "waiting_time",
                             occurrence=p["occurrence"] + 1, due_at=self._next(now, rule), run_id=None)
            return {"checked": 1, "woken": int(changed)}
        except (ValueError, OSError) as error:
            with self.workflow._transaction() as current:
                p = current["wake_plans"].get(matter_id)
                if p and p["base_revision"] == matter["revision"] and p["status"] not in {"invalidated", "closed"}:
                    if getattr(error, "status", None) in {"permission_denied", "credential_expired"}:
                        self._invalidate(current, p, "grant_revoked")
                    else:
                        p.update(status="source_unavailable", retry_at=self._next(now, rule))
            return {"unavailable": 1}
