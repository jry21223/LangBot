"""Injected Core pull/receipt protocol; no route, credential or second writer.

The protected Core adapter must normalize its actual wire/auth wrapper to these
methods. Finance remains the authority and original-body owner. Core cursors
belong solely to this opt-in ingress, never to the SDK/Finance upstream cursor.
"""

from copy import deepcopy
from hashlib import sha256
import json
import re
from uuid import UUID


class NativeConsumerConflict(ValueError):
    """A local registration/migration error; never overwrite the existing realm."""


def canonical_core_origin(value):
    from .source_http import _endpoint

    try:
        parsed = _endpoint(value)
        if parsed.path not in ("", "/"):
            raise ValueError()
        host = parsed.hostname.lower()
        if ":" in host:
            host = "[" + host + "]"
        else:
            host = host.encode("idna").decode("ascii")
        port = parsed.port
        suffix = (
            ""
            if port is None or (parsed.scheme, port) in {("https", 443), ("http", 80)}
            else ":" + str(port)
        )
        return parsed.scheme.lower() + "://" + host + suffix
    except (ValueError, TypeError, AttributeError, UnicodeError):
        raise NativeConsumerConflict("native_consumer_identity_invalid") from None


def consumer_identity(binding, *, source, scope, flavor):
    try:
        if (
            not isinstance(binding, dict)
            or set(binding)
            != {"endpoint", "workspace", "bot_uuid", "source", "scope", "flavor"}
            or binding["source"] != source
            or binding["scope"] != scope
            or binding["flavor"] != flavor
            or not isinstance(binding["workspace"], str)
            or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", binding["workspace"])
            or not isinstance(binding["bot_uuid"], str)
            or str(UUID(binding["bot_uuid"])) != binding["bot_uuid"]
        ):
            raise ValueError()
        domain = dict(binding, endpoint=canonical_core_origin(binding["endpoint"]))
        return dict(
            version=1, domain=domain, sha256=sha256(canonical_bytes(domain)).hexdigest()
        )
    except (ValueError, TypeError, KeyError, AttributeError):
        raise NativeConsumerConflict("native_consumer_identity_invalid") from None


OWNER_GAP_CODES = {
    "finance": frozenset({"history_before_feed_unverified", "original_unavailable"}),
    "native_wechat": frozenset(
        {"history_before_activation_unverified", "original_unavailable"}
    ),
}


def _valid_gap(gap, source, scope, flavor):
    if (
        not isinstance(gap, dict)
        or not _opaque(gap.get("event_id"), 200)
        or gap.get("source") != source
        or gap.get("scope") != scope
    ):
        return False
    if gap.get("reason") == "native_unresolved":
        return set(gap) == {"event_id", "reason", "source", "scope"}
    return (
        gap.get("reason") == "owner_source_gap"
        and set(gap) == {"event_id", "reason", "source", "scope", "code"}
        and gap["code"] in OWNER_GAP_CODES[flavor]
    )


def canonical_bytes(value):
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def sourcepage_digest(page):
    """SHA256 canonical UTF8 JSON excluding only page_sha256; no newline."""
    return sha256(
        canonical_bytes(
            {key: value for key, value in page.items() if key != "page_sha256"}
        )
    ).hexdigest()


def _opaque(value, limit):
    return (
        isinstance(value, str)
        and 1 <= len(value) <= limit
        and all(32 < ord(char) < 127 for char in value)
    )


def validate_page(page, *, source, scope, previous_cursor, limit=100, flavor="finance"):
    try:
        if (
            not isinstance(flavor, str)
            or flavor not in OWNER_GAP_CODES
            or not isinstance(page, dict)
            or set(page)
            != {
                "page_id",
                "page_sha256",
                "source",
                "scope",
                "complete_page",
                "previous_cursor",
                "next_cursor",
                "gaps",
                "items",
            }
            or not _opaque(page["page_id"], 200)
            or not isinstance(page["page_sha256"], str)
            or not re.fullmatch(r"[a-f0-9]{64}", page["page_sha256"])
            or page["source"] != source
            or page["scope"] != scope
            or page["complete_page"] is not True
            or page["previous_cursor"] != previous_cursor
            or page["previous_cursor"] is not None
            and not _opaque(page["previous_cursor"], 4096)
            or not _opaque(page["next_cursor"], 4096)
            or not isinstance(page["gaps"], list)
            or any(not _valid_gap(g, source, scope, flavor) for g in page["gaps"])
            or not isinstance(page["items"], list)
            or type(limit) is not int
            or not 1 <= limit <= 100
            or len(page["items"]) + len(page["gaps"]) > limit
            or any(
                not isinstance(item, dict)
                or set(item) != {"event_id", "envelope"}
                or not _opaque(item["event_id"], 200)
                or not isinstance(item["envelope"], dict)
                for item in page["items"]
            )
            or len({item["event_id"] for item in page["items"]}) != len(page["items"])
            or len({row["event_id"] for row in page["items"] + page["gaps"]})
            != len(page["items"]) + len(page["gaps"])
            or sourcepage_digest(page) != page["page_sha256"]
        ):
            raise ValueError()
        if (
            not page["items"]
            and not page["gaps"]
            and page["next_cursor"]
            != ("0" if previous_cursor is None else previous_cursor)
        ):
            raise ValueError()
    except (TypeError, KeyError, UnicodeError, ValueError):
        raise ValueError("invalid_native_ingress_page") from None
    return deepcopy(page)


def accepted_receipt(event_id, envelope):
    key = [
        "langbot-router-receipt-v1",
        envelope["source"],
        envelope["record"],
        envelope["version"],
    ]
    return dict(
        event_id=event_id,
        source=envelope["source"],
        record=envelope["record"],
        version=envelope["version"],
        status="accepted",
        receipt_id=sha256(canonical_bytes(key)).hexdigest(),
    )


def gap_code(gap):
    key = [gap["source"], gap["scope"], gap["event_id"]]
    prefix = (
        "owner_source_gap:" + gap["code"] + ":"
        if gap.get("reason") == "owner_source_gap"
        else "native_unresolved:"
    )
    return prefix + sha256(canonical_bytes(key)).hexdigest()


def unresolved_codes(metadata):
    return [
        gap_code(entry)
        for _, entry in sorted(metadata.get("gap_audit", {}).items())
        if entry["status"] == "unresolved"
    ]


def page_metadata(page, previous=None, *, flavor="finance", consumer=None):
    audit = deepcopy((previous or {}).get("gap_audit", {}))
    for gap in page["gaps"]:
        old = audit.get(gap["event_id"], {})
        if old and (old["source"] != gap["source"] or old["scope"] != gap["scope"]):
            raise ValueError("native_ingress_gap_scope_conflict")
        audit[gap["event_id"]] = dict(
            old
            or dict(
                first_page_id=page["page_id"], first_page_sha256=page["page_sha256"]
            ),
            **gap,
            status="unresolved",
            last_page_id=page["page_id"],
            last_page_sha256=page["page_sha256"],
        )
    receipts = [
        accepted_receipt(item["event_id"], item["envelope"]) for item in page["items"]
    ]
    for receipt in receipts:
        if receipt["event_id"] in audit:
            audit[receipt["event_id"]].update(
                status="accepted_metadata", receipt_id=receipt["receipt_id"]
            )
    result = dict(
        source=page["source"],
        scope=page["scope"],
        flavor=flavor,
        consumer=deepcopy(consumer),
        gap_audit=audit,
    )
    if page["items"] or page["gaps"]:
        result.update(
            page_id=page["page_id"],
            page_sha256=page["page_sha256"],
            previous_cursor=page["previous_cursor"],
            next_cursor=page["next_cursor"],
            ack_pending=True,
            receipts=receipts,
        )
    return result


class NativeIngress:
    """Owner-injected transport only; Host calls poll while holding .host.lock.

    Transport methods accept authorize=callback(envelope). read_router_page
    returns a validated metadata page; lookup returns the exact accepted receipt
    or None. ack returns exactly {status:'accepted',page_id,next_cursor}.
    A lookup can detect receipt conflicts, but never substitutes for page ack.
    """

    def __init__(
        self, finance_source, *, transport, descriptor_reader=None, flavor="finance"
    ):
        if not isinstance(flavor, str) or flavor not in OWNER_GAP_CODES:
            raise ValueError("native_ingress_flavor_invalid")
        self.flavor = flavor
        self.finance, self.transport = finance_source, transport
        reader = getattr(finance_source, "read_descriptor", None)
        self.descriptor_reader = (
            descriptor_reader
            if descriptor_reader is not None
            else (lambda event: reader(event, include_history=True))
            if callable(reader)
            else None
        )
        self.source, self.scope = finance_source.source, finance_source.scope

    def consumer_descriptor(self):
        binding = getattr(self.transport, "consumer_binding", None)
        if not callable(binding):
            raise NativeConsumerConflict("native_consumer_identity_required")
        return consumer_identity(
            binding(), source=self.source, scope=self.scope, flavor=self.flavor
        )

    def check_consumer(self, producer):
        expected = self.consumer_descriptor()
        coverage = producer.coverage(self.source)
        if coverage is None:
            return expected
        native = coverage.get("native_ingress")
        if not isinstance(native, dict) or "consumer" not in native:
            raise NativeConsumerConflict("native_consumer_migration_required")
        if (
            native.get("source") != self.source
            or native.get("scope") != self.scope
            or native.get("flavor", "finance") != self.flavor
            or native["consumer"] != expected
        ):
            raise NativeConsumerConflict("native_consumer_conflict")
        return expected

    def authorize(self, source, stage, agent=None):
        return self.finance.authorize(source, stage, agent)

    def authorize_evidence(self, event, stage, agent=None):
        return self.finance.authorize_evidence(event, stage, agent)

    def read_original(self, event, *, agent):
        return self.finance.read_original(event, agent=agent)

    def checked_envelope(self, envelope):
        if (
            not isinstance(envelope, dict)
            or envelope.get("source") != self.source
            or envelope.get("scope") != self.scope
        ):
            raise ValueError("native_ingress_source_denied")
        event = dict(
            source=self.source,
            scope=self.scope,
            record=envelope["record"],
            version=envelope["version"],
            evidence=envelope["original"],
        )
        before = self.finance.authorize(self.source, "ingest", None)
        if not callable(self.descriptor_reader):
            raise ValueError("native_ingress_descriptor_required")
        proof = self.descriptor_reader(event)
        expected = dict(
            reference=envelope["original"],
            version=envelope["version"],
            projection_hash=envelope["projection_hash"],
            kind=envelope["kind"],
            original_available=envelope.get("original_available", True),
        )
        if (
            not isinstance(proof, dict)
            or set(proof) != set(expected)
            or any(
                proof[key] != expected[key]
                for key in expected
                if key != "original_available"
            )
            or type(proof["original_available"]) is not bool
        ):
            raise ValueError("native_ingress_descriptor_mismatch")
        after = self.finance.authorize(self.source, "ingest", None)
        if after != before:
            raise ValueError("native_ingress_authority_changed")
        projected = deepcopy(envelope)
        projected["original_available"] = (
            envelope.get("original_available", True) and proof["original_available"]
        )
        return projected, after

    def authorize_envelope(self, envelope):
        return self.checked_envelope(envelope)[1]

    def authorize_accepted_metadata(self, envelope):
        if (
            not isinstance(envelope, dict)
            or envelope.get("source") != self.source
            or envelope.get("scope") != self.scope
        ):
            raise ValueError("native_ingress_source_denied")
        return self.finance.authorize(self.source, "ingest", None)

    def _recover_ack(self, producer, pending):
        expected = self.check_consumer(producer)
        if pending.get("consumer") != expected:
            raise NativeConsumerConflict("native_consumer_conflict")
        if (
            pending.get("source") != self.source
            or pending.get("scope") != self.scope
            or pending.get("flavor", "finance") != self.flavor
        ):
            raise ValueError("native_ingress_scope_conflict")
        state = producer.workflow._read()["producer"]
        before = self.authorize(self.source, "ingest")
        for receipt in pending["receipts"]:
            candidates = [
                c
                for c in state["candidates"].values()
                if c["source"] == receipt["source"]
                and c["scope"] == self.scope
                and c["change"]["record"] == receipt["record"]
                and c["change"]["version"] == receipt["version"]
            ]
            if (
                len(candidates) != 1
                or candidates[0].get("native_ingress", {}).get("receipt") != receipt
            ):
                raise ValueError("native_ingress_receipt_conflict")
            known = self.transport.lookup_router_receipt(
                receipt["event_id"], authorize=self.authorize_accepted_metadata
            )
            if known is not None and known != receipt:
                raise ValueError("native_ingress_receipt_conflict")
        # Even matching event receipts do not prove this page cursor advanced.
        proof = self.transport.ack_router_page(
            pending["page_id"],
            pending["page_sha256"],
            deepcopy(pending["receipts"]),
            authorize=self.authorize_accepted_metadata,
        )
        if proof != dict(
            page_id=pending["page_id"],
            next_cursor=pending["next_cursor"],
            status="accepted",
        ):
            return False
        if self.authorize(self.source, "ingest") != before:
            raise ValueError("native_ingress_authority_changed")
        producer.ack_native_page(self.source, proof, pending["receipts"])
        return True

    def poll(self, producer, *, limit):
        self.check_consumer(producer)
        self.authorize(self.source, "ingest")
        producer.bind_native_consumer(self)
        current = producer.coverage(self.source)
        pending = current["native_ingress"]
        if pending.get("ack_pending", False):
            acknowledged = self._recover_ack(producer, pending)
            return dict(stop=True, acknowledged=acknowledged)
        cursor = current.get("cursor")
        page = self.transport.read_router_page(
            cursor, limit, authorize=self.authorize_envelope
        )
        page = validate_page(
            page,
            source=self.source,
            scope=self.scope,
            previous_cursor=cursor,
            limit=limit,
            flavor=self.flavor,
        )
        producer.prepare(self.source, page, previous_cursor=cursor, native_ingress=self)
        if not page["items"] and not page["gaps"]:
            return dict(stop=True, acknowledged=True, idle=True)
        pending = producer.coverage(self.source)["native_ingress"]
        acknowledged = self._recover_ack(producer, pending)
        return dict(
            stop=not acknowledged or not page["items"] or page["next_cursor"] == cursor,
            acknowledged=acknowledged,
        )
