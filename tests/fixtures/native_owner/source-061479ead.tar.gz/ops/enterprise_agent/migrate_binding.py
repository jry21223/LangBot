"""Explicit, offline source-add migration; never starts a Host or performs network I/O."""

from copy import deepcopy
import argparse
from hashlib import sha256
import fcntl
import json
import os
from pathlib import Path
import re
import sqlite3
import stat
from urllib.parse import quote

from ._ledger import private_file
from .workflow import identity


def bundle_binding(bundle):
    return sha256(
        json.dumps([bundle["host"], bundle["connector"]], sort_keys=True).encode()
    ).hexdigest()


def _digest(value):
    return sha256(
        json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()


def _extension(old, new, key):
    before, after = old[key], new[key]
    if (
        not isinstance(before, list)
        or not isinstance(after, list)
        or after[: len(before)] != before
    ):
        raise ValueError("migration_existing_scope_changed")
    names = [item["source"] for item in after]
    if len(set(names)) != len(names) or len(after) <= len(before):
        raise ValueError("migration_source_add_required")
    return {item["source"] for item in after[len(before) :]}


def _validate(old, new):
    if set(old) != {"host", "reader", "connector"} or set(new) != set(old):
        raise ValueError("migration_bundle_invalid")
    if old["connector"] != new["connector"]:
        raise ValueError("migration_connector_identity_changed")
    added = _extension(old["host"], new["host"], "sources")
    if added != _extension(old["reader"], new["reader"], "sources"):
        raise ValueError("migration_source_binding_mismatch")
    for source in new["host"]["sources"][len(old["host"]["sources"]) :]:
        if source.get("kind", "wecom") != "wecom":
            raise ValueError("migration_only_wecom_source_add_supported")
        binding = next(
            item
            for item in new["reader"]["sources"]
            if item["source"] == source["source"]
        )
        if any(
            source.get(key) != binding.get(key)
            for key in ("source", "scope", "principal", "endpoint")
        ):
            raise ValueError("migration_source_binding_mismatch")
        if binding.get("workspace") != new["host"].get("workspace"):
            raise ValueError("migration_source_binding_mismatch")
    for key in set(old["host"]) | set(new["host"]):
        if key not in {"sources", "gd", "readonly_business", "source_document"} and old["host"].get(key) != new["host"].get(
            key
        ):
            raise ValueError("migration_host_configuration_changed")
    if old["host"].get("gd") is not None and old["host"]["gd"] != new["host"].get("gd"):
        raise ValueError("migration_gd_binding_changed")
    if old['host'].get('source_document') not in (None,{'enabled':False}) and old['host']['source_document']!=new['host'].get('source_document'):
        raise ValueError('migration_source_document_binding_changed')
    if old['host'].get('readonly_business') not in (None,{'enabled':False}) and old['host']['readonly_business']!=new['host'].get('readonly_business'):
        raise ValueError('migration_business_binding_changed')
    for key in set(old["reader"]) | set(new["reader"]):
        if key not in {"sources", "goals", "goal_scopes", "readonly_business", "source_document"} and old["reader"].get(
            key
        ) != new["reader"].get(key):
            raise ValueError("migration_reader_configuration_changed")
    old_goals, new_goals = old["reader"]["goals"], new["reader"]["goals"]
    if new_goals[: len(old_goals)] != old_goals:
        raise ValueError("migration_existing_catalog_changed")
    old_scopes = old["reader"].get("goal_scopes")
    scopes = new["reader"].get("goal_scopes")
    if old_scopes is not None and (
        scopes is None or scopes[: len(old_scopes)] != old_scopes
    ):
        raise ValueError("migration_existing_catalog_scope_changed")
    if old_scopes is None and scopes is not None:
        for source in old["host"]["sources"]:
            expected = dict(
                source=source["source"],
                scope=source["scope"],
                goal_ids=[goal["id"] for goal in old_goals],
                require_gd=False,
            )
            if source.get("kind") != "personal-wechat" or expected not in scopes:
                raise ValueError("migration_existing_catalog_scope_changed")


def _catalog(reader):
    return (
        identity(reader["goals"], reader["goal_scopes"])
        if "goal_scopes" in reader
        else identity(reader["goals"])
    )


def _read(db):
    return json.loads(db.execute("SELECT value FROM state WHERE id=1").fetchone()[0])


def _require_phase_binding(state, bundle):
    if (state["producer"].get("host_binding") != bundle_binding(bundle)
            or state["producer"].get("goal_catalog") != _catalog(bundle["reader"])):
        raise ValueError("migration_phase_binding_drift")


def _read_config(filename):
    fd = os.open(filename, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "r") as source:
        info = os.fstat(source.fileno())
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_uid != os.getuid()
            or info.st_mode & 0o077
            or info.st_nlink != 1
        ):
            raise ValueError("private_configuration_required")
        raw = source.read(131073)
        if len(raw) > 131072:
            raise ValueError("migration_configuration_too_large")
        return json.loads(raw)


def _preserved_digest(state):
    value = deepcopy(state)
    value.pop("binding_migration", None)
    value["producer"].pop("host_binding", None)
    value["producer"].pop("goal_catalog", None)
    return _digest(value)


def _save(db, expected, proposed):
    db.execute("BEGIN IMMEDIATE")
    try:
        if _read(db) != expected:
            raise ValueError("migration_concurrent_state_change")
        db.execute("UPDATE state SET value=? WHERE id=1", (json.dumps(proposed),))
        db.commit()
    except BaseException:
        db.rollback()
        raise


def migrate_binding(
    database,
    migration_id,
    old_bundle,
    new_bundle,
    *,
    files=None,
    apply=False,
    quiesced=False,
    checkpoint=None,
):
    """Migrate a stopped runtime; `quiesced` is an operator attestation, not a lock.

    files maps changed bundle role to its existing private config path. The same
    migration ID resumes after a crash. A Host lock does not stop the connector;
    the owner must stop every writer before apply. Preview performs no writes.
    """
    if not re.fullmatch(r"[A-Za-z0-9_.-]{1,120}", migration_id):
        raise ValueError("migration_id_required")
    _validate(old_bundle, new_bundle)
    from .run_host import validate_source_admission

    validate_source_admission(new_bundle["host"], new_bundle["reader"])
    business=new_bundle['host'].get('readonly_business')
    if business and business.get('enabled') is True:
        if business['private_root']!=new_bundle['connector'].get('stateRoot'):
            raise ValueError('readonly_business_private_root_mismatch')
        if old_bundle['host'].get('readonly_business') in (None,{'enabled':False}):
            added={s['source'] for s in new_bundle['host']['sources'][len(old_bundle['host']['sources']):]}
            if not {s['source'] for s in business['sources']} <= added:
                raise ValueError('migration_business_scope_must_be_new_source')
    document=new_bundle['host'].get('source_document')
    if document and document.get('enabled') is True:
        if document['private_root']!=new_bundle['connector'].get('stateRoot'):
            raise ValueError('source_document_private_root_mismatch')
        if old_bundle['host'].get('source_document') in (None,{'enabled':False}):
            added={(s['source'],s['scope']) for s in new_bundle['host']['sources'][len(old_bundle['host']['sources']):]}
            if not {(s['source'],s['scope']) for s in document['sources']}<=added:
                raise ValueError('migration_source_document_scope_must_be_new_source')
    paths = {key: str(Path(value).absolute()) for key, value in (files or {}).items()}
    changed = {key for key in old_bundle if old_bundle[key] != new_bundle[key]}
    if paths and set(paths) != changed:
        raise ValueError("migration_file_set_mismatch")
    if apply and (not quiesced or set(paths) != changed):
        raise ValueError("migration_stopped_runtime_and_files_required")
    plan = dict(
        id=migration_id,
        old_digest=_digest(old_bundle),
        new_digest=_digest(new_bundle),
        files=paths,
    )
    path = Path(database)
    if (
        path.is_symlink()
        or not path.is_file()
        or path.stat().st_uid != os.getuid()
        or path.stat().st_mode & 0o077
    ):
        raise ValueError("private_state_required")
    lock = None
    if apply:
        lock = private_file(str(path) + ".host.lock")
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            os.close(lock)
            raise ValueError("migration_host_busy") from None
    db = sqlite3.connect(
        "file:" + quote(str(path), safe="/") + ("?mode=rw" if apply else "?mode=ro"),
        uri=True,
    )
    try:
        state = _read(db)
        prior = state.get("binding_migration")
        if prior and any(prior.get(key) != value for key, value in plan.items()):
            raise ValueError("migration_operation_conflict")
        if prior:
            phase = prior.get("phase")
            if phase not in {"PREPARED", "STATE_COMMITTED", "FILES_COMMITTED", "VERIFIED"}:
                raise ValueError("migration_phase_invalid")
            _require_phase_binding(state, old_bundle if phase == "PREPARED" else new_bundle)
        if (
            prior
            and prior["phase"] != "VERIFIED"
            and prior.get("preserved_sha256") != _preserved_digest(state)
        ):
            raise ValueError("migration_concurrent_state_change")
        if prior and prior["phase"] == "VERIFIED":
            if state["producer"]["host_binding"] != bundle_binding(new_bundle) or state[
                "producer"
            ]["goal_catalog"] != _catalog(new_bundle["reader"]):
                raise ValueError("migration_new_binding_mismatch")
            for role, filename in paths.items():
                if _read_config(filename) != new_bundle[role]:
                    raise ValueError("migration_file_drift")
            return deepcopy(prior)
        if not prior:
            producer = state["producer"]
            if producer["host_binding"] != bundle_binding(old_bundle) or producer[
                "goal_catalog"
            ] != _catalog(old_bundle["reader"]):
                raise ValueError("migration_old_binding_mismatch")
            if any(
                action.get("status") == "delivery_unknown"
                or action.get("stage") == "understand"
                and action.get("status") in {"pending", "sent"}
                for action in state["outbox"].values()
            ):
                raise ValueError("migration_unsettled_understanding")
            if not apply:
                return dict(plan, phase="PREVIEW")
            for role, filename in paths.items():
                if _read_config(filename) != old_bundle[role]:
                    raise ValueError("migration_file_drift")
            proposed = deepcopy(state)
            proposed["binding_migration"] = dict(
                plan, phase="PREPARED", preserved_sha256=_preserved_digest(state)
            )
            _save(db, state, proposed)
            state = proposed
            if checkpoint:
                checkpoint("PREPARED")
        if not apply:
            return deepcopy(state["binding_migration"])
        if state["binding_migration"]["phase"] == "PREPARED":
            proposed = deepcopy(state)
            producer = proposed["producer"]
            producer["host_binding"] = bundle_binding(new_bundle)
            producer["goal_catalog"] = _catalog(new_bundle["reader"])
            projectors = producer["configuration"].setdefault("projectors", {})
            # WeCom uses the default projector and adds no explicit projector key.
            if not projectors:
                producer["configuration"].pop("projectors", None)
            proposed["binding_migration"]["phase"] = "STATE_COMMITTED"
            _save(db, state, proposed)
            state = proposed
            if checkpoint:
                checkpoint("STATE_COMMITTED")
        for role, filename in paths.items():
            target = Path(filename)
            present = _read_config(target)
            if present == new_bundle[role]:
                continue
            if present != old_bundle[role]:
                raise ValueError("migration_file_drift")
            temporary = target.with_name(target.name + "." + migration_id + ".staged")
            # A crash can leave this operation's partially written staged file.
            # Validate ownership/mode and rewrite it; never follow a symlink.
            fd = private_file(temporary)
            with os.fdopen(fd, "w") as output:
                output.truncate(0)
                json.dump(new_bundle[role], output, ensure_ascii=False)
                output.flush()
                os.fsync(output.fileno())
            os.replace(temporary, target)
            parent = os.open(target.parent, os.O_RDONLY)
            try:
                os.fsync(parent)
            finally:
                os.close(parent)
            if checkpoint:
                checkpoint("FILE_" + role)
        if state["binding_migration"]["phase"] != "FILES_COMMITTED":
            proposed = deepcopy(state)
            proposed["binding_migration"]["phase"] = "FILES_COMMITTED"
            _save(db, state, proposed)
            state = proposed
            if checkpoint:
                checkpoint("FILES_COMMITTED")
        proposed = deepcopy(state)
        _require_phase_binding(state, new_bundle)
        for role, filename in paths.items():
            if _read_config(filename) != new_bundle[role]:
                raise ValueError("migration_file_drift")
        proposed["binding_migration"]["phase"] = "VERIFIED"
        _save(db, state, proposed)
        return deepcopy(proposed["binding_migration"])
    finally:
        db.close()
        if lock is not None:
            fcntl.flock(lock, fcntl.LOCK_UN)
            os.close(lock)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--database", required=True)
    parser.add_argument("--migration-id", required=True)
    parser.add_argument("--old-bundle", required=True)
    parser.add_argument("--new-bundle", required=True)
    parser.add_argument("--host-config", required=True)
    parser.add_argument("--reader-config", required=True)
    parser.add_argument("--apply", action="store_true", help="apply the reviewed source-add plan")
    parser.add_argument("--quiesced", action="store_true", help="operator confirms all runtime writers are stopped")
    args = parser.parse_args()
    try:
        old, new = _read_config(args.old_bundle), _read_config(args.new_bundle)
        if Path(args.database).absolute() != Path(old["host"]["state"]).absolute():
            raise ValueError("migration_state_path_mismatch")
        reader_reference = old["host"].get("understanding", {}).get("reader_config")
        if reader_reference is not None and Path(args.reader_config).absolute() != Path(reader_reference).absolute():
            raise ValueError("migration_reader_path_mismatch")
        receipt = migrate_binding(
            args.database, args.migration_id, old, new,
            files={"host": args.host_config, "reader": args.reader_config},
            apply=args.apply, quiesced=args.quiesced,
        )
    except (ValueError, OSError, sqlite3.Error, TypeError, KeyError, UnicodeError):
        parser.exit(1, "Migration refused or interrupted; inspect the same migration ID before retrying.\n")
    # Bundle contents and private configuration paths never enter terminal output.
    print(json.dumps({key: receipt[key] for key in ("id", "phase", "old_digest", "new_digest")}))


if __name__ == "__main__":
    main()
