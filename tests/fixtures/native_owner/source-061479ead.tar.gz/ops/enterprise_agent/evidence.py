"""Minimal evidence identity shared by GD publications and personal notifications."""
from collections.abc import Mapping
from typing import TypedDict


class EvidenceReference(TypedDict):
    source: str
    record: str
    version: str
    evidence: str


def evidence_reference(evidence: Mapping[str, object]) -> EvidenceReference:
    try:
        reference = {k: evidence[k] for k in EvidenceReference.__annotations__}
        if any(not isinstance(v, str) or not v for v in reference.values()):
            raise ValueError()
        return EvidenceReference(**reference)
    except (KeyError, TypeError, ValueError):
        raise ValueError("invalid_evidence_reference") from None
