"""Opt-in personal-WeChat text source over an existing wx event observer.

No login, daemon creation, business tool, or outbound message is implemented here.
The source has its own durable cursor; the existing observer remains untouched.
"""

import argparse
from hashlib import sha256
import hmac
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import time
from urllib.parse import parse_qs, urlsplit

from .input_reader import read_private


def digest(value):
    return sha256(
        json.dumps(
            value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
        ).encode()
    ).hexdigest()


REQUEST_READ_SECONDS = 5.0
REQUEST_HEADER_BYTES = 64 * 1024


class _RequestReader:
    """Bound request lines, headers and body reads by one absolute receipt deadline."""

    def __init__(self, raw, connection):
        self.raw, self.connection = raw, connection
        self.deadline = time.monotonic() + REQUEST_READ_SECONDS
        self.buffer = bytearray()
        self.header_bytes = 0
        self.headers = True

    def _remaining(self):
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError("source_request_expired")
        return remaining

    def _fill(self):
        self.connection.settimeout(self._remaining())
        data = self.raw.read1(8192)
        self.buffer.extend(data)
        return bool(data)

    def readline(self, limit=-1):
        while True:
            self._remaining()
            newline = self.buffer.find(b"\n")
            if (
                self.headers
                and newline < 0
                and self.header_bytes + len(self.buffer) >= REQUEST_HEADER_BYTES
            ):
                raise TimeoutError("source_headers_too_large")
            count = newline + 1 if newline >= 0 else len(self.buffer)
            if limit >= 0:
                count = min(count, limit)
            if newline >= 0 or (limit >= 0 and count == limit):
                break
            if not self._fill():
                count = len(self.buffer) if limit < 0 else min(len(self.buffer), limit)
                break
        result = bytes(self.buffer[:count])
        del self.buffer[:count]
        if self.headers:
            self.header_bytes += len(result)
            if self.header_bytes > REQUEST_HEADER_BYTES:
                raise TimeoutError("source_headers_too_large")
            if result in {b"\r\n", b"\n"}:
                self.headers = False
        return result

    def read(self, length):
        result = bytearray()
        while len(result) < length:
            self._remaining()
            if not self.buffer and not self._fill():
                break
            count = min(length - len(result), len(self.buffer))
            result.extend(self.buffer[:count])
            del self.buffer[:count]
        return bytes(result)

    def close(self):
        self.raw.close()


class WechatJournal:
    def __init__(self, path, *, account, thread, start_cursor):
        self.account, self.thread = account, thread
        self.db = sqlite3.connect(path)
        os.chmod(path, 0o600)
        self.db.execute("CREATE TABLE IF NOT EXISTS binding(value TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS progress(cursor INTEGER NOT NULL)")
        self.db.execute(
            "CREATE TABLE IF NOT EXISTS messages("
            "seq INTEGER PRIMARY KEY, record TEXT NOT NULL, version TEXT NOT NULL, "
            "reference TEXT UNIQUE NOT NULL, change_json TEXT NOT NULL, body TEXT NOT NULL)"
        )
        binding = json.dumps([account, thread, start_cursor])
        if self.db.execute("SELECT value FROM binding").fetchone() is None:
            self.db.execute("INSERT INTO binding VALUES(?)", (binding,))
            self.db.execute("INSERT INTO progress VALUES(?)", (start_cursor,))
            self.db.commit()
        if self.db.execute("SELECT value FROM binding").fetchone()[0] != binding:
            raise ValueError("source_binding_drift")

    def close(self):
        self.db.close()

    def collect(self, events, read_message, *, max_events=1000):
        cursor = self.db.execute("SELECT cursor FROM progress").fetchone()[0]
        examined = 0
        with Path(events).open() as stream:
            for line in stream:
                if not line.endswith("\n"):
                    break  # observer may still be appending this frame
                event = json.loads(line)
                sequence = int(event["cursor"])
                if sequence <= cursor:
                    continue
                if examined >= max_events:
                    break
                examined += 1
                data = event.get("data", {})
                selected = (
                    event.get("accountId") == self.account
                    and event.get("kind") == "message.committed"
                    and data.get("threadId") == self.thread
                    and data.get("direction") == "incoming"
                )
                with self.db:
                    if selected:
                        message = read_message(self.thread, data["messageId"])
                        if any(
                            message.get(k) != v
                            for k, v in {
                                "accountId": self.account,
                                "threadId": self.thread,
                                "direction": "incoming",
                                "id": data["messageId"],
                            }.items()
                        ):
                            raise ValueError("message_binding_mismatch")
                        if message.get("type") == 1:
                            self._save(message, sequence, event["createdAt"])
                    self.db.execute("UPDATE progress SET cursor=?", (sequence,))
                cursor = sequence
        return examined

    def _save(self, message, sequence, observed):
        body = message.get("body")
        if (
            not isinstance(body, str)
            or not body
            or len(body.encode()) > 16384
            or not message.get("senderId")
            or not message.get("serverId")
        ):
            raise ValueError("text_original_unavailable")
        saved = dict(
            account_id=self.account,
            thread_id=self.thread,
            message_id=message["id"],
            sender_id=message["senderId"],
            server_id=str(message["serverId"]),
            direction="incoming",
            message_type="text",
            body_available=True,
        )
        record = digest([self.account, self.thread, message["id"]])
        version = digest([saved, message["createdAt"], body])
        reference = f"wechat:message/{record}/{version}"
        change = dict(
            record=record,
            version=version,
            sequence=sequence,
            kind="created",
            business_at=message["createdAt"],
            observed_at=observed,
            original=reference,
            goal_reference=None,
            saved=saved,
            original_available=True,
        )
        change["projection_hash"] = digest(change)
        old = self.db.execute(
            "SELECT body FROM messages WHERE reference=?", (reference,)
        ).fetchone()
        if old is None:
            self.db.execute(
                "INSERT INTO messages VALUES(?,?,?,?,?,?)",
                (sequence, record, version, reference, json.dumps(change), body),
            )
        elif old[0] != body:
            raise ValueError("source_version_conflict")

    def page(self, cursor, *, source, scope, limit):
        if cursor is not None and (
            not isinstance(cursor, str) or not cursor.isdecimal()
        ):
            raise ValueError("invalid_source_cursor")
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("invalid_page_limit")
        position = int(cursor or "0")
        high = self.db.execute("SELECT cursor FROM progress").fetchone()[0]
        if position > high:
            raise ValueError("invalid_source_cursor")
        rows = self.db.execute(
            "SELECT seq,change_json FROM messages WHERE seq>? ORDER BY seq LIMIT ?",
            (position, limit),
        ).fetchall()
        items = [dict(json.loads(row[1]), source=source, scope=scope) for row in rows]
        next_cursor = str(rows[-1][0] if len(rows) == limit else high)
        return dict(
            source=source,
            scope=scope,
            previous_cursor=cursor,
            next_cursor=next_cursor,
            complete_page=True,
            items=items,
            coverage="success",
            gaps=[
                "history_before_activation_unverified",
                "non_text_not_projected",
                "recall_not_qualified",
            ],
        )

    def original(self, reference):
        row = self.db.execute(
            "SELECT version,body FROM messages WHERE reference=?", (reference,)
        ).fetchone()
        if row is None:
            raise ValueError("original_unavailable")
        return dict(reference=reference, version=row[0], content=row[1])


def configuration(path):
    config = json.loads(read_private(path))
    required = {
        "version",
        "enabled",
        "account",
        "thread",
        "start_cursor",
        "events",
        "wx",
        "database",
        "listen_port",
        "source",
        "scope",
        "workspace",
        "principal",
        "agents",
        "read_token_file",
    }
    if (
        set(config) - {"native"} != required
        or config["version"] != 1
        or type(config["enabled"]) is not bool
        or not config["agents"]
        or len(set(config["agents"])) != len(config["agents"])
        or type(config["start_cursor"]) is not int
        or config["start_cursor"] < 0
        or type(config["listen_port"]) is not int
        or not 1024 <= config["listen_port"] <= 65535
    ):
        raise ValueError("invalid_wechat_source_configuration")
    for key in ("events", "wx", "database", "read_token_file"):
        if not Path(config[key]).is_absolute():
            raise ValueError("absolute_source_path_required")
    if "native" in config:
        from .wechat_native_http import validate_native

        validate_native(config)
    return config


def read_wx(config, thread, message):
    run = subprocess.run(
        [config["wx"], "--json", "messages", "get", thread, message],
        capture_output=True,
        text=True,
        timeout=15,
        env={"PATH": "/usr/bin:/bin", "NO_PROXY": "*", "no_proxy": "*"},
    )
    if run.returncode:
        raise ValueError("wechat_message_unavailable")
    return json.loads(run.stdout)


def source_server(path, journal, *, native_owner=None):
    initial = configuration(path)
    from .wechat_native_http import NativeError, NativeService

    native = NativeService(
        initial, current_configuration=lambda: configuration(path), owner=native_owner
    )

    class Handler(BaseHTTPRequestHandler):
        def setup(self):
            super().setup()
            self.rfile = _RequestReader(self.rfile, self.connection)

        def log_message(self, *_):
            pass

        def do_GET(self):
            if urlsplit(self.path).path.startswith("/native/"):
                self.native_request("GET")
                return
            try:
                config = configuration(path)
                if not config["enabled"] or config != initial:
                    raise PermissionError()
                token = read_private(config["read_token_file"], 4096).decode().strip()
                if len(token) < 32 or not hmac.compare_digest(
                    self.headers.get("Authorization", ""), "Bearer " + token
                ):
                    raise PermissionError()
                query = parse_qs(urlsplit(self.path).query, keep_blank_values=True)
                if any(len(v) != 1 for v in query.values()):
                    raise PermissionError()
                args = {k: v[0] for k, v in query.items()}
                if (
                    any(
                        args.get(k) != config[k]
                        for k in ("source", "scope", "workspace")
                    )
                    or self.headers.get("X-Operator") != config["principal"]
                ):
                    raise PermissionError()
                route = urlsplit(self.path).path
                allowed = {
                    "/changes": {"cursor", "limit"},
                    "/authority": {"stage", "agent", "reference"},
                    "/original": {"reference"},
                }
                if (
                    route not in allowed
                    or set(args) - {"source", "scope", "workspace"} - allowed[route]
                ):
                    raise PermissionError()
                if route == "/changes":
                    value = journal.page(
                        args.get("cursor"),
                        source=config["source"],
                        scope=config["scope"],
                        limit=int(args.get("limit", "100")),
                    )
                elif route == "/original":
                    value = journal.original(args["reference"])
                else:
                    stage, agent = args.get("stage"), args.get("agent")
                    if (
                        stage not in {"ingest", "dispatch", "result", "display"}
                        or agent is not None
                        and agent not in config["agents"]
                        or stage in {"dispatch", "result"}
                        and agent is None
                    ):
                        raise PermissionError()
                    if "reference" in args:
                        journal.original(args["reference"])
                    value = dict(
                        source=config["source"],
                        scope=config["scope"],
                        workspace=config["workspace"],
                        principal=config["principal"],
                        agent=agent,
                        revision=digest(config),
                        active=True,
                        read_only=True,
                        workspace_allowed=True,
                    )
                raw, status = json.dumps(value).encode(), 200
            except Exception:
                raw, status = b'{"error":"source_unavailable"}', 403
            self.send_response(status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_POST(self):
            self.native_request("POST")

        def native_request(self, method):
            try:
                query = parse_qs(urlsplit(self.path).query, keep_blank_values=True)
                if any(len(values) != 1 for values in query.values()):
                    raise NativeError(403)
                args = {key: values[0] for key, values in query.items()}
                route = urlsplit(self.path).path
                body = None
                if method == "POST":
                    # Authenticate before reading a potentially large derived result.
                    native.authorize(method, route, self.headers, args)
                    if (
                        self.headers.get("Transfer-Encoding") is not None
                        or len(self.headers.get_all("Content-Length", [])) != 1
                        or self.headers.get("Content-Type", "").split(";", 1)[0]
                        != "application/json"
                    ):
                        raise NativeError(403)
                    length = int(self.headers["Content-Length"])
                    if not 0 < length <= 32 * 1024**2:
                        raise NativeError(413)
                    body = json.loads(self.rfile.read(length))
                value = native.dispatch(method, route, self.headers, args, body)
                if isinstance(value, tuple):
                    raw, mime = value
                else:
                    raw, mime = (
                        json.dumps(value, ensure_ascii=False, allow_nan=False).encode(),
                        "application/json",
                    )
                status = 200
            except (TimeoutError, OSError):
                self.close_connection = True
                return
            except NativeError as error:
                raw, mime, status = (
                    b'{"error":"native_source_unavailable"}',
                    "application/json",
                    error.status,
                )
            except Exception:
                raw, mime, status = (
                    b'{"error":"native_source_unavailable"}',
                    "application/json",
                    403,
                )
            self.send_response(status)
            self.send_header("Content-Type", mime)
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(raw)))
            if mime != "application/json":
                self.send_header("X-Content-SHA256", sha256(raw).hexdigest())
            self.end_headers()
            self.wfile.write(raw)

    server = HTTPServer(("127.0.0.1", initial["listen_port"]), Handler)
    server.native_service = native
    return server


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--serve", action="store_true")
    args = parser.parse_args()
    os.umask(0o077)
    config = configuration(args.config)
    if not config["enabled"]:
        print('{"status":"disabled"}')
        return
    journal = WechatJournal(
        config["database"],
        account=config["account"],
        thread=config["thread"],
        start_cursor=config["start_cursor"],
    )
    try:
        if not args.serve:
            if config.get("native", {}).get("enabled") is True:
                from .wechat_native_http import NativeService

                service = NativeService(
                    config, current_configuration=lambda: configuration(args.config)
                )
                count = service.collect(config["events"])
            else:
                count = journal.collect(
                    config["events"], lambda t, m: read_wx(config, t, m)
                )
            print(json.dumps(dict(examined=count, status="collected")))
            return
        server = source_server(args.config, journal)
        server.timeout = 1
        try:
            while configuration(args.config) == config:
                if server.native_service.enabled:
                    try:
                        server.native_service.collect(config["events"])
                    except (OSError, ValueError):
                        # Keep scoped metadata reachable while upstream freshness is unknown.
                        # NativeService retains failure time and never advances failed input.
                        pass
                else:
                    journal.collect(
                        config["events"], lambda t, m: read_wx(config, t, m)
                    )
                server.handle_request()
        finally:
            server.server_close()
    finally:
        journal.close()


if __name__ == "__main__":
    main()
