"""Current SERVICE-only business MCP reads, with no ambient identity or endpoint."""

from copy import deepcopy
from functools import wraps
import json
import re
import time
from uuid import UUID
from urllib.parse import urlsplit

from ._http_budget import current_deadline, open_http
from .readonly_private import read_private_bytes
from .source_http import _endpoint, _token


def validated_server_request_id(value):
    """Preserve the tools/call server audit ID verbatim, never invent one."""
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", value):
        raise ValueError("readonly_business_request_id_invalid")
    return value


def _operation_deadline(operation):
    """Initialize/list/call/refresh share one budget, capped by the Host budget."""

    @wraps(operation)
    def bounded(self, *args, **kwargs):
        deadline = min(
            time.monotonic() + self.timeout, current_deadline.get() or float("inf")
        )
        binding = current_deadline.set(deadline)
        try:
            return operation(self, *args, **kwargs)
        finally:
            current_deadline.reset(binding)

    return bounded


class QueryOutcomeUnknown(ValueError):
    """A read was attempted but no currently authorized receipt was established."""


class ReadOnlyBusiness:
    def __init__(self, *, endpoint, token_file, service_id, timeout=10):
        if (
            not isinstance(endpoint, str)
            or len(endpoint) > 2048
            or not isinstance(token_file, str)
            or not isinstance(service_id, str)
        ):
            raise ValueError("readonly_business_configuration_invalid")
        _endpoint(endpoint)
        if urlsplit(endpoint).path != "/mcp/business":
            raise ValueError("readonly_business_configuration_invalid")
        if str(UUID(service_id)) != service_id or not 0 < timeout <= 30:
            raise ValueError("readonly_business_configuration_invalid")
        self.endpoint, self.token_file, self.service_id, self.timeout = (
            endpoint,
            token_file,
            service_id,
            timeout,
        )

    def _session(self):
        from ops.hermes.production_reminders import StageReminderMcp

        token = _token(read_private_bytes(self.token_file, 4096).decode().strip())

        def request(frame, **_):
            response = open_http(
                frame.full_url,
                method=frame.get_method(),
                data=frame.data,
                headers=dict(frame.header_items()),
                timeout=self.timeout,
                limit=4 * 1024 * 1024,
            )
            if response.status != 200:
                response.close()
                raise ValueError("readonly_business_unavailable")
            return response

        client = StageReminderMcp(
            dict(url=self.endpoint, headers={"Authorization": "Bearer " + token}),
            run=request,
        )
        client.connect()
        return client

    def _identity(self, result):
        meta = result.get("_meta", {})
        if not isinstance(meta, dict):
            raise ValueError("readonly_business_service_mismatch")
        if (
            meta.get("subject_type") != "SERVICE"
            or meta.get("service_id") != self.service_id
        ):
            raise ValueError("readonly_business_service_mismatch")
        required = (
            "service_id",
            "client_id",
            "authorization_version",
            "credential_version",
            "mcp_policy_version",
        )
        if any(meta.get(key) is None for key in required):
            raise ValueError("readonly_business_identity_missing")
        return {key: meta[key] for key in required}

    def _catalog(self, client):
        result = client._post(
            dict(jsonrpc="2.0", id="readonly-catalog", method="tools/list", params={}),
            expect_result=True,
        )
        identity = self._identity(result)
        manifest = result["_meta"].get("business_manifest", {})
        if (
            manifest.get("manifest_version") != 1
            or manifest.get("projection") != "CURRENT_AUTHORIZED_TOOLS"
            or not all(
                isinstance(manifest.get(key), str)
                and re.fullmatch(r"[a-f0-9]{64}", manifest[key])
                for key in ("schema_sha256", "authorization_context", "catalog_version")
            )
        ):
            raise ValueError("readonly_business_manifest_invalid")
        tools = result.get("tools")
        if (
            not isinstance(tools, list)
            or len(tools) > 200
            or any(
                not isinstance(tool, dict)
                or tool.get("annotations", {}).get("readOnlyHint") is not True
                or not isinstance(tool.get("name"), str)
                or not isinstance(tool.get("inputSchema"), dict)
                for tool in tools
            )
            or len({tool["name"] for tool in tools}) != len(tools)
        ):
            raise ValueError("readonly_business_catalog_invalid")
        advertised = manifest.get("tools", [])
        if not isinstance(advertised, list) or any(
            not isinstance(t, dict) for t in advertised
        ):
            raise ValueError("readonly_business_catalog_invalid")
        if any(
            not any(
                other.get("name") == tool["name"]
                and other.get("inputSchema") == tool["inputSchema"]
                and other.get("annotations", {}).get("readOnlyHint") is True
                for other in advertised
            )
            for tool in tools
        ):
            raise ValueError("readonly_business_catalog_mismatch")
        return dict(
            binding=dict(
                identity=identity,
                **{
                    key: manifest[key]
                    for key in (
                        "schema_sha256",
                        "authorization_context",
                        "catalog_version",
                    )
                },
            ),
            tools=deepcopy(tools),
        )

    @_operation_deadline
    def catalog(self):
        try:
            return self._catalog(self._session())
        except (RuntimeError, OSError, KeyError, TypeError, AttributeError) as error:
            raise ValueError("readonly_business_unavailable") from error

    @_operation_deadline
    def execute(self, tool, arguments, *, expected, authorize=None):
        attempted = False
        try:
            client = self._session()
            before = self._catalog(client)
            if before["binding"] != expected or not isinstance(arguments, dict):
                raise ValueError("readonly_business_catalog_changed")
            definition = next(
                (entry for entry in before["tools"] if entry["name"] == tool), None
            )
            if definition is None:
                raise ValueError("readonly_business_tool_denied")
            schema = definition["inputSchema"]
            if (
                schema.get("type") != "object"
                or any(key not in arguments for key in schema.get("required", []))
                or schema.get("additionalProperties") is False
                and set(arguments) - set(schema.get("properties", {}))
            ):
                raise ValueError("readonly_business_arguments_invalid")
            if authorize is not None:
                authorize()
            attempted = True
            result = client._post(
                dict(
                    jsonrpc="2.0",
                    id="readonly-query",
                    method="tools/call",
                    params=dict(name=tool, arguments=arguments),
                ),
                expect_result=True,
            )
            if self._identity(result) != expected["identity"] or result.get("isError"):
                raise ValueError("readonly_business_query_rejected")
            server_request_id = validated_server_request_id(
                result["_meta"].get("request_id")
            )
            after = self._catalog(client)
            if after["binding"] != before["binding"]:
                raise ValueError("readonly_business_catalog_changed")
            if authorize is not None:
                authorize()
            if isinstance(result.get("structuredContent"), dict):
                value = result["structuredContent"]
            else:
                texts = [
                    block["text"]
                    for block in result.get("content", [])
                    if block.get("type") == "text"
                ]
                if len(texts) != 1:
                    raise ValueError("readonly_business_result_invalid")
                try:
                    value = json.loads(texts[0])
                except ValueError:
                    value = dict(text=texts[0])
            return dict(
                result=value,
                server_request_id=server_request_id,
                tool=tool,
                manifest=before["binding"],
                execution_subject="service:" + self.service_id,
            )
        except (
            ValueError,
            RuntimeError,
            OSError,
            KeyError,
            TypeError,
            AttributeError,
        ) as error:
            if attempted:
                raise QueryOutcomeUnknown("readonly_query_outcome_unknown") from error
            raise ValueError("readonly_business_unavailable") from error
