"""Trusted saved-approval metadata projection; approval is never bank payment."""

from copy import deepcopy
from datetime import datetime
import re


class SavedApproval:
    version = "dingtalk-saved-v1"

    def project(self, candidate, selection):
        try:
            change = candidate["change"]
            saved = change["saved"]
            if set(saved) != {
                "version",
                "sequence",
                "observed_at",
                "original",
                "approval",
                "attachments",
            }:
                raise ValueError()
            if any(
                saved[key] != change[key]
                for key in ("version", "sequence", "observed_at", "original")
            ):
                raise ValueError()
            approval = saved["approval"]
            fields = {
                "kind",
                "instance_id",
                "process_instance_id",
                "template_code",
                "status",
                "result",
                "create_time",
                "finish_time",
                "detail_available",
                "declaration_verified",
            }
            if set(approval) != fields or approval["kind"] not in {
                "expense",
                "payment",
            }:
                raise ValueError()
            if (
                not re.fullmatch(r"[a-f0-9-]{36}", approval["instance_id"])
                or change["record"] != approval["instance_id"]
                or not re.fullmatch(r"dr-[1-9][0-9]*", saved["version"])
                or saved["original"]
                != f"dingtalk:{approval['kind']}/{approval['instance_id']}/{saved['version']}"
                or type(saved["sequence"]) is not int
                or saved["sequence"] < 1
                or type(approval["detail_available"]) is not bool
                or type(approval["declaration_verified"]) is not bool
            ):
                raise ValueError()
            for key in ("process_instance_id", "template_code", "status"):
                if (
                    not isinstance(approval[key], str)
                    or not 1 <= len(approval[key]) <= 200
                    or any(ord(c) < 32 for c in approval[key])
                ):
                    raise ValueError()
            if approval["result"] is not None and (
                not isinstance(approval["result"], str) or len(approval["result"]) > 200
            ):
                raise ValueError()
            for value in [
                change["business_at"],
                saved["observed_at"],
                approval["create_time"],
                approval["finish_time"],
            ]:
                if (
                    value is not None
                    and datetime.fromisoformat(value.replace("Z", "+00:00")).utcoffset()
                    is None
                ):
                    raise ValueError()
            if set(selection) != {"goal", "confirmed", "intent", "candidates"}:
                raise ValueError()
            attachments = saved["attachments"]
            if not isinstance(attachments, list) or len(attachments) > 100:
                raise ValueError()
            for item in attachments:
                if (
                    set(item)
                    != {"reference", "relation", "status", "sha256", "size", "type"}
                    or not re.fullmatch(
                        r"dingtalk:attachment/"
                        + re.escape(approval["instance_id"])
                        + r"/[a-f0-9]{64}/"
                        + saved["version"],
                        item["reference"],
                    )
                    or item["status"] not in {"saved", "missing", "failed"}
                    or not re.fullmatch(r"header|line:[1-9][0-9]*", item["relation"])
                    or item["status"] == "saved"
                    and (
                        not isinstance(item["sha256"], str)
                        or not re.fullmatch(r"[a-f0-9]{64}", item["sha256"])
                        or type(item["size"]) is not int
                        or item["size"] < 1
                    )
                ):
                    raise ValueError()
            event = {
                "source": candidate["source"],
                "scope": candidate["scope"],
                "record": change["record"],
                "version": change["version"],
                "sequence": change["sequence"],
                "business_at": change["business_at"],
                "observed_at": change["observed_at"],
                "evidence": change["original"],
                "approval_status": approval["status"] or "unknown",
                **deepcopy(selection),
                "evidence_details": {
                    "approval": deepcopy(approval),
                    "attachments": deepcopy(attachments),
                    "actual_payment": "unverified",
                },
            }
            if (
                not approval["detail_available"]
                or not approval["declaration_verified"]
                or any(item["status"] != "saved" for item in attachments)
            ):
                event["review_required"] = True
            return event
        except (ValueError, TypeError, KeyError, AttributeError):
            raise ValueError("invalid_saved_approval") from None
