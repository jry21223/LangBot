"""Native OpenAgents HTTP boundary. No source credentials or business tools.

Use only against a protected workspace with notifications disabled. The trusted
HTTP server owns agent identity. A shared token alone is not employee authority;
Workflow's source authority and #1323's connector boundary remain mandatory.
"""

import json
from ._http_budget import open_http
from urllib.parse import urlencode, urlsplit
from urllib.request import HTTPRedirectHandler


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class OpenAgents:
    def __init__(self, endpoint, workspace, token):
        url = urlsplit(endpoint)
        if (
            url.username
            or url.password
            or url.query
            or url.fragment
            or url.path not in {"", "/"}
            or (
                url.scheme != "https"
                and not (url.scheme == "http" and url.hostname in {"127.0.0.1", "::1"})
            )
        ):
            raise ValueError("invalid_workspace_endpoint")
        if (
            not isinstance(token, str)
            or len(token) < 16
            or any(c.isspace() for c in token)
        ):
            raise ValueError("invalid_workspace_token")
        self.endpoint = endpoint.rstrip("/")
        self.workspace = workspace
        self._token = token

    def _request(self, path, data=None):
        try:
            response = open_http(self.endpoint + path,
                method="GET" if data is None else "POST",
                data=None if data is None else json.dumps(data).encode(),
                headers={"X-Workspace-Token": self._token, "Content-Type": "application/json"})
            try:
                if response.status != 200:
                    raise ValueError()
                result = json.loads(response.read())
                return result.get("data", result)
            finally:
                response.close()
        except Exception:
            raise ValueError("workspace_unavailable") from None

    def supports_idempotency(self):
        return (
            self._request("/v1/events/delivery-capabilities").get("idempotent_messages")
            is True
        )

    def ensure_thread(self, channel, coordinator, assistants):
        """Reconcile stable native channel name before retrying channel creation.

        Channel creation has no message-delivery receipt support at the pin.
        Its unique workspace/name constraint plus discover readback is the
        recovery boundary; never generate a new name after an unknown result.
        """

        def read():
            return next(
                (
                    c
                    for c in self._request(
                        "/v1/discover?" + urlencode({"network": self.workspace})
                    )["channels"]
                    if c["address"] == "channel/" + channel
                ),
                None,
            )

        existing = read()
        if existing is None:
            self._request(
                "/v1/events",
                {
                    "network": self.workspace,
                    "source": "system:enterprise-agent-1324",
                    "target": "channel/" + channel,
                    "type": "network.channel.create",
                    "payload": {
                        "name": channel,
                        "title": "Observation · " + channel[:12],
                        "master": coordinator,
                        "participants": sorted({coordinator, *assistants}),
                        "visibility": "public",
                        "human_participants": [],
                    },
                },
            )
            existing = read()
        if (
            not existing
            or existing.get("created_by") != "system:enterprise-agent-1324"
            or existing.get("status") != "active"
            or existing.get("master") != coordinator
            or set(existing.get("participants", [])) != {coordinator, *assistants}
        ):
            raise ValueError("thread_binding_unavailable")

    def post(self, message):
        if message.get("network") != self.workspace:
            raise ValueError("workspace_mismatch")
        return self._request("/v1/events", message).get("id")

    def replies(self, channel, after=None):
        query = {
            "network": self.workspace,
            "channel": channel,
            "type": "workspace.message",
            "limit": "100",
        }
        if after:
            query["after"] = after
        result = self._request("/v1/events?" + urlencode(query))
        return result["events"], result.get("next_cursor") or result.get("newest_id") or after
