"""Protected Core HTTP client, disabled until an owner injects it into Host.

The normal Core API key/workspace and receiver registration are independent of
Finance/OpenAgents identities. No listener, ambient credential or server-side
authorizer is created here. The authorize keyword is in-process protocol
compatibility only: no callback or authorization claim travels over HTTP.
"""

from contextlib import contextmanager
import http.client
import json
import math
import os
from pathlib import Path
import re
import stat
import time
from urllib.parse import quote, urlencode
from uuid import UUID

from ._http_budget import current_deadline, open_http
from .native_ingress import (
    OWNER_GAP_CODES,
    _opaque,
    canonical_bytes,
    validate_page,
    canonical_core_origin,
)
from .source_http import _endpoint, _token


class NativeCoreUnavailable(ValueError):
    def __init__(self):
        super().__init__("native_core_unavailable")


def _event_id(value):
    return (
        isinstance(value, str)
        and re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", value) is not None
        and value not in {".", ".."}
    )


def _receipt(value, *, source, event_id=None):
    if (
        not isinstance(value, dict)
        or set(value)
        != {"event_id", "source", "record", "version", "status", "receipt_id"}
        or not _event_id(value["event_id"])
        or event_id is not None
        and value["event_id"] != event_id
        or value["source"] != source
        or value["status"] != "accepted"
        or any(
            not isinstance(value[k], str)
            or not 1 <= len(value[k]) <= 512
            or any(ord(char) < 32 for char in value[k])
            for k in ("record", "version")
        )
        or not isinstance(value["receipt_id"], str)
        or not re.fullmatch(r"[a-f0-9]{64}", value["receipt_id"])
    ):
        raise NativeCoreUnavailable()
    return value


class NativeCoreHttp:
    def __init__(
        self,
        *,
        endpoint,
        bot_uuid,
        workspace,
        api_key_file,
        source,
        scope,
        timeout=10,
        flavor="finance",
    ):
        try:
            self.endpoint = _endpoint(canonical_core_origin(endpoint))
            if (
                self.endpoint.path not in ("", "/")
                or not isinstance(bot_uuid, str)
                or str(UUID(bot_uuid)) != bot_uuid
                or any(
                    not isinstance(v, str)
                    or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,200}", v)
                    for v in (source, scope)
                )
                or not isinstance(workspace, str)
                or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", workspace)
                or not isinstance(api_key_file, str)
                or not Path(api_key_file).is_absolute()
                or "\x00" in api_key_file
                or len(api_key_file) > 4096
                or type(timeout) not in (int, float)
                or not math.isfinite(timeout)
                or not 0 < timeout <= 30
                or not isinstance(flavor, str)
                or flavor not in OWNER_GAP_CODES
            ):
                raise ValueError()
        except (ValueError, TypeError, AttributeError):
            raise ValueError("native_core_configuration_invalid") from None
        self.bot_uuid, self.workspace, self.api_key_file = (
            bot_uuid,
            workspace,
            api_key_file,
        )
        self.source, self.scope, self.timeout, self.flavor = (
            source,
            scope,
            timeout,
            flavor,
        )
        self.prefix = f"/api/v1/native-ingress/{bot_uuid}/router"

    def consumer_binding(self):
        """Public registration identity only; no key, key path, read or request."""
        return dict(
            endpoint=canonical_core_origin(self.endpoint.geturl()),
            workspace=self.workspace,
            bot_uuid=self.bot_uuid,
            source=self.source,
            scope=self.scope,
            flavor=self.flavor,
        )

    @contextmanager
    def _budget(self):
        token = current_deadline.set(
            min(time.monotonic() + self.timeout, current_deadline.get() or float("inf"))
        )
        try:
            yield
        finally:
            current_deadline.reset(token)

    def _key(self):
        # O_NONBLOCK also makes a wrongly configured FIFO fail rather than hang.
        fd = os.open(self.api_key_file, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            if (
                not stat.S_ISREG(info.st_mode)
                or info.st_uid != os.getuid()
                or info.st_nlink != 1
                or info.st_mode & 0o077
            ):
                raise NativeCoreUnavailable()
            raw = stream.read(4097)
        if len(raw) > 4096:
            raise NativeCoreUnavailable()
        return _token(raw.decode().strip())

    def _call(self, method, route, *, query=None, body=None):
        with self._budget():
            response = None
            try:
                url = self.endpoint._replace(
                    path=self.prefix + route, query=urlencode(query or {})
                ).geturl()
                headers = {
                    "X-API-Key": self._key(),
                    "X-Workspace-Id": self.workspace,
                    "Accept": "application/json",
                }
                data = None
                if body is not None:
                    data = canonical_bytes(body)
                    if len(data) > 512 * 1024:
                        raise NativeCoreUnavailable()
                    headers["Content-Type"] = "application/json"
                response = open_http(
                    url,
                    method=method,
                    data=data,
                    headers=headers,
                    timeout=self.timeout,
                    limit=4 * 1024 * 1024,
                )
                if response.status != 200:
                    raise NativeCoreUnavailable()
                result = json.loads(response.read())
                if (
                    not isinstance(result, dict)
                    or set(result) != {"code", "data", "msg"}
                    or type(result["code"]) is not int
                    or result["code"] != 0
                    or not isinstance(result["msg"], str)
                    or len(result["msg"]) > 4096
                ):
                    raise NativeCoreUnavailable()
                return result["data"]
            except (
                ValueError,
                TypeError,
                KeyError,
                UnicodeError,
                OSError,
                http.client.HTTPException,
                RecursionError,
            ):
                raise NativeCoreUnavailable() from None
            finally:
                if response is not None:
                    response.close()

    def read_router_page(self, cursor, limit, *, authorize=None):
        try:
            if cursor is not None and not _opaque(cursor, 4096):
                raise NativeCoreUnavailable()
            if type(limit) is not int or not 1 <= limit <= 100:
                raise NativeCoreUnavailable()
            query = dict(limit=limit)
            if cursor is not None:
                query["cursor"] = cursor
            result = self._call("GET", "/changes", query=query)
            result = validate_page(
                result,
                source=self.source,
                scope=self.scope,
                previous_cursor=cursor,
                limit=limit,
                flavor=self.flavor,
            )
            if any(
                not _event_id(row["event_id"])
                for row in result["items"] + result["gaps"]
            ):
                raise NativeCoreUnavailable()
            return result
        except (ValueError, TypeError, KeyError, RecursionError):
            raise NativeCoreUnavailable() from None

    def ack_router_page(self, page_id, page_sha256, receipts, *, authorize=None):
        try:
            if (
                not _opaque(page_id, 200)
                or not isinstance(page_sha256, str)
                or not re.fullmatch(r"[a-f0-9]{64}", page_sha256)
                or not isinstance(receipts, list)
                or len(receipts) > 100
            ):
                raise NativeCoreUnavailable()
            for receipt in receipts:
                _receipt(receipt, source=self.source)
            if len({r["event_id"] for r in receipts}) != len(receipts):
                raise NativeCoreUnavailable()
            result = self._call(
                "POST",
                "/ack",
                body=dict(page_id=page_id, page_sha256=page_sha256, receipts=receipts),
            )
            if (
                not isinstance(result, dict)
                or set(result) != {"status", "page_id", "next_cursor"}
                or result["status"] != "accepted"
                or result["page_id"] != page_id
                or not _opaque(result["next_cursor"], 4096)
            ):
                raise NativeCoreUnavailable()
            return result
        except (ValueError, TypeError, KeyError, RecursionError):
            raise NativeCoreUnavailable() from None

    def lookup_router_receipt(self, event_id, *, authorize=None):
        try:
            if not _event_id(event_id):
                raise NativeCoreUnavailable()
            result = self._call("GET", "/receipts/" + quote(event_id, safe=""))
            return (
                None
                if result is None
                else _receipt(result, source=self.source, event_id=event_id)
            )
        except (ValueError, TypeError, KeyError, RecursionError):
            raise NativeCoreUnavailable() from None
