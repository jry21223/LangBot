"""Immutable, thread-bound native originals in the existing source database.

This module owns evidence and derived representations, never an agent task queue.
It performs no network, credential lookup, extraction, or model operation.
"""
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import sqlite3


MESSAGE_FIELDS = {'account_id', 'thread_id', 'message_id', 'sender_id', 'server_id', 'message_type',
                  'direction', 'native_version', 'body', 'media', 'recalled', 'business_at'}
MEDIA_FIELDS = {'asset_id', 'kind', 'state', 'sha256', 'byte_length', 'content_type'}
SUPPORTED = {'text', 'image', 'voice', 'file'}


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def digest(value):
    return sha256(canonical(value).encode()).hexdigest()


def token(value, maximum=512):
    return isinstance(value, str) and 0 < len(value) <= maximum and all(ord(c) >= 32 and ord(c) != 127 for c in value)


def instant(value):
    if not isinstance(value, str) or datetime.fromisoformat(value.replace('Z', '+00:00')).utcoffset() is None:
        raise ValueError('native_time_invalid')


class NativeWechatStore:
    def __init__(self, path, *, account, thread, source, scope, parser_version, sequence_floor=None, start_cursor=None):
        if (any(not token(v, 200) for v in (account, thread, source, scope, parser_version))
                or sequence_floor is not None and (type(sequence_floor) is not int or not 0 <= sequence_floor < 2**63 - 1)):
            raise ValueError('native_binding_invalid')
        path = Path(path)
        if path.is_symlink():
            raise ValueError('native_state_invalid')
        self.account, self.thread, self.source, self.scope, self.parser_version = account, thread, source, scope, parser_version
        self.db = sqlite3.connect(path)
        os.chmod(path, 0o600)
        existing = self.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='messages'").fetchone()
        legacy_max = self.db.execute('SELECT COALESCE(MAX(seq),0) FROM messages').fetchone()[0] if existing else 0
        native_table = self.db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='wx_native_binding'").fetchone()
        native_initialized = native_table and self.db.execute('SELECT value FROM wx_native_binding').fetchone() is not None
        if not native_initialized and legacy_max and (sequence_floor is None or sequence_floor < legacy_max):
            self.db.close()
            raise ValueError('native_source_migration_required')
        self.db.executescript('''
          CREATE TABLE IF NOT EXISTS wx_native_binding(value TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS wx_native_counter(sequence INTEGER NOT NULL);
          CREATE TABLE IF NOT EXISTS wx_native_observer(cursor TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS wx_native_unqualified(message_key TEXT PRIMARY KEY,snapshot TEXT NOT NULL,item TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS wx_native_current(record TEXT PRIMARY KEY,reference TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS wx_native_versions(reference TEXT PRIMARY KEY,record TEXT NOT NULL,
            version TEXT NOT NULL,input_hash TEXT NOT NULL,snapshot TEXT NOT NULL,item TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS wx_native_events(sequence INTEGER PRIMARY KEY,event_id TEXT UNIQUE NOT NULL,item TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS wx_native_results(result_hash TEXT PRIMARY KEY,value TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS wx_native_operations(operation_id TEXT PRIMARY KEY,fingerprint TEXT NOT NULL,receipt TEXT NOT NULL);
        ''')
        initial_cursor = '0' if start_cursor is None else start_cursor
        self._observer_position(initial_cursor)
        binding = canonical([account, thread, source, scope, parser_version, sequence_floor or 0, initial_cursor])
        with self.db:
            row = self.db.execute('SELECT value FROM wx_native_binding').fetchone()
            if row is None:
                self.db.execute('INSERT INTO wx_native_binding VALUES(?)', (binding,))
                self.db.execute('INSERT INTO wx_native_counter VALUES(?)', (sequence_floor or 0,))
                self.db.execute('INSERT INTO wx_native_observer VALUES(?)', (initial_cursor,))
            elif row[0] != binding:
                raise ValueError('native_binding_drift')

    def close(self):
        self.db.close()

    def normalize_message(self, message):
        if (not isinstance(message, dict) or set(message) != MESSAGE_FIELDS
                or message['account_id'] != self.account or message['thread_id'] != self.thread
                or message['direction'] not in ('incoming', None) or type(message['recalled']) is not bool
                or any(not token(message[k]) for k in MESSAGE_FIELDS - {'body', 'media', 'recalled', 'sender_id', 'server_id', 'direction', 'business_at'})
                or any(message[k] is not None and not token(message[k]) for k in ('sender_id', 'server_id'))
                or message['body'] is not None and (not isinstance(message['body'], str) or len(message['body'].encode()) > 2_000_000)
                or not isinstance(message['media'], list) or len(message['media']) > 100):
            raise ValueError('native_message_invalid')
        if message['business_at'] is not None:
            instant(message['business_at'])
        assets = []
        for asset in message['media']:
            if (not isinstance(asset, dict) or set(asset) != MEDIA_FIELDS
                    or any(not token(asset[k], 200) for k in ('asset_id', 'kind'))
                    or asset['content_type'] is not None and not token(asset['content_type'], 200)
                    or not isinstance(asset['state'], str) or asset['state'] not in {'pending', 'available', 'expired', 'unsupported', 'failed', 'cancelled', 'needs_review'}
                    or asset['byte_length'] is not None and (type(asset['byte_length']) is not int or not 0 <= asset['byte_length'] < 2**63)
                    or asset['sha256'] is not None and (not isinstance(asset['sha256'], str) or not re.fullmatch('[a-f0-9]{64}', asset['sha256']))
                    or (asset['state'] == 'available' and (not isinstance(asset['sha256'], str)
                        or not re.fullmatch('[a-f0-9]{64}', asset['sha256'])
                        or asset['byte_length'] is None or asset['content_type'] is None))):
                raise ValueError('native_media_invalid')
            assets.append(deepcopy(asset))
        if len({a['asset_id'] for a in assets}) != len(assets):
            raise ValueError('native_media_invalid')
        value = deepcopy(message)
        value['media'] = assets
        return value

    def input_hash(self, message):
        value = self.normalize_message(message)
        # wx 1.4 version is the profile reader generation, not a message revision.
        # Keep it in immutable provenance but do not churn refs for unrelated messages.
        state = {k: value[k] for k in MESSAGE_FIELDS - {'body', 'media', 'native_version'}}
        state['media'] = sorted(value['media'], key=lambda a: a['asset_id'])
        state['body_hash'] = sha256(value['body'].encode()).hexdigest() if value['body'] is not None else None
        return digest(state)

    @contextmanager
    def _transaction(self):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            yield
            self.db.commit()
        except BaseException:
            self.db.rollback()
            raise

    @staticmethod
    def _observer_position(value):
        # The selected wx 1.4 protocol explicitly defines decimal i64 cursors.
        # This is not the source sequence or Core position domain.
        if not isinstance(value, str) or not re.fullmatch('0|[1-9][0-9]*', value) or len(value) > 19 or int(value) >= 2**63:
            raise ValueError('native_observer_cursor_invalid')
        return int(value)

    def observer_cursor(self):
        return self.db.execute('SELECT cursor FROM wx_native_observer').fetchone()[0]

    def advance_observer_cursor(self, expected, next_cursor):
        if self._observer_position(next_cursor) < self._observer_position(expected):
            raise ValueError('native_observer_cursor_invalid')
        with self._transaction():
            if self.observer_cursor() != expected:
                raise ValueError('native_observer_cursor_conflict')
            self.db.execute('UPDATE wx_native_observer SET cursor=?', (next_cursor,))

    def snapshot_by_message(self, message_id):
        if not token(message_id):
            raise ValueError('native_message_id_invalid')
        key = digest([self.account, self.thread, message_id])
        current = self._current(key)
        if current:
            return self.snapshot(current['reference'], current['version'])
        row = self.db.execute('SELECT snapshot FROM wx_native_unqualified WHERE message_key=?', (key,)).fetchone()
        return json.loads(row[0]) if row else None

    def _find_message(self, predicate):
        matches = []
        for row in self.db.execute('SELECT v.snapshot FROM wx_native_current c JOIN wx_native_versions v ON v.reference=c.reference'):
            snapshot = json.loads(row[0])
            if not snapshot['recalled'] and predicate(snapshot):
                matches.append(snapshot['message_id'])
        for row in self.db.execute('SELECT snapshot FROM wx_native_unqualified'):
            snapshot = json.loads(row[0])
            if not snapshot['recalled'] and predicate(snapshot):
                matches.append(snapshot['message_id'])
        return matches[0] if len(set(matches)) == 1 else None

    def find_message_by_asset(self, asset_id):
        if not token(asset_id, 200):
            raise ValueError('native_asset_invalid')
        return self._find_message(lambda s: any(a['asset_id'] == asset_id for a in s['media']))

    def find_message_by_server_id(self, server_id):
        if not token(server_id):
            raise ValueError('native_server_id_invalid')
        return self._find_message(lambda s: s['server_id'] == server_id)

    def _next(self):
        sequence = self.db.execute('SELECT sequence FROM wx_native_counter').fetchone()[0] + 1
        if sequence >= 2**63:
            raise ValueError('native_sequence_exhausted')
        self.db.execute('UPDATE wx_native_counter SET sequence=?', (sequence,))
        return sequence

    def _current(self, record):
        row = self.db.execute('SELECT v.snapshot FROM wx_native_current c JOIN wx_native_versions v ON v.reference=c.reference WHERE c.record=?', (record,)).fetchone()
        return json.loads(row[0]) if row else None

    def _publish(self, message, event_cursor, observed_at, baseline, result=None):
        record = digest([self.account, self.thread, message['message_id']])
        input_hash = self.input_hash(message)
        old = self._current(record)
        source_business_at = message['business_at']
        if source_business_at is None and message['recalled'] and old:
            source_business_at = old.get('source_business_at') or old.get('business_at')
        if source_business_at is None:
            return self._publish_unqualified(message, event_cursor, baseline, input_hash)
        if old and old['recalled'] and not message['recalled']:
            raise ValueError('native_recall_terminal')
        representation = ({'kind': 'text', 'content_sha256': sha256(message['body'].encode()).hexdigest() if message['body'] is not None else None}
                          if message['message_type'] == 'text' else {'kind': 'pending', 'parser_version': self.parser_version})
        if result is not None:
            representation = dict(kind='derived', parser_version=self.parser_version, result_sha256=result['result_sha256'])
        version = digest(dict(input_hash=input_hash, representation=representation))
        reference = f'wechat-native:message/{record}/{version}'
        exists = self.db.execute('SELECT item FROM wx_native_versions WHERE reference=?', (reference,)).fetchone()
        if exists:
            if not old or old['reference'] != reference:
                raise ValueError('native_version_rollback')
            return json.loads(exists[0])
        sequence = self._next()
        ready = (not message['recalled'] and message['direction'] == 'incoming' and message['message_type'] in SUPPORTED and
                 ((message['message_type'] == 'text' and bool(message['body'])) or
                  (result is not None and result['status'] == 'COMPLETE' and not result['issues'] and bool(result['content_text']))))
        kind = 'recalled' if message['recalled'] else 'baseline' if baseline else 'created' if old is None else 'attachments_changed' if result is not None or old['media'] != message['media'] else 'changed'
        saved = {k: message[k] for k in ('account_id', 'thread_id', 'message_id', 'sender_id', 'server_id', 'message_type', 'direction')}
        saved['body_available'] = ready
        change = dict(source=self.source, scope=self.scope, record=record, version=version, sequence=sequence,
                      kind=kind, business_at=source_business_at, observed_at=observed_at, original=reference,
                      goal_reference=None, saved=saved, original_available=ready)
        change['projection_hash'] = digest(change)
        qualification = 'recalled' if message['recalled'] else 'baseline' if baseline else 'direction_unverified' if message['direction'] is None else 'unknown_identity' if not message['sender_id'] or not message['server_id'] else 'ready' if ready else 'unsupported' if message['message_type'] not in SUPPORTED else 'media_pending' if any(a['state'] != 'available' for a in message['media']) else 'media_materialization_required'
        item = dict(event_id=digest(['wx-native-event-v1', self.source, self.scope, record, version]), change=change,
                    native_version=message['native_version'], event_cursor=event_cursor, media=deepcopy(message['media']),
                    qualification=qualification, dispatch_eligible=ready and not baseline and bool(message['sender_id']) and bool(message['server_id']))
        snapshot = dict(message, reference=reference, version=version, record=record, input_hash=input_hash,
                        body_hash=sha256(message['body'].encode()).hexdigest() if message['body'] is not None else None, event_cursor=event_cursor,
                        source_sequence=sequence, source_business_at=source_business_at, parser_version=self.parser_version, result_sha256=result['result_sha256'] if result else None,
                        status=result['status'] if result else 'RECALLED' if message['recalled'] else 'COMPLETE' if ready else 'PENDING',
                        baseline=baseline,qualification=qualification,dispatch_eligible=item['dispatch_eligible'])
        self.db.execute('DELETE FROM wx_native_unqualified WHERE message_key=?', (record,))
        self.db.execute('INSERT INTO wx_native_versions VALUES(?,?,?,?,?,?)', (reference, record, version, input_hash, canonical(snapshot), canonical(item)))
        self.db.execute('INSERT INTO wx_native_events VALUES(?,?,?)', (sequence, item['event_id'], canonical(item)))
        self.db.execute('INSERT INTO wx_native_current VALUES(?,?) ON CONFLICT(record) DO UPDATE SET reference=excluded.reference', (record, reference))
        return item

    def _publish_unqualified(self, message, event_cursor, baseline, input_hash):
        key = digest([self.account, self.thread, message['message_id']])
        prior = self.db.execute('SELECT snapshot,item FROM wx_native_unqualified WHERE message_key=?', (key,)).fetchone()
        if prior and json.loads(prior[0])['input_hash'] == input_hash:
            return json.loads(prior[1])
        event_id = digest(['wx-native-unqualified-v1',self.source,self.scope,key,input_hash])
        sequence = self._next()
        item = dict(event_id=event_id,kind='unresolved',source_sequence=sequence,event_cursor=event_cursor,
                    reason='native_unresolved',source=self.source,scope=self.scope)
        snapshot = dict(message,reference=None,version=None,record=None,native_message_id=message['message_id'],
                        input_hash=input_hash,body_hash=sha256(message['body'].encode()).hexdigest() if message['body'] is not None else None,
                        event_cursor=event_cursor,source_sequence=sequence,source_business_at=None,
                        parser_version=self.parser_version,result_sha256=None,status='UNQUALIFIED',baseline=baseline,
                        current=True,qualification='native_unresolved',dispatch_eligible=False)
        self.db.execute('INSERT INTO wx_native_unqualified VALUES(?,?,?) ON CONFLICT(message_key) DO UPDATE SET snapshot=excluded.snapshot,item=excluded.item',
                        (key,canonical(snapshot),canonical(item)))
        self.db.execute('INSERT INTO wx_native_events VALUES(?,?,?)',(sequence,event_id,canonical(item)))
        return item

    def commit_native(self, message, *, event_cursor, observed_at, baseline=False):
        message = self.normalize_message(message)
        if not token(event_cursor, 4096) or type(baseline) is not bool:
            raise ValueError('native_event_invalid')
        instant(observed_at)
        with self._transaction():
            key = digest([self.account, self.thread, message['message_id']])
            old = self._current(key)
            pending = self.db.execute('SELECT snapshot FROM wx_native_unqualified WHERE message_key=?', (key,)).fetchone()
            if pending and json.loads(pending[0])['recalled'] and not message['recalled']:
                raise ValueError('native_recall_terminal')
            if old and old['input_hash'] == self.input_hash(message):
                return json.loads(self.db.execute('SELECT item FROM wx_native_versions WHERE reference=?', (old['reference'],)).fetchone()[0])
            return self._publish(message, event_cursor, observed_at, baseline)

    def commit_unresolved(self, event_id, event_cursor, reason='native_unresolved'):
        if not token(event_id, 200) or not token(event_cursor, 4096) or reason != 'native_unresolved':
            raise ValueError('native_unresolved_invalid')
        with self._transaction():
            row = self.db.execute('SELECT item FROM wx_native_events WHERE event_id=?', (event_id,)).fetchone()
            if row:
                item = json.loads(row[0])
                if item.get('event_cursor') != event_cursor or item.get('reason') != reason:
                    raise ValueError('native_event_conflict')
                return item
            sequence = self._next()
            item = dict(event_id=event_id,kind='unresolved',source_sequence=sequence,event_cursor=event_cursor,
                        reason=reason,source=self.source,scope=self.scope)
            self.db.execute('INSERT INTO wx_native_events VALUES(?,?,?)', (sequence, event_id, canonical(item)))
            return item

    def changes(self, cursor=None, limit=100):
        if type(limit) is not int or not 1 <= limit <= 100 or cursor is not None and (not isinstance(cursor, str) or not re.fullmatch('0|[1-9][0-9]*', cursor)):
            raise ValueError('native_cursor_invalid')
        position = int(cursor or '0')
        high = self.db.execute('SELECT sequence FROM wx_native_counter').fetchone()[0]
        if position > high:
            raise ValueError('native_cursor_invalid')
        rows = self.db.execute('SELECT sequence,item FROM wx_native_events WHERE sequence>? ORDER BY sequence LIMIT ?', (position, limit)).fetchall()
        items = [json.loads(row[1]) for row in rows]
        return dict(source=self.source, scope=self.scope, previous_cursor=cursor,
                    next_cursor=str(rows[-1][0] if rows else high), complete_page=True,
                    items=items, gaps=['history_before_activation_unverified'] + (['original_unavailable'] if any(
                        'change' in item and not item['change']['original_available'] for item in items) else []))

    def snapshot(self, reference, version, *, include_history=False):
        row = self.db.execute('SELECT snapshot FROM wx_native_versions WHERE reference=? AND version=?', (reference, version)).fetchone()
        if row is None:
            raise ValueError('native_original_unavailable')
        value = json.loads(row[0])
        current = self._current(value['record'])
        value['current'] = current['reference'] == reference
        if not include_history and not value['current']:
            raise ValueError('native_original_stale')
        value['native_message_id'] = value['message_id']
        return value

    def descriptor(self, reference, version, *, include_history=False):
        snapshot = self.snapshot(reference, version, include_history=include_history)
        item = json.loads(self.db.execute('SELECT item FROM wx_native_versions WHERE reference=?', (reference,)).fetchone()[0])
        change = item['change']
        return {k: change[k] for k in ('version', 'projection_hash', 'kind')} | dict(reference=reference, original_available=snapshot['current'] and change['original_available'])

    def set_parser_version(self, parser_version, *, observed_at):
        """Explicit owner transition; never exposed as a parser-reader action."""
        if not token(parser_version, 200):
            raise ValueError('native_parser_pin_invalid')
        instant(observed_at)
        previous = self.parser_version
        try:
            with self._transaction():
                row = self.db.execute('SELECT value FROM wx_native_binding').fetchone()
                binding = json.loads(row[0])
                if binding[4] != previous:
                    raise ValueError('native_binding_drift')
                current = [json.loads(r[0]) for r in self.db.execute(
                    'SELECT v.snapshot FROM wx_native_current c JOIN wx_native_versions v ON v.reference=c.reference')]
                self.parser_version = parser_version
                binding[4] = parser_version
                self.db.execute('UPDATE wx_native_binding SET value=?', (canonical(binding),))
                for snapshot in current:
                    if snapshot['message_type'] != 'text':
                        self._publish({k: snapshot[k] for k in MESSAGE_FIELDS}, snapshot['event_cursor'],
                                      observed_at, snapshot['baseline'])
        except BaseException:
            self.parser_version = previous
            raise

    def materialization_records(self, cursor=None, limit=100, *, parser_version):
        if parser_version != self.parser_version:
            raise ValueError('native_parser_pin_mismatch')
        page = self.changes(cursor, limit)
        items = []
        for item in page['items']:
            if 'change' not in item:
                continue
            change = item['change']
            try:
                s = self.snapshot(change['original'], change['version'])
            except ValueError:
                continue
            if s['message_type'] == 'text' or s['recalled'] or s['status'] == 'COMPLETE':
                continue
            assets = s['media']
            original = {'msgtype':s['message_type'],s['message_type']:{}}
            paths = [f'$.{s["message_type"]}']
            if len(assets) > 1:
                original = {'msgtype':'mixed','mixed':{'item':[{'type':a['kind'],'content':{}} for a in assets]}}
                paths = [f'$.mixed.item[{index}].content' for index in range(len(assets))]
            expected = [dict(source_path=paths[index],media_id=a['asset_id'],media_type=a['kind'])
                        for index,a in enumerate(assets)]
            media = [dict(id=a['asset_id'],media_id=a['asset_id'],download_status='AVAILABLE' if a['state']=='available' else 'PENDING',
                          size_bytes=a['byte_length'],content_hash=a['sha256']) for a in assets]
            items.append(dict(reference=s['reference'], version=s['version'], input_hash=s['input_hash'],
                message_type=s['message_type'],assets=assets,media=media,original=original,expected_media=expected,recalled=s['recalled']))
        return {**page, 'items': items}

    def save_materialization(self, reference, version, input_hash, parser_version, status, content_text, parts, issues, media_hashes, operation_id):
        if (not token(operation_id, 200) or parser_version != self.parser_version or status not in {'COMPLETE', 'PARTIAL', 'UNSUPPORTED'}
                or not isinstance(content_text, str) or len(content_text.encode()) > 8_000_000
                or not isinstance(parts, list) or not isinstance(issues, list) or not isinstance(media_hashes, dict)
                or status == 'COMPLETE' and (not content_text or issues)):
            raise ValueError('native_materialization_invalid')
        fingerprint = digest([reference, version, input_hash, parser_version, status, content_text, parts, issues, media_hashes])
        with self._transaction():
            prior = self.db.execute('SELECT fingerprint,receipt FROM wx_native_operations WHERE operation_id=?', (operation_id,)).fetchone()
            if prior:
                if prior[0] != fingerprint:
                    raise ValueError('native_operation_conflict')
                return json.loads(prior[1])
            s = self.snapshot(reference, version)
            if s['recalled'] or s['input_hash'] != input_hash or s['message_type'] == 'text':
                raise ValueError('native_materialization_stale')
            expected = {a['asset_id']: a['sha256'] for a in s['media']}
            if media_hashes != expected or status == 'COMPLETE' and (not expected or any(a['state'] != 'available' for a in s['media'])):
                raise ValueError('native_media_integrity_failed')
            result = dict(status=status, content_text=content_text, parts=deepcopy(parts), issues=deepcopy(issues))
            result['result_sha256'] = digest(result)
            if s['status'] == 'COMPLETE' and s['result_sha256'] != result['result_sha256']:
                raise ValueError('native_complete_result_immutable')
            self.db.execute('INSERT OR IGNORE INTO wx_native_results VALUES(?,?)', (result['result_sha256'], canonical(result)))
            message = {k: s[k] for k in MESSAGE_FIELDS}
            item = self._publish(message, s['event_cursor'], datetime.now(timezone.utc).isoformat(), s['baseline'], result)
            change = item['change']
            receipt = dict(operation_id=operation_id, status='saved', reference=change['original'], version=change['version'],
                           source_sequence=change['sequence'], result_sha256=result['result_sha256'])
            self.db.execute('INSERT INTO wx_native_operations VALUES(?,?,?)', (operation_id, fingerprint, canonical(receipt)))
            return receipt

    def lookup_operation(self, operation_id):
        """Read an immutable technical receipt, never a current-content grant."""
        if not token(operation_id, 200):
            raise ValueError('native_operation_invalid')
        row = self.db.execute('SELECT receipt FROM wx_native_operations WHERE operation_id=?', (operation_id,)).fetchone()
        return json.loads(row[0]) if row else None

    def read_derived(self, reference, version, parser_version):
        if parser_version != self.parser_version:
            raise ValueError('native_parser_pin_mismatch')
        s = self.snapshot(reference, version)
        if s['recalled']:
            return dict(reference=reference, version=version, parser_version=parser_version, result_sha256=None,
                        status='RECALLED', content_text='', parts=[], issues=[])
        if not s['result_sha256']:
            text = s['body'] if s['message_type'] == 'text' and s['status'] == 'COMPLETE' else ''
            return dict(reference=reference, version=version, parser_version=parser_version, result_sha256=None,
                        status=s['status'], content_text=text, parts=[], issues=[])
        result = json.loads(self.db.execute('SELECT value FROM wx_native_results WHERE result_hash=?', (s['result_sha256'],)).fetchone()[0])
        return dict(reference=reference, version=version, parser_version=parser_version, **result)
