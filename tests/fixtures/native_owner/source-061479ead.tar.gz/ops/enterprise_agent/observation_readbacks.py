"""Read-only audit collectors over existing public owner interfaces.

Their output is ALWAYS synthetic/unqualified until the real owner independently
attests provenance, identity, configuration and original evidence. No writer,
notification outlet, model launch or permissive real authority lives here.
"""
from hashlib import sha256
from .observation import digest


class Readbacks:
    @staticmethod
    def archive(receipt, client):
        references = ["receipt:" + digest(receipt)]
        saved = dict(kind="archive_saved", outcome="unknown", provenance="synthetic", references=references)
        indexed = dict(kind="archive_index", outcome="unmeasured", provenance="synthetic", references=references)
        try:
            document = client.read(receipt["path"], receipt["revision"])
            if (not receipt.get("index_job_id") or document["current"] is not True
                    or document["revision"] != receipt["revision"] or document["document_id"] != receipt["document_id"]
                    or sha256(document["content"].encode()).hexdigest() != receipt["revision"]):
                saved["outcome"] = "failed"
            else:
                saved["outcome"] = "passed"
                saved["references"] = references + ["document:" + document["document_id"] + "/" + document["revision"]]
                status = client.status()
                if (document["index_status"] == "ready" and status["index_status"] == "ready"
                        and status["semantic_available"] is True and status["pending_count"] == 0):
                    indexed.update(outcome="passed", references=saved["references"] + ["index:" + digest(status)])
                elif document["index_status"] == "updating":
                    indexed["outcome"] = "pending"
        except Exception:
            # An unavailable read is not proof of failed save, or a ready index.
            pass
        return dict(saved=saved, index=indexed)

    @staticmethod
    def gd(workflow, maintenance, mcp, action_id):
        # Reuse the owner's authorized projection, then read the original request
        # and object. Never tick maintenance, retry writes or replace request IDs.
        action = next(a for a in maintenance.notification_actions(workflow) if a["id"] == action_id)
        references = ["gd:" + action_id]
        if action["status"] != "verified":
            return dict(kind="gd_readback", outcome="unknown", provenance="synthetic", references=references)
        receipt = mcp.call_tool("get_mcp_write_request", dict(request_id=action_id))
        if receipt != action.get("receipt"):
            return dict(kind="gd_readback", outcome="failed", provenance="synthetic", references=references)
        item = mcp.call_tool("get_work_item_detail", dict(code=receipt["result"]["code"]))
        matches = receipt["status"] == "SUCCEEDED" and all(
            item.get(k) == v for k, v in receipt["result"].items() if not k.startswith("previous_"))
        references += ["receipt:" + digest(receipt), "object:" + digest(item)]
        return dict(kind="gd_readback", outcome="passed" if matches else "failed",
                    provenance="synthetic", references=references)

    @staticmethod
    def native(workflow, workspace, matter_id):
        matter = next(m for m in workflow.matters() if m["id"] == matter_id)
        result = matter.get("result", {})
        actions = [a for a in workflow.actions() if a["matter"] == matter_id
                   and a["revision"] == matter["revision"] and a["stage"] == "assistant"
                   and a["status"] == "completed"]
        replies, _ = workspace.replies(matter_id)
        matching = [r for r in replies if r.get("id") == result.get("event_id")
                    and r.get("source") == "openagents:" + result.get("agent", "")
                    and r.get("target") == "channel/" + matter_id
                    and r.get("type") == "workspace.message.posted"
                    and r.get("metadata", {}).get("status_kind") == "completed"
                    and any(r.get("metadata", {}).get("in_reply_to") == a.get("remote_id") for a in actions)
                    and r.get("payload", {}).get("content") == result.get("content")]
        return dict(kind="native_entry", outcome="passed" if matching else "unknown",
                    provenance="synthetic", references=["native:" + matter_id + "/" + matter["revision"]] +
                    ["receipt:" + digest(r) for r in matching])
