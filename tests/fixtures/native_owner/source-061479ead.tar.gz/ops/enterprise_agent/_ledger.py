"""Private JSON persistence mechanics; each consumer retains its own file/schema."""
from contextlib import contextmanager
import json
import os
import sqlite3
import stat


def private_file(path):
    """Return a validated private descriptor; callers own its lifetime."""
    try:
        fd = os.open(path, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
        try:
            info = os.fstat(fd)
            if (not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid()
                    or info.st_mode & 0o077):
                raise ValueError()
        except BaseException:
            os.close(fd)
            raise
        return fd
    except (OSError, ValueError):
        raise ValueError("private_state_required") from None


class PrivateJsonLedger:
    def _open_ledger(self, database, table):
        if table not in {"state", "gd_state", "notifications"}:
            raise ValueError("invalid_ledger_table")
        os.close(private_file(database))
        self._table = table
        self.db = sqlite3.connect(database, timeout=10)
        self.db.execute(f"CREATE TABLE IF NOT EXISTS {table} (id INTEGER PRIMARY KEY CHECK(id=1), value TEXT NOT NULL)")

    def _read(self):
        return json.loads(self.db.execute(f"SELECT value FROM {self._table} WHERE id=1").fetchone()[0])

    @contextmanager
    def _transaction(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            state = self._read()
            yield state
            self.db.execute(f"UPDATE {self._table} SET value=? WHERE id=1", (json.dumps(state),))
            self.db.commit()
        except BaseException:
            self.db.rollback()
            raise
