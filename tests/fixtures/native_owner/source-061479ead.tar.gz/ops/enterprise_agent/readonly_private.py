"""Private content-addressed request/receipt files; no model-chosen file paths."""

from hashlib import sha256
import json
import os
from pathlib import Path
import re
import stat
import tempfile


def read_private_bytes(path, limit):
    path = Path(path)
    if not path.is_absolute():
        raise ValueError("private_readonly_file_required")
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    with os.fdopen(fd, "rb") as source:
        info = os.fstat(source.fileno())
        if (
            not stat.S_ISREG(info.st_mode)
            or info.st_uid != os.getuid()
            or info.st_mode & 0o077
            or info.st_nlink != 1
        ):
            raise ValueError("private_readonly_file_required")
        raw = source.read(limit + 1)
    if len(raw) > limit:
        raise ValueError("readonly_private_budget_exceeded")
    return raw


def directory(root, area, *, create=False):
    root = Path(root)
    if (
        area not in {"readonly-proposals", "readonly-results"}
        or not root.is_absolute()
        or root.is_symlink()
        or root.resolve() != root
    ):
        raise ValueError("private_readonly_directory_required")
    for path in [root, root / area]:
        if create and not path.exists():
            path.mkdir(mode=0o700)
        info = path.lstat()
        if (
            not stat.S_ISDIR(info.st_mode)
            or info.st_uid != os.getuid()
            or info.st_mode & 0o077
        ):
            raise ValueError("private_readonly_directory_required")
    return root / area


def read_record(root, area, key, *, expected_hash=None, limit=4 * 1024 * 1024):
    if not isinstance(key, str) or not re.fullmatch(r"[a-f0-9-]{32,64}", key):
        raise ValueError("readonly_reference_invalid")
    raw = read_private_bytes(directory(root, area) / (key + ".json"), limit)
    digest = sha256(raw).hexdigest()
    if expected_hash is not None and digest != expected_hash:
        raise ValueError("readonly_receipt_changed")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("readonly_receipt_invalid")
    return value, digest


def write_record(root, area, key, value):
    if not isinstance(key, str) or not re.fullmatch(r"[a-f0-9-]{32,64}", key):
        raise ValueError("readonly_reference_invalid")
    parent = directory(root, area, create=True)
    raw = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode()
    if len(raw) > 4 * 1024 * 1024:
        raise ValueError("readonly_private_budget_exceeded")
    target = parent / (key + ".json")
    fd, temporary = tempfile.mkstemp(prefix=".receipt-", dir=parent)
    try:
        with os.fdopen(fd, "wb") as output:
            output.write(raw)
            output.flush()
            os.fsync(output.fileno())
        try:
            os.link(temporary, target)
        except FileExistsError:
            if read_private_bytes(target, len(raw)) != raw:
                raise ValueError("readonly_receipt_conflict") from None
        parent_fd = os.open(parent, os.O_RDONLY)
        try:
            os.fsync(parent_fd)
        finally:
            os.close(parent_fd)
    finally:
        os.unlink(temporary)
    return sha256(raw).hexdigest()
