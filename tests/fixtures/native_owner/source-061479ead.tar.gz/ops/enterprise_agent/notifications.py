"""Trusted personal-bot notification coordinator, never a model tool or scheduler.

Only narrow references are retained. Delivery authority and source access are
rechecked for every send, receipt lookup and display. No default recipient exists.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta
import fcntl
import json
import os
from pathlib import Path
from zoneinfo import ZoneInfo

from ._ledger import PrivateJsonLedger, private_file

from .evidence import evidence_reference
from .workflow import identity


@dataclass(frozen=True)
class Signal:
    kind: str
    exception: str
    change: str
    action: str
    known_wait: bool = False
    due_at: str | None = None


class Notifications(PrivateJsonLedger):
    def __init__(self, database, *, recipient, timezone, binding, classify,
                 deadline_seconds=86400, policy_version="1"):
        if (type(deadline_seconds) is not int or deadline_seconds < 1
                or not isinstance(policy_version, str) or not policy_version):
            raise ValueError("invalid_policy_configuration")
        self.deadline_window = timedelta(seconds=deadline_seconds)
        if not isinstance(recipient, str) or not recipient:
            raise ValueError("stable_recipient_required")
        self.recipient = recipient
        self.zone = ZoneInfo(timezone)
        self.binding = binding
        self.classify = classify
        path = Path(database)
        self._open_ledger(path, "notifications")
        try:
            self.lock = os.fdopen(private_file(str(path) + ".lock"), "r+")
        except BaseException:
            self.db.close()
            raise
        config = dict(recipient=recipient, timezone=timezone, purpose="enterprise-agent-1327",
                      deadline_seconds=deadline_seconds, policy_version=policy_version)
        self.db.execute("INSERT OR IGNORE INTO notifications VALUES (1, ?)",
                        (json.dumps(dict(configuration=config, records={}, coverage={})),))
        self.db.commit()
        if self._read()["configuration"] != config:
            self.close()
            raise ValueError("configuration_drift")

    def close(self):
        self.db.close()
        self.lock.close()

    def _binding(self):
        try:
            value = self.binding(self.recipient)
            if (value["active"] is not True or value["private"] is not True
                    or value["user_id"] != self.recipient
                    or any(not isinstance(value[k], str) or not value[k]
                           for k in ("profile", "target", "revision"))):
                raise ValueError()
            return {k: value[k] for k in ("user_id", "profile", "target", "revision")}
        except Exception:
            raise ValueError("binding_unavailable") from None

    def records(self, workflow):
        visible = {m["id"] for m in workflow.matters()}
        return [r for r in self._read()["records"].values()
                if all(m in visible for m in r["matters"])]

    def coverage(self):
        return self._read()["coverage"]

    def _queue(self, *, key, content, matters):
        version = identity(content)
        notice_id = identity("enterprise-agent-1327", self.recipient, key, version)
        with self._transaction() as state:
            for old in state["records"].values():
                if old["key"] == key and old["id"] != notice_id and old["status"] in {"pending", "undeliverable"}:
                    old["status"] = "superseded"
            state["records"].setdefault(notice_id, dict(id=notice_id, key=key,
                content_version=version, content=content, matters=matters,
                status="pending", actual_receipt="unverified"))

    def _suppress(self, matter, key=None):
        with self._transaction() as state:
            for record in state["records"].values():
                if (matter in record["matters"]
                        and record["content"]["purpose"] == "enterprise-agent-important"
                        and (key is None or record["key"] == key)
                        and record["status"] in {"pending", "undeliverable"}):
                    record["status"] = "suppressed"

    def tick(self, workflow, outlet, *, now, maintenance=None, summarize_day=None):
        fcntl.flock(self.lock, fcntl.LOCK_EX)
        try:
            if now.utcoffset() is None:
                raise ValueError("aware_time_required")
            try:
                matters = workflow.available_matters()
            except ValueError:
                with self._transaction() as state:
                    state["coverage"]["source"] = "source_unavailable"
                return
            with self._transaction() as state:
                state["coverage"]["source"] = (
                    "source_unavailable" if workflow.unavailable_matters() else "available"
                )
            maintenance_signals = {}
            actions = []
            if maintenance is not None:
                try:
                    actions = maintenance.notification_actions(workflow)
                except ValueError:
                    with self._transaction() as state:
                        state["coverage"]["maintenance"] = "authority_unavailable"
                    return
                with self._transaction() as state:
                    state["coverage"]["maintenance"] = "available"
                for action in actions:
                    rule = action["decision"]["rule"]
                    pause = maintenance.pauses().get(rule)
                    if pause:
                        maintenance_signals[action["matter"]] = Signal("failure", "rule:" + rule,
                            pause.get("id", identity(pause)), "规则 " + rule + " 已暂停，请修复验证后由授权人员恢复：" + pause["reason"])
                    elif action["status"] in {"conflict", "rejected", "unauthorized", "unknown"}:
                        maintenance_signals[action["matter"]] = Signal("failure", "rule:" + rule,
                            identity(action["id"], action["status"]), "核对原动作及处理结果：" + action["status"])
                if summarize_day is not None:
                    self._summary(actions, matters, summarize_day, now)
            for matter in matters:
                signal = maintenance_signals.get(matter["id"]) or self.classify(matter)
                if signal is None or (isinstance(signal, Signal) and signal.known_wait):
                    self._suppress(matter["id"])
                    continue
                if not isinstance(signal, Signal) or signal.kind not in {"decision", "failure", "deadline"}:
                    raise ValueError("invalid_signal")
                if (any(not isinstance(value, str) or not 1 <= len(value) <= 1000
                        for value in (signal.exception, signal.change, signal.action))
                        or type(signal.known_wait) is not bool):
                    raise ValueError("invalid_signal")
                key = identity(matter["id"], signal.kind, signal.exception)
                if signal.kind == "deadline":
                    try:
                        due = datetime.fromisoformat(signal.due_at.replace("Z", "+00:00"))
                        if due.utcoffset() is None or due - now > self.deadline_window:
                            self._suppress(matter["id"], key)
                            continue
                    except (AttributeError, ValueError):
                        self._suppress(matter["id"], key)
                        continue
                # Reobserving a revision without a material change is silent.
                if any(r["key"] == key and r["content"]["change"] == signal.change
                       and r["content"].get("due_at") == signal.due_at
                       for r in self._read()["records"].values()):
                    continue
                content = dict(purpose="enterprise-agent-important", matter=matter["id"],
                    kind=signal.kind, change=signal.change, action=signal.action,
                    goal=matter["event"]["goal"], due_at=signal.due_at,
                    evidence=[evidence_reference(e) for e in matter["evidence"]])
                self._queue(key=key, content=content, matters=[matter["id"]])
            visible_ids = {m["id"] for m in matters}
            for notice in [r for r in self._read()["records"].values()
                           if all(m in visible_ids for m in r["matters"])]:
                if notice["status"] not in {"pending", "undeliverable", "unknown", "accepted"}:
                    continue
                if (notice["content"]["purpose"] == "enterprise-agent-daily-completions"
                        and notice["status"] in {"pending", "undeliverable"}):
                    latest = {m["id"]: m["revision"] for m in matters}
                    current = {a["id"] for a in actions if a["status"] == "verified"
                               and a["revision"] == latest[a["matter"]]
                               and a.get("receipt", {}).get("result", {}).get("status") == "DONE"}
                    if not all(i["action"] in current for i in notice["content"]["items"]):
                        with self._transaction() as state:
                            state["records"][notice["id"]]["status"] = "suppressed"
                        continue
                try:
                    binding = self._binding()
                    if notice.get("binding", binding) != binding:
                        raise ValueError("binding_drift")
                except ValueError:
                    with self._transaction() as state:
                        current = state["records"][notice["id"]]
                        if current["status"] in {"pending", "undeliverable"}:
                            current["status"] = "undeliverable"
                        current["reason"] = "binding_unavailable"
                    continue
                try:
                    visible = {m["id"] for m in workflow.available_matters()}
                    if not all(m in visible for m in notice["matters"]):
                        raise ValueError()
                except ValueError:
                    with self._transaction() as state:
                        state["coverage"]["source"] = "source_unavailable"
                    continue
                if notice["status"] in {"unknown", "accepted"}:
                    try:
                        self._receipt(notice, outlet.lookup(notice), binding)
                    except Exception:
                        pass
                    continue
                if any(r["key"] == notice["key"] and r["status"] == "unknown"
                       for r in self._read()["records"].values()):
                    continue
                notice.update(binding=binding, status="unknown")
                with self._transaction() as state:
                    state["records"][notice["id"]] = notice
                try:
                    self._receipt(notice, outlet.send(notice), binding)
                except Exception:
                    pass  # Unknown must be reconciled, never blindly sent again.
        finally:
            fcntl.flock(self.lock, fcntl.LOCK_UN)

    def _summary(self, actions, matters, business_day, now):
        day = datetime.strptime(business_day, "%Y-%m-%d").date()
        if day >= now.astimezone(self.zone).date():
            raise ValueError("completed_business_day_required")
        visible = {m["id"]: m for m in matters}
        items = []
        for action in actions:
            if (action["status"] != "verified" or action["decision"]["kind"] != "complete"
                    or action.get("receipt", {}).get("result", {}).get("status") != "DONE"):
                continue
            source = visible[action["matter"]]
            if source["revision"] != action["revision"]:
                continue  # Corrected/reopened completions aren't presented as current.
            business_at = source["event"]["business_at"]
            if datetime.fromisoformat(business_at.replace("Z", "+00:00")).astimezone(self.zone).date() != day:
                continue
            items.append(dict(action=action["id"], matter=action["matter"],
                code=action["receipt"]["result"]["code"], result="DONE",
                evidence=[evidence_reference(e) for e in action["evidence"]]))
        if items:
            items.sort(key=lambda item: item["action"])
            self._queue(key="daily:" + business_day,
                content=dict(purpose="enterprise-agent-daily-completions", business_day=business_day,
                             items=items), matters=sorted({i["matter"] for i in items}))

    def _receipt(self, notice, receipt, binding):
        if (not isinstance(receipt, dict) or receipt.get("id") != notice["id"]
                or receipt.get("content_version") != notice["content_version"]
                or receipt.get("binding") != binding or receipt.get("state") != "accepted"
                or not isinstance(receipt.get("channel_id"), str) or not receipt["channel_id"]):
            return
        if self._binding() != binding:
            return
        with self._transaction() as state:
            state["records"][notice["id"]].update(status="accepted", receipt=receipt)


class HermesOutlet:
    """Reuse the existing strict DM/no-replay sender, with no cron registration.

    The native CLI cannot query an unknown send or prove actual human receipt.
    Such records therefore remain unknown until an authoritative outlet provides
    matching evidence; deleting the record is never a recovery procedure.
    """
    def __init__(self, root):
        from hermes import production_reminders
        self.sender = production_reminders
        self.root = Path(root)

    def send(self, notice):
        binding = notice["binding"]
        if self.sender.strict_daily_target(self.root, binding["profile"]) != binding["target"]:
            raise ValueError("binding_unavailable")
        def safe(value):
            return " ".join(str(value).split()).replace("MEDIA:", "MEDIA：")
        content = notice["content"]
        if content["purpose"] == "enterprise-agent-daily-completions":
            lines = ["【Agent 普通完成日汇总】", "业务日期：" + content["business_day"]]
            for item in content["items"]:
                lines.append("已核验完成：" + safe(item["code"]))
                lines.extend("依据：" + safe(e["evidence"]) for e in item["evidence"])
        else:
            lines = ["【Agent 重要提醒】", "事项：" + safe(content.get("goal", content["matter"])),
                     "需处理：" + safe(content["action"])]
            if content.get("due_at"):
                lines.append("明确截止：" + safe(content["due_at"]))
            lines.extend("依据：" + safe(e["evidence"]) for e in content["evidence"])
        text = "\n".join(lines)
        channel_id = self.sender.daily_sender(self.root, expected_target=binding["target"])(
            binding["profile"], binding["profile"], text)
        return dict(id=notice["id"], content_version=notice["content_version"],
                    binding=binding, state="accepted", channel_id=channel_id)

    def lookup(self, notice):
        return None
