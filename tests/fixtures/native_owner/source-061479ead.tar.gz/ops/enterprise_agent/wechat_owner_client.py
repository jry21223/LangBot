"""Owner-only cached wx reads. No account lifecycle, download, send or acknowledgement."""

from contextlib import contextmanager
from hashlib import sha256
import json
import re
import time
from urllib.parse import quote

from ._http_budget import current_deadline, open_http
from .readonly_private import read_private_bytes
from .source_http import _endpoint


def _id(value):
    if (
        not isinstance(value, str)
        or not 1 <= len(value) <= 512
        or any(ord(c) < 33 for c in value)
        or any(c in value for c in "/\\?#")
        or value in {".", ".."}
    ):
        raise ValueError("owner_unavailable")
    return value


def _recall_timestamp(value):
    from datetime import datetime

    if not isinstance(value, str) or not re.fullmatch(
        r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})", value
    ):
        raise ValueError("owner_unavailable")
    try:
        if datetime.fromisoformat(value.replace("Z", "+00:00")).utcoffset() is None:
            raise ValueError()
    except (ValueError, OverflowError):
        raise ValueError("owner_unavailable") from None


def _confirmed_recall(raw):
    # NativeRecallInfo is emitted by the exact single-message resource after upstream
    # target checks. System type 10000 alone also represents ordinary notices.
    marker = raw.get("recall")
    if marker is None:
        return False
    if (
        raw["type"] != 10000
        or not isinstance(marker, dict)
        or "observedAt" not in marker
        or set(marker) - {"observedAt", "recalledAt", "replacementText"}
    ):
        raise ValueError("owner_unavailable")
    _recall_timestamp(marker["observedAt"])
    if "recalledAt" in marker:
        _recall_timestamp(marker["recalledAt"])
    replacement = marker.get("replacementText")
    if replacement is not None and (
        not isinstance(replacement, str) or len(replacement.encode()) > 16384
    ):
        raise ValueError("owner_unavailable")
    return True


class WxOwnerClient:
    def __init__(self, endpoint, *, token_file, account, thread, timeout=15):
        parsed = _endpoint(endpoint)
        if (
            parsed.path.rstrip("/") != "/v1"
            or not isinstance(timeout, (int, float))
            or not 0 < timeout <= 30
        ):
            raise ValueError("owner_unavailable")
        self.endpoint = endpoint.rstrip("/")
        self.account, self.thread = _id(account), _id(thread)
        self.token_file, self.timeout = token_file, timeout
        self.token_hash = sha256(self._token().encode()).hexdigest()

    def _token(self):
        try:
            token = read_private_bytes(self.token_file, 4096).decode().strip()
            if not 16 <= len(token) <= 4096 or any(c.isspace() for c in token):
                raise ValueError()
            if (
                hasattr(self, "token_hash")
                and sha256(token.encode()).hexdigest() != self.token_hash
            ):
                raise ValueError()
            return token
        except Exception:
            raise ValueError("owner_unavailable") from None

    @contextmanager
    def _budget(self):
        token = current_deadline.set(
            min(time.monotonic() + self.timeout, current_deadline.get() or float("inf"))
        )
        try:
            yield
        finally:
            current_deadline.reset(token)

    def _read(self, suffix, *, binary=False, limit=1024 * 1024):
        response = None
        try:
            path = "/accounts/" + quote(self.account, safe="") + suffix
            response = open_http(
                self.endpoint + path,
                headers={"Authorization": "Bearer " + self._token()},
                timeout=self.timeout,
                limit=limit,
            )
            if response.status != 200:
                raise ValueError()
            data = response.read()
            if binary:
                return data, response.headers.get("Content-Type", "").split(";", 1)[0]
            result = json.loads(data)
            if not isinstance(result, dict):
                raise ValueError()
            return result
        except Exception:
            raise ValueError("owner_unavailable") from None
        finally:
            if response is not None:
                response.close()

    def _asset(self, raw, message_id):
        if (
            not isinstance(raw, dict)
            or raw.get("accountId") != self.account
            or raw.get("messageId") != message_id
        ):
            raise ValueError("owner_unavailable")
        asset = dict(
            asset_id=_id(raw.get("id")),
            kind=raw.get("kind"),
            state=raw.get("state"),
            sha256=raw.get("sha256"),
            byte_length=raw.get("byteLength"),
            content_type=raw.get("contentType"),
        )
        if (
            not isinstance(asset["kind"], str)
            or asset["kind"] not in {"image", "voice", "file", "video", "sticker"}
            or not isinstance(asset["state"], str)
            or asset["state"]
            not in {
                "available",
                "pending",
                "expired",
                "failed",
                "unsupported",
                "cancelled",
                "needs_review",
            }
        ):
            raise ValueError("owner_unavailable")
        if asset["state"] == "available" and (
            not isinstance(asset["sha256"], str)
            or not re.fullmatch(r"[a-f0-9]{64}", asset["sha256"])
            or type(asset["byte_length"]) is not int
            or not 0 <= asset["byte_length"] <= 32 * 1024**2
            or not isinstance(asset["content_type"], str)
            or not re.fullmatch(
                r"[A-Za-z0-9!#$&^_.+-]+/[A-Za-z0-9!#$&^_.+-]+", asset["content_type"]
            )
        ):
            raise ValueError("owner_unavailable")
        return asset

    def status(self):
        """Only fresh documented runtime facts; no nickname or arbitrary account data."""
        from datetime import datetime, timezone

        with self._budget():
            try:
                raw = self._read("")
                if (
                    raw.get("id") != self.account
                    or type(raw.get("authenticated")) is not bool
                    or type(raw.get("contactSyncReady")) is not bool
                    or raw.get("connection")
                    not in {"online", "reconnecting", "disconnected"}
                    or raw.get("incomingTransport")
                    not in {"native_push", "heartbeat_polling", "disconnected"}
                ):
                    return None
                return dict(
                    account=raw["id"],
                    authenticated=raw["authenticated"],
                    connection=raw["connection"],
                    incoming_transport=raw["incomingTransport"],
                    contact_sync_ready=raw["contactSyncReady"],
                    observed_at=datetime.now(timezone.utc).isoformat(),
                )
            except (ValueError, TypeError):
                return None

    def message(self, message_id):
        with self._budget():
            message_id = _id(message_id)
            raw = self._read("/messages/" + quote(message_id, safe=""))
            if (
                raw.get("id") != message_id
                or raw.get("accountId") != self.account
                or raw.get("threadId") != self.thread
            ):
                raise ValueError("owner_unavailable")
            native_version = _id(raw.get("version"))
            if type(raw.get("type")) is not int or not 0 <= raw["type"] <= 2147483647:
                raise ValueError("owner_unavailable")
            recalled = _confirmed_recall(raw)
            if raw.get("direction") not in (None, "incoming") and not recalled:
                raise ValueError("owner_unavailable")
            kind = {
                1: "text",
                3: "image",
                34: "voice",
                43: "video",
                47: "sticker",
                49: "file",
            }.get(raw.get("type"), "unsupported")
            media = []
            if kind in {"image", "voice", "file", "video", "sticker"} and not recalled:
                result = self._read(
                    "/messages/" + quote(message_id, safe="") + "/media"
                )
                if (
                    not isinstance(result.get("items"), list)
                    or len(result["items"]) > 100
                ):
                    raise ValueError("owner_unavailable")
                media = [self._asset(a, message_id) for a in result["items"]]
                if len({a["asset_id"] for a in media}) != len(media):
                    raise ValueError("owner_unavailable")
            return dict(
                account_id=self.account,
                thread_id=self.thread,
                message_id=message_id,
                sender_id=raw.get("senderId"),
                server_id=raw.get("serverId"),
                message_type=kind,
                direction=raw.get("direction"),
                native_version=native_version,
                body=raw.get("body"),
                media=sorted(media, key=lambda a: a["asset_id"]),
                recalled=recalled,
                business_at=raw.get("createdAt"),
            )

    def media(self, message_id, expected):
        with self._budget():
            if not isinstance(expected, dict) or set(expected) != {
                "asset_id",
                "kind",
                "state",
                "sha256",
                "byte_length",
                "content_type",
            }:
                raise ValueError("owner_unavailable")
            before = self.message(message_id)
            if (
                before["recalled"]
                or expected["state"] != "available"
                or expected not in before["media"]
            ):
                raise ValueError("owner_unavailable")
            asset_id = _id(expected["asset_id"])
            asset = self._asset(
                self._read("/media/" + quote(asset_id, safe="")), message_id
            )
            if asset != expected:
                raise ValueError("owner_unavailable")
            data, mime = self._read(
                "/media/" + quote(asset_id, safe="") + "/content",
                binary=True,
                limit=min(expected["byte_length"] + 1, 32 * 1024**2 + 1),
            )
            if (
                len(data) != expected["byte_length"]
                or sha256(data).hexdigest() != expected["sha256"]
                or mime != expected["content_type"]
                or {
                    k: v
                    for k, v in self.message(message_id).items()
                    if k != "native_version"
                }
                != {k: v for k, v in before.items() if k != "native_version"}
                or self._asset(
                    self._read("/media/" + quote(asset_id, safe="")), message_id
                )
                != expected
            ):
                raise ValueError("owner_unavailable")
            return data
