"""Native candidate understanding; trusted association remains a separate decision.

The model returns bounded codes and references. It cannot confer source grants,
choose tools, invent owners, or write business facts. Originals remain at owner.
"""
from copy import deepcopy
from hashlib import sha256
import hmac
import json
import re
import time

from .wecom_projection import SavedArchive
from .workflow import identity, action_identity
from ._http_budget import current_deadline
from .source_goals import catalog_identity, source_goals, validate_goal_scopes, is_observation_goal

INTENTS = {"progress", "action", "chat", "already_done", "reference", "completion", "correction", "new_goal"}
KINDS = {"internal_sample", "customer_sample", "selection", "research", "other"}
CLUES = {"supplier", "product", "batch", "transaction", "person"}


def signed_input(value, key):
    return hmac.new(key, json.dumps(value, sort_keys=True, separators=(",", ":")).encode(), "sha256").hexdigest()


def validate_goal_catalog(goals):
    if not isinstance(goals, list) or len(goals) > 100:
        raise ValueError("invalid_goal_catalog")
    for goal in goals:
        if (set(goal) - {"completion_phrases", "correction_phrases", "new_goal_phrases", "gd_code", "allow_new", "observation_source"}
                != {"id", "kind", "status", "clues", "reporters"}
                or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,200}", goal["id"])
                or goal["kind"] not in KINDS or goal["status"] not in {"OPEN", "DONE", "NEW"}
                or not isinstance(goal["clues"], dict) or not set(goal["clues"]) <= CLUES
                or any(not isinstance(v, str) or not 1 <= len(v) <= 200 for v in goal["clues"].values())
                or not isinstance(goal["reporters"], list)
                or any(not isinstance(v, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", v)
                       for v in goal["reporters"])
                or any(not isinstance(goal.get(k, []), list) or len(goal.get(k, [])) > 20
                       or any(not isinstance(v, str) or not 2 <= len(v) <= 200 for v in goal.get(k, []))
                       for k in ("completion_phrases", "correction_phrases", "new_goal_phrases"))
                or type(goal.get("allow_new", False)) is not bool
                or ("gd_code" in goal and (not isinstance(goal["gd_code"], str)
                    or not re.fullmatch(r"GD-[A-Za-z0-9-]{1,60}", goal["gd_code"])))):
            raise ValueError("invalid_goal_catalog")
        if 'observation_source' in goal:
            binding = goal['observation_source']
            if (not isinstance(binding, dict) or set(binding) != {'source', 'scope'}
                    or any(not isinstance(binding[k], str) or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,200}', binding[k])
                           for k in ('source', 'scope'))
                    or not is_observation_goal(goal, binding['source'], binding['scope'])):
                raise ValueError('invalid_goal_catalog')
    if len({g["id"] for g in goals}) != len(goals):
        raise ValueError("invalid_goal_catalog")



class Understanding:
    def __init__(self, producer, *, sources, goals, input_key, reviewers=(), exact_goal_rule=None,
                 project=None, qualify_input=None, goal_scopes=None, source_document=None):
        if not isinstance(input_key, bytes) or len(input_key) < 32:
            raise ValueError("private_input_key_required")
        self.producer, self.workflow, self.sources = producer, producer.workflow, sources
        self.goals, self.input_key = deepcopy(goals), input_key
        if (not isinstance(reviewers, (list, tuple)) or len(reviewers) > 100
                or any(not isinstance(v, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", v) for v in reviewers)):
            raise ValueError("invalid_reviewers")
        self.reviewers = frozenset(reviewers)
        self.exact_goal_rule, self.project = exact_goal_rule, project
        self.qualify_input = qualify_input
        self.source_document = deepcopy(source_document)
        validate_goal_catalog(self.goals)
        self.goal_scopes = deepcopy(goal_scopes)
        validate_goal_scopes(self.goals, self.goal_scopes)
        catalog = catalog_identity(self.goals, self.goal_scopes)
        with self.workflow._transaction() as state:
            if state["producer"].setdefault("goal_catalog", catalog) != catalog:
                raise ValueError("configuration_drift")
        self.workflow.understanding = self

    def _candidate(self, candidate_id):
        return self.workflow._read()["producer"]["candidates"][candidate_id]

    def _event(self, candidate):
        return dict(source=candidate["source"], scope=candidate["scope"],
                    record=candidate["change"]["record"], version=candidate["change"]["version"],
                    evidence=candidate["change"]["original"])

    def _projection(self, candidate, selection):
        if self.project is not None:
            return self.project(candidate, selection)
        return SavedArchive(self.workflow, source=candidate["source"], scope=candidate["scope"]).project(
            candidate["change"]["saved"], decision=selection)

    def _authorize(self, candidate, stage, agent):
        if self.qualify_input is not None:
            self.qualify_input()
        grant = self.workflow._grant(candidate["source"], stage, agent, candidate["scope"])
        if grant != candidate["authority"]:
            raise ValueError("source_unavailable")
        event = self._event(candidate)
        if self.workflow.authorize_evidence is not None:
            self.workflow.authorize_evidence(event, stage, agent)
        latest = [c for c in self.workflow._read()["producer"]["candidates"].values()
                  if c["source"] == candidate["source"]
                  and c["change"]["record"] == candidate["change"]["record"]]
        if any(c["change"]["sequence"] > candidate["change"]["sequence"] for c in latest):
            raise ValueError("stale_understanding")

    def authorize(self, action, stage, agent):
        candidate = self._candidate(action["candidate"])
        self._authorize(candidate, stage, agent)
        current = candidate.get("understanding", {})
        if stage != "display" and current.get("action") != action["id"]:
            raise ValueError("stale_understanding")

    def start(self, candidate_id):
        candidate = self._candidate(candidate_id)
        self._authorize(candidate, "ingest", None)
        projection = self._projection(candidate, dict(goal="unresolved", confirmed=True, intent="reference", candidates=[]))
        if (candidate["status"] == "admitted" or candidate["change"].get("original_available", True) is not True
                or candidate["change"]["kind"] == "recalled"
                or projection.get("review_required", False) or projection.get("confirmed") is not True):
            raise ValueError("understanding_ineligible")
        with self.workflow._transaction() as state:
            current = state["producer"]["candidates"][candidate_id]
            if current.get("understanding"):
                return current["understanding"]["action"]
            revision = current.setdefault("judgment_revision", 1)
            key = action_identity(candidate_id, "understand", revision, self.producer.model_version)
            channel = identity(self.workflow.workspace, current["scope"], "proposal", current["source"],
                               current["change"]["record"])
            current["understanding"] = dict(version=revision, action=key, status="queued",
                                            history=deepcopy(current.get("judgment_history", [])))
            current["status"] = "understanding"
            state["outbox"][key] = dict(id=key, matter=channel, candidate=candidate_id,
                subject_type="proposal", revision=candidate_id, judgment_version=revision,
                agent=self.workflow.coordinator, stage="understand", status="pending")
            return key

    def reconsider(self, candidate_id, *, actor, reason):
        """Trusted control revision; never rewrites the owner's source event."""
        candidate = self._candidate(candidate_id)
        self._authorize(candidate, "ingest", None)
        if actor not in self.reviewers or reason not in {"association_correction", "missing_evidence_resolved", "runtime_recovered"}:
            raise ValueError("trusted_review_required")
        with self.workflow._transaction() as state:
            current = state["producer"]["candidates"][candidate_id]
            old = current.get("understanding")
            if not old:
                raise ValueError("no_judgment")
            action = state["outbox"][old["action"]]
            if reason == "runtime_recovered" and action["status"] != "failed":
                raise ValueError("failed_execution_required")
            if action["status"] == "delivery_unknown":
                raise ValueError("recover_original_delivery_first")
            history = current.setdefault("judgment_history", [])
            history.append({**{k: deepcopy(v) for k, v in old.items() if k != "history"},
                            "review_actor": actor, "review_reason": reason})
            current["judgment_revision"] = old["version"] + 1
            if action["status"] in {"pending", "sent"}:
                action["status"] = "superseded"
            if current.get("matter"):
                current.update(status="readjudication_pending")
                old.update(status="needs_review", version=current["judgment_revision"], history=deepcopy(history),
                           reason="cross_matter_rebinding_requires_review")
                matter = state["matters"][current["matter"]]
                matter.update(status="needs_review", judgment_control=dict(version=current["judgment_revision"],
                    candidate=candidate_id, actor=actor, reason=reason))
                matter["current_run_id"] = identity(matter["id"], candidate_id, "judgment_control",
                                                    current["judgment_revision"])
                plan = state.get("wake_plans", {}).get(matter["id"])
                if plan is not None:
                    plan.update(status="invalidated", invalidated_reason="judgment_control")
                for pending in state["outbox"].values():
                    if pending["matter"] == matter["id"] and pending["status"] in {"pending", "sent", "delivery_unknown"}:
                        pending["status"] = "superseded"
                return
            # A held interpretation has no admitted matter. Its preparation
            # receipt belongs to the archived judgment, not the next control.
            if "admission_receipt" in current:
                history[-1]["admission_receipt"] = current.pop("admission_receipt")
            current.pop("understanding")
        return self.start(candidate_id)

    def dispatch_one(self, workspace, action):
        self.authorize(action, "dispatch", action["agent"])
        candidate = self._candidate(action["candidate"])
        goals = source_goals(self.goals, self.goal_scopes, candidate["source"], candidate["scope"])
        workspace.ensure_thread(action["matter"], self.workflow.coordinator, [])
        envelope = dict(version=1, stage="understand", action=action["id"], candidate=candidate["id"],
            workspace=self.workflow.workspace, agent=action["agent"], channel=action["matter"],
            source=candidate["source"], scope=candidate["scope"], reference=candidate["change"]["original"],
            source_version=candidate["change"]["version"], judgment_version=action["judgment_version"],
            model_version=self.producer.model_version, rule_version=self.producer.rule_version)
        content = dict(understand_input=envelope, input_signature=signed_input(envelope, self.input_key),
            mode="observe", allowed_action="read_only_understanding",
            candidate_goals=[dict(id=g["id"], kind=g["kind"], clue_fields=sorted(g["clues"])) for g in goals],
            reply_contract=dict(intent=sorted(INTENTS), kind=sorted(KINDS), goals="zero or more exact candidate IDs",
                clues=sorted(CLUES), evidence=[envelope["reference"]], ambiguities="bounded missing field codes only"))
        content["reply_schema"] = dict(type="object", additionalProperties=False,
            required=["intent", "kind", "goals", "clues", "evidence", "ambiguities"], properties={
                "intent": dict(type="string", enum=sorted(INTENTS)),
                "kind": dict(type="string", enum=sorted(KINDS)),
                **{field: dict(type="array", items=dict(type="string"), maxItems=20)
                   for field in ("goals", "clues", "evidence", "ambiguities")}})
        for field, values in {
            "goals": [g["id"] for g in goals], "clues": sorted(CLUES),
            "evidence": [envelope["reference"]],
            "ambiguities": ["goal", "supplier", "product", "batch", "transaction", "person", "reporter", "completion", "kind"],
        }.items():
            content["reply_schema"]["properties"][field]["items"]["enum"] = values
        message = dict(network=self.workflow.workspace, source="system:enterprise-agent-1324",
            type="workspace.message.posted", target="channel/" + action["matter"], idempotency_key=action["id"],
            metadata=dict(target_agents=[action["agent"]], delivery_key=action["id"]),
            payload=dict(message_type="chat", content=json.dumps(content, ensure_ascii=False)))
        self.workflow._deliver(workspace, action, message)

    def receive(self, reply, action):
        if (action["status"] != "sent" or reply.get("source") != "openagents:" + action["agent"]
                or reply.get("target") != "channel/" + action["matter"]
                or reply.get("type") != "workspace.message.posted"
                or reply.get("metadata", {}).get("status_kind") not in {"completed", "error"}):
            return False
        self.authorize(action, "result", action["agent"])
        content = reply.get("payload", {}).get("content")
        parsed = None
        try:
            if not isinstance(content, str) or len(content.encode()) > 16000:
                raise ValueError()
            parsed = json.loads(content)
            if (set(parsed) != {"intent", "kind", "goals", "clues", "evidence", "ambiguities"}
                    or parsed["intent"] not in INTENTS or parsed["kind"] not in KINDS
                    or any(not isinstance(parsed[k], list) or len(parsed[k]) > 20 for k in
                           ("goals", "clues", "evidence", "ambiguities"))
                    or any(not isinstance(v, str) or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,512}", v)
                           for k in ("goals", "clues", "evidence", "ambiguities") for v in parsed[k])
                    or not set(parsed["clues"]) <= CLUES
                    or parsed["evidence"] != [self._candidate(action["candidate"])["change"]["original"]]):
                raise ValueError()
        except (ValueError, TypeError, KeyError):
            parsed = None
        failed = reply["metadata"]["status_kind"] == "error"
        with self.workflow._transaction() as state:
            current = state["outbox"][action["id"]]
            if current["status"] != "sent":
                return False
            current["status"] = "failed" if failed else "completed"
            judgment = state["producer"]["candidates"][action["candidate"]]["understanding"]
            judgment.update(status="ready" if parsed is not None and not failed else "needs_review",
                            result=parsed, result_reference=reply.get("id"),
                            native_response_key=reply.get("idempotency_key"),
                            response_hash=sha256(content.encode()).hexdigest() if isinstance(content, str) else None)
            if parsed is None or failed:
                state["producer"]["candidates"][action["candidate"]]["status"] = "needs_review"
        return True

    def _resolve(self, candidate, parsed, original):
        # Independent, reviewed catalog + literal owner-original corroboration.
        # Model-selected IDs, confidence, amount, and time never establish linkage.
        goals = source_goals(self.goals, self.goal_scopes, candidate["source"], candidate["scope"])
        observations = [g for g in goals if is_observation_goal(g, candidate['source'], candidate['scope'])]
        if observations:
            if (len(goals) != 1 or len(observations) != 1 or parsed['kind'] != 'research'
                    or parsed['goals'] != [observations[0]['id']]
                    or any(value in {'goal', 'kind'} for value in parsed['ambiguities'])
                    or parsed['intent'] not in {'action', 'progress', 'correction', 'new_goal'}):
                return None
            return deepcopy(observations[0])
        matches = [g for g in goals if g["kind"] == parsed["kind"] and
            len([k for k, v in g["clues"].items() if k in parsed["clues"] and v in original["content"]]) >= 2]
        if (parsed["ambiguities"] or len(matches) != 1 or parsed["goals"] != [matches[0]["id"]]):
            return None
        target = deepcopy(matches[0])
        explicit = candidate["change"].get("goal_reference")
        if explicit and target.get("gd_code") != explicit:
            return None
        if "gd_code" in target:
            if self.exact_goal_rule is None:
                return None
            exact_candidate = deepcopy(candidate)
            exact_candidate["change"]["goal_reference"] = target["gd_code"]
            actual = self.exact_goal_rule(exact_candidate)
            if actual is None or actual.goal != target["id"]:
                return None
            target["status"] = "DONE" if actual.target["status"] in {"DONE", "CANCELLED"} else "OPEN"
        return target

    def admit_ready(self, *, limit=20, deadline=None):
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("invalid_understanding_limit")
        candidates = [c for c in self.workflow._read()["producer"]["candidates"].values()
                      if c.get("understanding", {}).get("status") == "ready"]
        selected = self.workflow._window(candidates, "understanding_admit_position", limit)
        for index, candidate in enumerate(selected):
            if deadline is not None and time.monotonic() >= deadline:
                break
            budget = current_deadline.set(None if deadline is None else time.monotonic() +
                max(0, deadline - time.monotonic()) / (len(selected) - index))
            try:
                self._admit_one(candidate)
            except (ValueError, OSError):
                continue
            finally:
                current_deadline.reset(budget)

    def admission_current(self, state, candidate):
        """Pure coordination fence, shared by preparation and atomic ingest."""
        current = state["producer"]["candidates"].get(candidate["id"])
        judgment = candidate.get("understanding", {})
        return (current == candidate and judgment.get("status") == "ready"
            and state["outbox"][judgment["action"]]["status"] == "completed"
            and not any(c["source"] == candidate["source"]
                and c["change"]["record"] == candidate["change"]["record"]
                and c["change"]["sequence"] > candidate["change"]["sequence"]
                for c in state["producer"]["candidates"].values()))

    def _admit_one(self, candidate):
        self._authorize(candidate, "ingest", None)
        def hold():
            with self.workflow._transaction() as state:
                current = state["producer"]["candidates"][candidate["id"]]
                if not self.admission_current(state, candidate):
                    raise ValueError("judgment_changed")
                current.update(status="needs_review", reason="needs_review")
        judgment = candidate["understanding"]
        parsed = judgment["result"]
        try:
            from .source_document_queries import understanding_original
            original, input_digest, window = understanding_original(self.sources[candidate['source']],self._event(candidate),
                agent=self.workflow.coordinator,goals=source_goals(self.goals,self.goal_scopes,candidate['source'],candidate['scope']),
                config=self.source_document)
            target = self._resolve(candidate, parsed, original)
        except (ValueError, OSError):
            return
        continue_document=(window is not None and window['complete'] is False)
        if continue_document:
            # An incomplete prefix cannot establish that its unread suffix has no work.
            # This is a source-reading observation, never inferred business/GD linkage.
            target=source_goals(self.goals,self.goal_scopes,candidate['source'],candidate['scope'])[0]
            result='admitted'
        elif parsed["intent"] in {"chat", "already_done", "reference"}:
            result = "recorded"
        elif target is None:
            result = "needs_review"
        else:
            result = "admitted"
        if result != "admitted":
            with self.workflow._transaction() as state:
                current = state["producer"]["candidates"][candidate["id"]]
                if not self.admission_current(state, candidate):
                    raise ValueError("judgment_changed")
                current.update(status=result)
                current["understanding"].update(status=result, reason="no_unique_target" if target is None else "record_only")
            return
        goal_id = target["id"]
        intent = "action" if continue_document else parsed["intent"]
        if target["status"] == "NEW" and intent != "new_goal":
            hold()
            return
        reporter = self._projection(candidate, dict(goal="unresolved", confirmed=True, intent="reference", candidates=[]))[
            "evidence_details"].get("sender_user_id")
        recommendation = "continue_source_document" if continue_document else "progress"
        if intent in {"completion", "correction"}:
            phrases = target.get("completion_phrases" if intent == "completion" else "correction_phrases", [])
            if (reporter not in target["reporters"] or not phrases
                    or not any(phrase in original["content"] for phrase in phrases)):
                hold()
                return
            recommendation = "complete" if intent == "completion" else "reopen"
        if intent == "new_goal":
            if (target["status"] not in {"DONE", "NEW"} or not target.get("new_goal_phrases")
                    or (target["status"] == "NEW" and (not target.get("allow_new")
                        or not {"batch", "transaction"}.intersection(target["clues"])))
                    or not any(phrase in original["content"] for phrase in target["new_goal_phrases"])):
                hold()
                return
            goal_id = "new:" + (identity(target["id"], candidate["source"], candidate["change"]["record"])
                if target["status"] == "DONE" else identity(target["id"], sorted(target["clues"].items())))
            recommendation = "new_goal"
        receipt = identity(candidate["id"], self.producer.rule_version, judgment["version"], parsed, goal_id)
        with self.workflow._transaction() as state:
            current = state["producer"]["candidates"][candidate["id"]]
            if not self.admission_current(state, candidate):
                raise ValueError("judgment_changed")
            if current.get("admission_receipt") not in {None, receipt}:
                raise ValueError("admission_conflict")
            current.update(status="prepared_semantic", admission_receipt=receipt)
            current["understanding"].update(recommendation=recommendation, target=goal_id,
                input_hash=input_digest, input_hash_kind="source_document_window_v1" if window else "full_text_utf8_sha256", rule_version=self.producer.rule_version,
                model_version=self.producer.model_version)
            prepared = deepcopy(current)
        selection = dict(goal=goal_id, confirmed=True, intent="action", candidates=[goal_id])
        event = self._projection(candidate, selection)
        event["evidence_details"].update(admission_receipt=receipt, judgment_version=judgment["version"],
            recommendation=recommendation, result_reference=judgment["result_reference"])
        if "gd_code" in target and intent != "new_goal":
            event["evidence_details"]["goal_reference"] = target["gd_code"]
        old_cursor = (self.workflow.coverage(candidate["source"]) or {}).get("cursor")
        self.workflow.ingest(event, cursor=receipt, previous_cursor=old_cursor, retain_historical=True,
                             semantic_admission=prepared)

    def poll(self, workspace, *, limit=20, deadline=None):
        values = [c for c in self.workflow._read()["producer"]["candidates"].values() if c.get("understanding")]
        selected = self.workflow._window(values, "understanding_poll_position", limit)
        for index, candidate in enumerate(selected):
            if deadline is not None and time.monotonic() >= deadline:
                break
            budget = current_deadline.set(None if deadline is None else time.monotonic() +
                max(0, deadline - time.monotonic()) / (len(selected) - index))
            action = self.workflow._read()["outbox"][candidate["understanding"]["action"]]
            try:
                self.authorize(action, "display", None)
                replies, cursor = workspace.replies(action["matter"], candidate["understanding"].get("cursor"))
                for reply in replies:
                    self.workflow.reconcile_delivery(reply)
                    self.workflow.receive(reply)
                with self.workflow._transaction() as state:
                    state["producer"]["candidates"][candidate["id"]]["understanding"]["cursor"] = cursor
            except (ValueError, OSError):
                continue
            finally:
                current_deadline.reset(budget)
