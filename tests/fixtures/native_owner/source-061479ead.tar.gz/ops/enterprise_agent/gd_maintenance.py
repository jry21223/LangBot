"""Trusted GD-only maintenance consumer; never accepts model tool authorizations.

The Workflow owns source grants and collection. This store holds coordination
references/receipts only. The injected MCP boundary owns transport, signing and
live employee eligibility; no credential or approval token is persisted here.
"""
from contextlib import contextmanager
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import fcntl
import json
import os
from pathlib import Path
from urllib.parse import urlencode, urlsplit

from ._ledger import PrivateJsonLedger, private_file

from .evidence import evidence_reference
from .workflow import action_identity, identity


@dataclass(frozen=True)
class Rule:
    id: str
    version: str


@dataclass(frozen=True)
class Decision:
    rule: str
    kind: str
    title: str
    note: str
    exact_goal: bool = False
    explicit: bool = False
    related_person: bool = False
    business_completion: bool = False
    contradictory: bool = False
    corrects: str | None = None


class Maintenance(PrivateJsonLedger):
    def __init__(self, database, *, rules, authorize, decide, link_base):
        rules = list(rules)
        if (not rules or any(not isinstance(r, Rule) or not r.id or not r.version for r in rules)
                or len({r.id for r in rules}) != len(rules)):
            raise ValueError("invalid_rules")
        parsed = urlsplit(link_base)
        if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("invalid_gd_link")
        self.rules = {r.id: r for r in rules}
        self.authorize = authorize
        self.decide = decide
        self._workflow = None
        self.link_base = link_base.rstrip("/")
        path = Path(database)
        self._open_ledger(path, "gd_state")
        try:
            self.lock = os.fdopen(private_file(str(path) + ".lock"), "r+")
        except BaseException:
            self.db.close()
            raise
        config = dict(rules=[asdict(r) for r in rules], link_base=self.link_base)
        self.db.execute("INSERT OR IGNORE INTO gd_state VALUES (1, ?)", (json.dumps(
            dict(configuration=config, matters={}, actions={}, pauses={})),))
        self.db.commit()
        if self._read()["configuration"] != config:
            self.close()
            raise ValueError("configuration_drift")

    def close(self):
        self.db.close()
        self.lock.close()

    def _grant(self, rule, matter, stage):
        try:
            grant = self.authorize(rule, matter, stage)
            if grant["active"] is not True or any(not isinstance(grant[k], str) or not grant[k]
                    for k in ("operator_id", "operator_name", "profile_id", "revision")):
                raise ValueError()
            return {k: grant[k] for k in ("operator_id", "operator_name", "profile_id", "revision")}
        except Exception:
            raise ValueError("authority_unavailable") from None

    def _visible(self, workflow=None, *, available_only=False):
        workflow = workflow or self._workflow
        if workflow is None:
            raise ValueError("authorized_workflow_required")
        return {m["id"]: m for m in (
            workflow.available_matters() if available_only else workflow.matters()
        )}

    def matters(self, workflow=None):
        visible = self._visible(workflow)
        return [m for m in self._read()["matters"].values() if m["id"] in visible]

    def actions(self, workflow=None, *, available_only=False):
        visible = self._visible(workflow, available_only=available_only)
        return [a for a in self._read()["actions"].values() if a["matter"] in visible]

    def notification_actions(self, workflow):
        """Authorized result projection for #1327; no raw ledger access by sender."""
        visible = self._visible(workflow, available_only=True)
        actions = self.actions(workflow, available_only=True)
        for action in actions:
            if action["status"] == "verified" and self._grant(
                    action["decision"]["rule"], visible[action["matter"]], "display") != action["authority"]:
                raise ValueError("authority_unavailable")
        return actions

    def pauses(self):
        return self._read()["pauses"]

    def rule_history(self):
        return self._read().get("rule_history", [])

    def pause(self, rule, *, reason, evidence):
        """Trusted operator/error hook. There is deliberately no model resume API."""
        if rule not in self.rules or reason not in {
            "wrong_association", "duplicate_gd", "unsupported_completion", "unauthorized",
            "version_conflict", "readback_conflict", "receipt_identity_conflict",
        } or not evidence:
            raise ValueError("invalid_pause")
        with self._transaction() as state:
            if rule not in state["pauses"]:
                history = state.setdefault("rule_history", [])
                pause = dict(id=identity(rule, reason, evidence, len(history)),
                    rule=rule, rule_version=self.rules[rule].version, reason=reason,
                    evidence=evidence, at=datetime.now(timezone.utc).isoformat())
                state["pauses"][rule] = pause
                history.append(dict(event="paused", **pause))

    def collect(self, workflow):
        """Read only Workflow's public authorized projection; collect while paused."""
        self._workflow = workflow
        for source in workflow.available_matters():
            with self._transaction() as state:
                matter = state["matters"].setdefault(source["id"], {"id": source["id"]})
                matter.update(source=source, evidence=source["evidence"])
                for previous in state["actions"].values():
                    if (previous["matter"] == source["id"] and previous["revision"] != source["revision"]
                            and previous["status"] in {"prepared", "pending", "paused", "needs_review"}):
                        previous["status"] = "superseded"
                try:
                    decision = self.decide(source)
                    if (not isinstance(decision, Decision)
                            or not isinstance(decision.title, str) or not 1 <= len(decision.title) <= 200
                            or not isinstance(decision.note, str) or not 1 <= len(decision.note) <= 500):
                        raise ValueError()
                except Exception:
                    matter["status"] = "needs_review"
                    continue
                if decision.rule not in self.rules:
                    matter["status"] = "needs_review"
                    continue
                if (source["association"] != "confirmed_goal" or source["event"]["intent"] != "action"
                        or source.get("review_required", False)):
                    matter["status"] = "recorded"
                    continue
                key = "gd-" + identity(source["id"], source["revision"], decision.rule,
                                       self.rules[decision.rule].version)
                previous = state["actions"].get(key)
                if previous and previous["decision"] != asdict(decision):
                    previous["decision_conflict"] = asdict(decision)
                    if previous["status"] in {"prepared", "pending", "paused"}:
                        previous["status"] = "needs_review"
                    matter["status"] = "needs_review"
                    continue
                for old in state["actions"].values():
                    if (old["matter"] == source["id"] and old["id"] != key
                            and old["status"] in {"prepared", "pending", "paused"}):
                        old["status"] = "superseded"
                if key not in state["actions"]:
                    try:
                        authority = self._grant(decision.rule, source, "plan")
                        if matter.setdefault("authority", authority) != authority:
                            raise ValueError("authority_drift")
                        status = "prepared"
                    except ValueError:
                        authority = matter.get("authority")
                        status = "unauthorized"
                    state["actions"][key] = dict(id=key, matter=source["id"],
                        revision=source["revision"], decision=asdict(decision),
                        rule_version=self.rules[decision.rule].version, status=status,
                        authority=authority, evidence=source["evidence"])
                    matter["status"] = "pending" if status == "prepared" else status

    def tick(self, workflow, mcp, workspace=None):
        # A process lock serializes all network writes for this bounded store.
        # Each request is committed BEFORE I/O, so process loss stays unknown.
        with self._exclusive():
            self.collect(workflow)
            for action in self.actions(available_only=True):
                if action["status"] in {"prepared", "pending"}:
                    if any(a["matter"] == action["matter"] and a["status"] == "unknown"
                           for a in self._read()["actions"].values()):
                        continue
                    rule = action["decision"]["rule"]
                    if rule in self.pauses():
                        with self._transaction() as state:
                            state["actions"][action["id"]]["status"] = "paused"
                            state["matters"][action["matter"]]["status"] = "paused"
                        continue
                    self._execute(action, mcp)
                elif action["status"] == "unknown":
                    try:
                        self._recover(action, mcp)
                    except Exception:
                        pass  # Original request only; never mint a replacement.

            if workspace is not None:
                self.publish(workflow, workspace)

    def publish(self, workflow, workspace):
        """Publish receipts as native messages, with no assistant/human dispatch."""
        visible = self._visible(workflow, available_only=True)
        if not workspace.supports_idempotency():
            raise ValueError("idempotent_delivery_required")
        for action in self.actions(available_only=True):
            if action["matter"] not in visible or action["status"] in {"prepared", "superseded"}:
                continue
            source = visible[action["matter"]]
            try:
                if self._grant(action["decision"]["rule"], source, "display") != action["authority"]:
                    continue
                state = self._read()
                matter = state["matters"][action["matter"]]
                status = action["status"]
                result = (action.get("receipt") or {}).get("result") or {}
                content = dict(action=action["id"], matter=matter["id"], revision=action["revision"],
                    rule=action["decision"]["rule"], rule_version=action["rule_version"],
                    status=status, code=result.get("code", matter.get("code")), link=matter.get("link"),
                    actual_status=result.get("status"), edit_version=result.get("edit_version"),
                    evidence=[evidence_reference(e) for e in action["evidence"]], operation=action.get("operation"),
                    reason=action.get("reason"))
                message = dict(network=workflow.workspace, source="system:enterprise-agent-1325",
                    type="workspace.message.posted", target="channel/" + matter["id"],
                    idempotency_key=action_identity(action["id"], status),
                    metadata={"target_agents": ["__no_response__"], "explicit_targets": []},
                    payload={"message_type": "chat",
                             "content": json.dumps(content, ensure_ascii=False)})
                with self._transaction() as state:
                    publication = state["actions"][action["id"]].setdefault("publications", {}).setdefault(
                        status, dict(message=message, status="pending"))
                    if publication["status"] == "accepted":
                        continue
                    message = publication["message"]
                workspace.ensure_thread(matter["id"], workflow.coordinator, workflow.assistants)
                remote_id = workspace.post(message)
                if not isinstance(remote_id, str) or not remote_id:
                    continue
                with self._transaction() as state:
                    state["actions"][action["id"]]["publications"][status].update(
                        status="accepted", remote_id=remote_id)
            except Exception:
                continue  # Same persisted message/key on the next bounded tick.

    @contextmanager
    def _exclusive(self):
        fcntl.flock(self.lock, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(self.lock, fcntl.LOCK_UN)

    def _execute(self, action, mcp):
        matter = self._read()["matters"][action["matter"]]
        source = matter["source"]
        marker = "[enterprise-goal:" + identity(source["event"]["scope"], source["event"]["goal"]) + "]"
        decision = action["decision"]
        try:
            latest = self._visible(available_only=True)[action["matter"]]
            if latest["revision"] != action["revision"]:
                raise ValueError("stale_source")
            if asdict(self.decide(latest)) != decision:
                raise ValueError("decision_drift")
            grant = self._grant(decision["rule"], latest, "write")
            if grant != action["authority"]:
                raise ValueError("authority_drift")
            result = mcp.call_tool("search_work_items", dict(keyword=marker, status="ALL", limit=50))
            matches = [item for item in result["items"] if marker in (item.get("detail") or "")]
            candidates = {code for event in source["evidence"] for code in event.get("candidates", [])}
            if matter.get("code"):
                candidates.add(matter["code"])
            candidates.update(item["code"] for item in matches)
            if result.get("truncated") or len(candidates) > 1:
                raise ValueError("ambiguous_gd")
            if candidates:
                matches = [dict(code=next(iter(candidates)))]
            if decision["kind"] not in {"progress", "complete", "correct"}:
                raise ValueError("unsupported_action")
            if decision["kind"] in {"complete", "correct"} and not (
                decision["exact_goal"] is True and decision["explicit"] is True
                and (decision["related_person"] is True or decision["business_completion"] is True)
                and decision["contradictory"] is False
            ):
                with self._transaction() as state:
                    state["actions"][action["id"]]["status"] = "needs_review"
                    state["matters"][action["matter"]]["status"] = "needs_review"
                return
            if matches:
                item = mcp.call_tool("get_work_item_detail", dict(code=matches[0]["code"]))
                if matter.get("actual") and matter["actual"]["edit_version"] != item["edit_version"]:
                    self._conflict(action, "version_conflict", actual=item)
                    return
                operation = "update_work_item"
                arguments = dict(code=item["code"], expected_version=item["edit_version"],
                    detail=(item.get("detail") or "") + "\n" + decision["note"])
                if decision["kind"] == "correct":
                    previous = self._read()["actions"].get(decision["corrects"], {})
                    if (previous.get("matter") != matter["id"]
                            or previous.get("status") != "verified"
                            or previous.get("decision", {}).get("kind") != "complete"
                            or previous["receipt"]["result"]["edit_version"] != item["edit_version"]):
                        raise ValueError("correction_conflict")
                if decision["kind"] in {"complete", "correct"}:
                    operation = "transition_work_item"
                    arguments = dict(code=item["code"], expected_version=item["edit_version"],
                                     status="OPEN" if decision["kind"] == "correct" else "DONE",
                                     note=decision["note"])
                elif item["status"] in {"DONE", "CANCELLED"}:
                    raise ValueError("closed_goal_requires_review")
                target = "work_item:" + item["code"]
            else:
                if decision["kind"] != "progress":
                    raise ValueError("completion_without_gd")
                operation = "create_work_item"
                arguments = dict(title=decision["title"], detail=marker + "\n" + decision["note"],
                                 category=None, assignees=None, due_date=None)
                target = "work_item:new"
            latest = self._visible(available_only=True)[action["matter"]]
            if latest["revision"] != action["revision"]:
                raise ValueError("stale_source")
            if asdict(self.decide(latest)) != decision:
                raise ValueError("decision_drift")
            if self._grant(decision["rule"], latest, "write") != action["authority"]:
                raise ValueError("authority_drift")
            payload_hash = sha256(json.dumps({k: v for k, v in arguments.items() if v is not None},
                ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            action.update(operation=operation, arguments=arguments, target=target, status="unknown",
                          payload_hash=payload_hash, association="existing_gd" if matches else "new_goal")
            with self._transaction() as state:
                state["actions"][action["id"]] = action
            mcp.call_tool(operation, {**arguments, "write_context": mcp.write_context(action)})
            self._recover(action, mcp)
        except Exception as error:
            with self._transaction() as state:
                current = state["actions"][action["id"]]
                if current["status"] in {"prepared", "pending"}:
                    reason = str(error) if isinstance(error, ValueError) else "boundary_unavailable"
                    if reason in {"ambiguous_gd", "unsupported_action", "correction_conflict", "decision_drift",
                                  "closed_goal_requires_review", "completion_without_gd"}:
                        current.update(status="needs_review", reason=reason)
                    elif reason == "stale_source":
                        current.update(status="superseded", reason=reason)
                    elif reason in {"authority_drift", "authority_unavailable"}:
                        current.update(status="unauthorized", reason=reason)
                    else:
                        current.update(status="pending", reason="boundary_unavailable")
                state["matters"][action["matter"]]["status"] = current["status"]

    def _conflict(self, action, reason, *, actual=None, receipt=None):
        with self._transaction() as state:
            state["actions"][action["id"]].update(status="conflict", reason=reason,
                conflicting_actual=actual, receipt=receipt)
            state["matters"][action["matter"]]["status"] = "conflict"
        self.pause(action["decision"]["rule"], reason=reason, evidence=action["id"])

    def _recover(self, action, mcp):
        source = self._visible(available_only=True)[action["matter"]]
        if self._grant(action["decision"]["rule"], source, "readback") != action["authority"]:
            raise ValueError("authority_drift")
        receipt = mcp.call_tool("get_mcp_write_request", dict(request_id=action["id"]))
        if (receipt.get("request_id") != action["id"]
                or receipt.get("idempotency_key") != action["id"]
                or receipt.get("operation") != action["operation"]
                or receipt.get("logical_target") != action["target"]
                or receipt.get("operator_id") != action["authority"]["operator_id"]
                or receipt.get("operator_name") != action["authority"]["operator_name"]
                or receipt.get("payload_hash") != action["payload_hash"]
                or receipt.get("approval_id") != action["id"]):
            self._conflict(action, "receipt_identity_conflict", receipt=receipt)
            return
        if receipt["status"] in {"FAILED", "FAILED_RETRYABLE"}:
            conflict = receipt.get("error_code") == "HTTP_409"
            denied = receipt.get("error_code") in {"HTTP_401", "HTTP_403"}
            conflicting_actual = None
            if conflict and action["arguments"].get("code"):
                conflicting_actual = mcp.call_tool("get_work_item_detail", {"code": action["arguments"]["code"]})
            with self._transaction() as state:
                state["actions"][action["id"]].update(
                    status="conflict" if conflict else "rejected", receipt=receipt,
                    conflicting_actual=conflicting_actual)
                state["matters"][action["matter"]].update(
                    status="conflict" if conflict else "rejected")
            if conflict or denied:
                self.pause(action["decision"]["rule"], reason="version_conflict" if conflict else "unauthorized",
                           evidence=action["id"])
            return
        if receipt["status"] != "SUCCEEDED":
            return
        result = receipt["result"]
        item = mcp.call_tool("get_work_item_detail", dict(code=result["code"]))
        if (any(item.get(k) != v for k, v in result.items() if not k.startswith("previous_"))
                or ("code" in action["arguments"] and result["code"] != action["arguments"]["code"])
                or (action["operation"] == "transition_work_item"
                    and result["status"] != action["arguments"]["status"])
                or (action["operation"] in {"create_work_item", "update_work_item"}
                    and result["detail"] != action["arguments"]["detail"])):
            self._conflict(action, "readback_conflict", actual=item, receipt=receipt)
            return
        with self._transaction() as state:
            state["actions"][action["id"]].update(status="verified", receipt=receipt)
            state["matters"][action["matter"]].update(status="verified", code=item["code"],
                actual=item, link=self.link_base + "?" + urlencode({"view": item["id"]}))


class Recovery:
    """Separate trusted operator boundary. Never register with MCP/model tools.

    verify must authenticate an opaque human request through the existing owner
    authority and verify repair/test evidence. JSON/model assertions are not proof.
    """
    def __init__(self, maintenance, *, verify):
        self.maintenance = maintenance
        self.verify = verify

    def resume(self, rule, *, pause_id, request):
        service = self.maintenance
        with service._exclusive():
            pause = service.pauses().get(rule)
            if not pause or pause.get("id") != pause_id:
                raise ValueError("pause_changed")
            try:
                proof = self.verify(request)
                if (proof["active"] is not True or proof["human"] is not True
                        or proof["rule"] != rule or proof["pause_id"] != pause_id
                        or proof["rule_version"] != service.rules[rule].version
                        or any(not isinstance(proof[k], str) or not proof[k]
                               for k in ("reviewer_id", "repair", "validation", "reason"))):
                    raise ValueError()
                audit = {k: proof[k] for k in ("reviewer_id", "repair", "validation", "reason")}
            except Exception:
                raise ValueError("verified_human_recovery_required") from None
            with service._transaction() as state:
                if state["pauses"].get(rule) != pause:
                    raise ValueError("pause_changed")
                del state["pauses"][rule]
                state.setdefault("rule_history", []).append(dict(event="resumed", rule=rule,
                    rule_version=service.rules[rule].version, pause_id=pause_id,
                    at=datetime.now(timezone.utc).isoformat(), **audit))
                for action in state["actions"].values():
                    if action["decision"]["rule"] == rule and action["status"] == "paused":
                        action["status"] = "prepared"
