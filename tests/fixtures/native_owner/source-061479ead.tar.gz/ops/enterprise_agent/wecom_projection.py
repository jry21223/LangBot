"""Trusted projection of already saved WecomArchiveMessageInput evidence.

No SDK, source credentials, source cursor, raw text reader or business writer.
The owner supplies authoritative saved revisions, original/media relations and
reviewed goal decisions separately from untrusted message payloads.
"""
from copy import deepcopy
import re


def validate_content_materialization(value):
    """Only V285 snapshot proofs belong in metadata; never original text."""
    if not isinstance(value, dict):
        raise ValueError("invalid_content_materialization")
    status = value.get("status")
    if status in {"pending", "recalled"}:
        valid = (set(value) == {"status", "evidence_fingerprint"}
                 and isinstance(value["evidence_fingerprint"], str)
                 and re.fullmatch(r"[a-f0-9]{64}", value["evidence_fingerprint"]))
    elif status == "complete":
        valid = (set(value) == {"status", "parser_version", "input_hash", "result_sha256", "text_bytes", "parts"}
                 and isinstance(value["parser_version"], str)
                 and re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", value["parser_version"])
                 and all(isinstance(value[k], str) and re.fullmatch(r"[a-f0-9]{64}", value[k])
                         for k in ("input_hash", "result_sha256"))
                 and all(type(value[k]) is int and 0 <= value[k] <= 2147483647
                         for k in ("text_bytes", "parts")))
    else:
        valid = False
    if not valid:
        raise ValueError("invalid_content_materialization")


class SavedArchive:
    def __init__(self, workflow, *, source, scope):
        self.workflow = workflow
        self.source = source
        self.scope = scope

    def ingest(self, saved, *, decision, cursor, previous_cursor):
        """Consume one saved revision; cursor belongs only to this projection."""
        event = self.project(saved, decision=decision)
        return self.workflow.ingest(event, cursor=cursor, previous_cursor=previous_cursor,
                                    retain_historical=True)

    def project(self, saved, *, decision):
        """Validate and narrow an owner revision before any admission side effect."""
        try:
            if not isinstance(saved, dict) or not isinstance(decision, dict):
                raise ValueError()
            message = saved["message"]
            if "content_materialization" in message:
                validate_content_materialization(message["content_materialization"])
            if not isinstance(message, dict):
                raise ValueError()
            details = {k: message[k] for k in (
                "message_id", "chat_id", "chat_type", "sender_user_id",
                "sender_identity_type", "message_type")}
            for value in details.values():
                self._text(value)
            access = message.get("sender_access_type")
            if access is not None:
                self._text(access)
            seq = message["source_seq"]
            if type(seq) is not int or seq < 0:
                raise ValueError()
            action = message.get("action") or "send"
            if action not in {"send", "recall"}:
                raise ValueError()
            recalled = None
            if action == "recall":
                if message["message_type"] != "revoke":
                    raise ValueError()
                # The owner feed supplies a narrow validated relation, never the raw SDK payload.
                recalled = message.get("recalled_message_id")
                if recalled is None:
                    recalled = message["raw_payload"]["revoke"]["pre_msgid"]  # legacy saved-owner contract
                self._text(recalled)
            elif message["message_type"] == "revoke":
                raise ValueError()
            attachments = deepcopy(saved["attachments"])
            if not isinstance(attachments, list) or len(attachments) > 100:
                raise ValueError()
            for attachment in attachments:
                legacy = {"reference", "status"}
                rich = legacy | {"type", "sha256", "size"}
                if (not isinstance(attachment, dict) or set(attachment) not in (legacy, rich)
                        or attachment["status"] not in {"saved", "missing", "withdrawn"}):
                    raise ValueError()
                self._reference(attachment["reference"])
                if set(attachment) == rich:
                    if (attachment["type"] not in {"file", "image", "voice", "video", "unknown"}
                            or (attachment["type"] == "unknown" and attachment["status"] == "saved")):
                        raise ValueError()
                    digest, size = attachment["sha256"], attachment["size"]
                    if ((digest is not None and (not isinstance(digest, str)
                            or not re.fullmatch(r"[a-f0-9]{64}", digest)))
                            or (size is not None and (type(size) is not int or size < 0))
                            or (attachment["status"] == "saved" and (digest is None or size is None))):
                        raise ValueError()
            self._reference(saved["original"])
            if set(decision) != {"goal", "confirmed", "intent", "candidates"}:
                raise ValueError()
            details.update(sender_access_type=access, source_seq=seq, action=action,
                           recalled_message_id=recalled, attachments=attachments)
            media = message.get("media_evidence") or []
            if not isinstance(media, list) or len(media) > 100:
                raise ValueError()
            projected_media = []
            for item in media:
                if not isinstance(item, dict):
                    raise ValueError()
                evidence = {}
                for field in ("mediaId", "mediaType", "sourcePath", "sourceMd5", "contentSha256"):
                    value = item.get(field)
                    if value is not None:
                        self._text(value)
                        evidence[field] = value
                for field in ("sourceFileSize", "contentSize"):
                    value = item.get(field)
                    if value is not None:
                        if type(value) is not int or value < 0:
                            raise ValueError()
                        evidence[field] = value
                projected_media.append(evidence)
            if projected_media:
                details["media_evidence"] = projected_media
            incomplete = (message["message_type"] in {"file", "image", "voice", "video"}
                          and not attachments) or any(a["status"] != "saved" for a in attachments)
            materialization = message.get("content_materialization")
            unreadable = (message["message_type"] != "text" and materialization is not None
                          and (not isinstance(materialization, dict)
                               or materialization.get("status") != "complete"))
            unknown_sender = message["sender_identity_type"] not in {"EMPLOYEE", "CUSTOMER"}
            event = dict(source=self.source, scope=self.scope,
                         record=recalled or message["message_id"], version=saved["version"],
                         sequence=saved["sequence"], business_at=message["sent_at"],
                         observed_at=saved["observed_at"], evidence=saved["original"],
                         approval_status="not_applicable", **deepcopy(decision),
                         evidence_details=details)
            if incomplete or unreadable:
                event["review_required"] = True
            if unknown_sender or recalled or unreadable:
                event["confirmed"] = False
            if recalled:
                event["intent"] = "reference"
        except (KeyError, TypeError, ValueError):
            raise ValueError("invalid_saved_archive") from None
        return event

    def coverage(self, status=None):
        """Projection progress never claims acceptance of the real source."""
        if status is not None:
            self.workflow.record_coverage(self.source, status=status)
        return {"projection": self.workflow.coverage(self.source),
                "real_coverage": "uncovered", "validation": "synthetic_only"}

    @staticmethod
    def _text(value):
        if (not isinstance(value, str) or not 1 <= len(value) <= 512
                or any(ord(c) < 32 for c in value)):
            raise ValueError()

    @classmethod
    def _reference(cls, value):
        cls._text(value)
        if not re.fullmatch(r"[a-zA-Z0-9_.:/-]+", value):
            raise ValueError()
