"""Durable narrow candidates and trusted first admission into the existing Workflow."""
from copy import deepcopy
from dataclasses import asdict, dataclass
from datetime import datetime
from hashlib import sha256
import json
import re
import time

from .source_http import is_gd_edit_version
from .wecom_projection import SavedArchive, validate_content_materialization
from .workflow import identity
from ._http_budget import current_deadline


def _fingerprint(value):
    def stable(item):
        if isinstance(item, dict):
            return {k: stable(v) for k, v in item.items() if k not in {"observed_at", "original_available"}}
        if isinstance(item, list):
            return [stable(v) for v in item]
        return item
    return sha256(json.dumps(stable(value), sort_keys=True, separators=(",", ":")).encode()).hexdigest()


@dataclass(frozen=True)
class Admission:
    rule_version: str
    goal: str
    intent: str
    target: dict


class ExactGoalRule:
    def __init__(self, reader, *, version, allowed_owners, project=None):
        if (not isinstance(allowed_owners, dict) or not allowed_owners
                or any(not isinstance(key, tuple) or len(key) != 2 or not value
                       or not isinstance(value, (list, set, frozenset))
                       or any(not isinstance(owner, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", owner)
                              for owner in value) for key, value in allowed_owners.items())):
            raise ValueError("goal_ownership_binding_required")
        self.allowed_owners = {key: frozenset(value) for key, value in allowed_owners.items()}
        self.reader, self.version = reader, version
        self.project = project

    def __call__(self, candidate):
        change = candidate["change"]
        if self.project is not None:
            projection = self.project(candidate, dict(goal="unresolved", confirmed=True, intent="reference", candidates=[]))
            if (change.get("original_available", True) is not True
                    or projection.get("review_required") or projection.get("confirmed") is not True):
                return None
        else:
            message = change["saved"]["message"]
            if (change.get("original_available", True) is not True
                or message["sender_identity_type"] not in {"EMPLOYEE", "CUSTOMER"}
                or message.get("action", "send") != "send"
                or any(a["status"] != "saved" for a in change["saved"]["attachments"])
                or (message["message_type"] != "text" and not change["saved"]["attachments"])):
                return None
        code = change.get("goal_reference")
        if not code:
            return None
        target = self.reader.get(code)
        allowed = self.allowed_owners.get((candidate["source"], candidate["scope"]), frozenset())
        if not allowed.intersection(target["assignee_ids"]):
            raise ValueError("goal_ownership_unavailable")
        return Admission(self.version, "gd:" + str(target["id"]),
                         "completed" if target["status"] in {"DONE", "CANCELLED"} else "action", target)

    def requalify(self, candidate, decision):
        if self(candidate) != decision:
            raise ValueError("goal_readback_changed")
        return decision


class Producer:
    def __init__(self, workflow, *, rule_version, model_version, projectors=None):
        if any(not isinstance(v, str) or not 1 <= len(v) <= 200 for v in (rule_version, model_version)):
            raise ValueError("invalid_producer_configuration")
        self.workflow = workflow
        self.rule_version, self.model_version = rule_version, model_version
        self.projectors = dict(projectors or {})
        configuration = dict(rule_version=rule_version, model_version=model_version)
        if self.projectors:
            if any(not isinstance(source, str) or not isinstance(getattr(projector, "version", None), str)
                   or not callable(getattr(projector, "project", None)) for source, projector in self.projectors.items()):
                raise ValueError("trusted_projection_required")
            configuration["projectors"] = {source: projector.version for source, projector in self.projectors.items()}
        with workflow._transaction() as state:
            data = state.setdefault("producer", dict(configuration=configuration, candidates={}, coverage={}))
            if data["configuration"] != configuration:
                raise ValueError("configuration_drift")

    def coverage(self, source):
        return deepcopy(self.workflow._read()["producer"]["coverage"].get(source))

    def candidates(self, *, available_only=False):
        result = []
        for value in self.workflow._read()["producer"]["candidates"].values():
            try:
                grant = self.workflow._grant(value["source"], "display", scope=value["scope"])
                if grant != value["authority"]:
                    raise ValueError("source_unavailable")
            except ValueError:
                if available_only:
                    continue
                raise
            result.append(deepcopy(value))
        return result

    def pending_candidates(self, *, limit, deadline):
        """Select bounded pending work before performing any current-grant reads."""
        values = [c for c in self.workflow._read()["producer"]["candidates"].values()
                  if c["status"] in {"pending", "prepared"}]
        selected = self.workflow._window(values, "candidate_position", limit)
        for index, value in enumerate(selected):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            budget = current_deadline.set(time.monotonic() + remaining / (len(selected) - index))
            try:
                grant = self.workflow._grant(value["source"], "ingest", scope=value["scope"])
                if grant != value["authority"]:
                    continue
            except ValueError:
                continue
            finally:
                current_deadline.reset(budget)
            yield deepcopy(value)

    def record_coverage(self, source, status):
        if status not in {"disabled", "permission_denied", "credential_expired", "missing_page", "sync_failed"}:
            raise ValueError("invalid_coverage")
        with self.workflow._transaction() as state:
            old = state["producer"]["coverage"].get(source, {})
            state["producer"]["coverage"][source] = {**old, "status": status}

    def bind_native_consumer(self,native_ingress):
        """Only an authorized fresh source may reserve a Core consumer realm."""
        from .native_ingress import NativeConsumerConflict
        expected=native_ingress.check_consumer(self)
        self.workflow._grant(native_ingress.source,'ingest',scope=native_ingress.scope)
        with self.workflow._transaction() as state:
            data=state['producer']['coverage']
            old=data.get(native_ingress.source)
            if old is not None:
                if old.get('native_ingress',{}).get('consumer')!=expected:
                    raise NativeConsumerConflict('native_consumer_conflict')
                return
            data[native_ingress.source]=dict(cursor=None,status='initialized',gaps=[],native_ingress=dict(
                source=native_ingress.source,scope=native_ingress.scope,flavor=native_ingress.flavor,
                consumer=deepcopy(expected),gap_audit={}))

    def _validate_change(self, change, source, scope):
        try:
            self._checked_change(change, source, scope)
        except (TypeError, KeyError, AttributeError):
            raise ValueError("invalid_source_change") from None

    def _checked_change(self, change, source, scope):
        allowed = {"source", "scope", "record", "version", "sequence", "kind", "business_at",
                   "observed_at", "original", "projection_hash", "goal_reference", "saved"}
        if (not isinstance(change, dict) or set(change) - {"original_available"} != allowed
                or change["source"] != source or change["scope"] != scope
                or not re.fullmatch(r"[0-9a-f]{64}", change["projection_hash"])
                or change["kind"] not in {"created", "baseline", "baseline_snapshot", "changed",
                                          "attachments_changed", "recalled"}):
            raise ValueError("invalid_source_change")
        if type(change.get("original_available", True)) is not bool:
            raise ValueError("invalid_source_change")
        if source in self.projectors:
            event = self.project(dict(source=source, scope=scope, change=change),
                                 dict(goal="unresolved", confirmed=False, intent="reference", candidates=[]))
            if (type(change["sequence"]) is not int or change["sequence"] < 1
                    or any(event[key] != change[key] for key in ("record", "version", "sequence", "business_at", "observed_at"))
                    or event["evidence"] != change["original"]):
                raise ValueError("invalid_source_change")
            code = change["goal_reference"]
            if code is not None and (not isinstance(code, str) or not re.fullmatch(r"GD-[A-Za-z0-9-]{1,60}", code)):
                raise ValueError("invalid_goal_reference")
            return
        saved = change["saved"]
        if (set(saved) != {"version", "sequence", "observed_at", "original", "attachments", "message"}
                or any(saved[k] != change[k] for k in ("version", "sequence", "original"))
                or self._instant(saved["observed_at"]) != self._instant(change["observed_at"])
                or saved["message"]["message_id"] != change["record"]):
            raise ValueError("invalid_source_change")
        message = saved["message"]
        message_fields = {"source_seq", "message_id", "chat_id", "chat_type", "sender_user_id",
                          "sender_identity_type", "sender_access_type", "message_type", "sent_at", "action",
                          "media_evidence", "recalled_message_id", "content_materialization"}
        if (set(message) - message_fields
                or self._instant(message["sent_at"]) != self._instant(change["business_at"])
                or (change["kind"] == "recalled") != (message.get("action", "send") == "recall")):
            raise ValueError("invalid_source_change")
        if "content_materialization" in message:
            try:
                validate_content_materialization(message["content_materialization"])
            except (ValueError, TypeError):
                raise ValueError("invalid_source_change") from None
        for key in ("business_at", "observed_at"):
            self._instant(change[key])
        decision = dict(goal="unresolved", confirmed=False, intent="reference", candidates=[])
        event = SavedArchive(self.workflow, source=source, scope=scope).project(saved, decision=decision)
        if (event["record"] != change["record"] or type(change["sequence"]) is not int
                or change["sequence"] < 1 or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,512}", change["version"])):
            raise ValueError("invalid_source_change")
        code = change["goal_reference"]
        if code is not None and (not isinstance(code, str) or not re.fullmatch(r"GD-[A-Za-z0-9-]{1,60}", code)):
            raise ValueError("invalid_goal_reference")

    @staticmethod
    def _instant(value):
        if not isinstance(value, str):
            raise ValueError("invalid_source_change")
        try:
            instant = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            raise ValueError("invalid_source_change") from None
        if instant.utcoffset() is None:
            raise ValueError("invalid_source_change")
        return instant

    def prepare(self, source, page, *, previous_cursor=None, native_ingress=None):
        native_page=None
        native_consumer=None
        if native_ingress is not None:
            from .native_ingress import NativeIngress, validate_page
            if not isinstance(native_ingress,NativeIngress) or native_ingress.source!=source:
                raise ValueError('native_ingress_binding_required')
            native_consumer=native_ingress.check_consumer(self)
            native_page=validate_page(page,source=source,scope=native_ingress.scope,previous_cursor=previous_cursor,flavor=native_ingress.flavor)
            page={key:deepcopy(value) for key,value in native_page.items() if key not in {'page_id','page_sha256'}}
            page['items']=[deepcopy(item['envelope']) for item in native_page['items']]
            from .native_ingress import gap_code
            page['gaps']=[gap_code(gap) for gap in native_page['gaps']]

        if (not isinstance(page, dict) or page.get("source") != source
                or page.get("complete_page") is not True or page.get("previous_cursor") != previous_cursor
                or not isinstance(page.get("next_cursor"), str) or not page["next_cursor"]
                or not isinstance(page.get("items"), list) or len(page["items"]) > 100
                or not isinstance(page.get("gaps"), list)
                or any(not isinstance(g, str) or len(g) > 200 for g in page["gaps"])):
            raise ValueError("incomplete_source_page")
        scope = page.get("scope")
        if not isinstance(scope, str):
            raise ValueError("incomplete_source_page")
        authority = self.workflow._grant(source, "ingest", scope=scope)
        for change in page["items"]:
            self._validate_change(change, source, scope)
        native_bindings={}
        if native_page is not None:
            from .native_ingress import canonical_bytes, accepted_receipt
            for item,projected in zip(native_page['items'],page['items']):
                change=item['envelope']
                checked,grant=native_ingress.checked_envelope(change)
                if 'original_available' in change or checked['original_available'] is False:
                    projected['original_available']=checked['original_available']
                if {key:grant[key] for key in ('source','scope','principal','revision')}!=authority:
                    raise ValueError('native_ingress_authority_changed')
                native_bindings[identity(source,change['record'],change['version'])]=dict(
                    event_id=item['event_id'],envelope_sha256=sha256(canonical_bytes(change)).hexdigest(),
                    receipt=accepted_receipt(item['event_id'],change))
            if len(native_bindings)!=len(native_page['items']):
                raise ValueError('native_ingress_duplicate_candidate')
        with self.workflow._transaction() as state:
            data = state["producer"]
            old = data["coverage"].get(source, {})
            previous_native=old.get('native_ingress')
            if native_page is not None and previous_native is not None and previous_native.get('consumer')!=native_consumer:
                from .native_ingress import NativeConsumerConflict
                raise NativeConsumerConflict('native_consumer_conflict')
            if previous_native is not None:
                if native_page is None:
                    raise ValueError('native_ingress_binding_required')
                if (previous_native.get('source')!=source or previous_native.get('scope')!=scope
                        or previous_native.get('flavor','finance')!=native_ingress.flavor):
                    raise ValueError('native_ingress_scope_conflict')
                if previous_native.get('page_id')==native_page['page_id']:
                    if previous_native['page_sha256']!=native_page['page_sha256']:
                        raise ValueError('native_ingress_page_conflict')
                    return
                if previous_native.get('ack_pending',False):
                    raise ValueError('native_ingress_ack_pending')
            if native_page is not None:
                if previous_native is None and old.get('cursor') is not None:
                    raise ValueError('native_ingress_cursor_binding_required')
                known={c['native_ingress']['event_id']:c['native_ingress'] for c in data['candidates'].values()
                    if 'native_ingress' in c}
                for key,binding in native_bindings.items():
                    if binding['event_id'] in known and known[binding['event_id']]!=binding:
                        raise ValueError('native_ingress_event_conflict')
                    candidate=data['candidates'].get(key)
                    if candidate and candidate.get('native_ingress',binding)!=binding:
                        raise ValueError('native_ingress_event_conflict')
            if old.get("cursor") not in {previous_cursor, page["next_cursor"]}:
                raise ValueError("cursor_gap")
            for change in page["items"]:
                key = identity(source, change["record"], change["version"])
                old_candidate = data["candidates"].get(key)
                if old_candidate:
                    if old_candidate["fingerprint"] != _fingerprint(change):
                        raise ValueError("version_conflict")
                    old_candidate["change"]["original_available"] = change.get("original_available", True)
                    if native_page is not None:
                        old_candidate['native_ingress']=native_bindings[key]
                    continue
                prior = [c for c in data["candidates"].values()
                         if c["source"] == source and c["change"]["record"] == change["record"]]
                if any(c["change"]["sequence"] == change["sequence"] for c in prior):
                    raise ValueError("version_conflict")
                data["candidates"][key] = dict(id=key, source=source, scope=scope, change=deepcopy(change),
                    authority=authority, fingerprint=_fingerprint(change), status="pending")
                if native_page is not None:
                    data['candidates'][key]['native_ingress']=native_bindings[key]
            data["coverage"][source] = dict(cursor=page["next_cursor"],
                status="success" if page["items"] else "success_zero", gaps=deepcopy(page["gaps"]))
            if native_page is not None:
                from .native_ingress import page_metadata, unresolved_codes
                metadata=page_metadata(native_page,previous_native,flavor=native_ingress.flavor,consumer=native_consumer)
                data['coverage'][source]['native_ingress']=metadata
                data['coverage'][source]['gaps']=unresolved_codes(metadata)
                data['coverage'][source]['status']=('missing_page' if data['coverage'][source]['gaps'] else
                    'idle' if not native_page['items'] and not native_page['gaps'] else 'success')

    def ack_native_page(self,source,proof,receipts):
        """Persist only a verified page-level ack; never an event-lookup guess."""
        with self.workflow._transaction() as state:
            coverage=state['producer']['coverage'][source]
            pending=coverage['native_ingress']
            if (proof!=dict(page_id=pending['page_id'],next_cursor=pending['next_cursor'],status='accepted')
                    or receipts!=pending['receipts']):
                raise ValueError('native_ingress_ack_conflict')
            pending['ack_pending']=False
            coverage['status']='missing_page' if coverage['gaps'] else 'success' if receipts else 'idle'


    def apply_owner_state(self, candidate_id):
        """Apply trusted WeCom withdrawal/hold state, never admit a new business goal.

        Cancellation consumes the same owner metadata/current-reference boundary as admission,
        but does not read original bodies or require a GD to still exist or have an assignee.
        """
        state = self.workflow._read()
        value = state["producer"]["candidates"][candidate_id]
        change = value["change"]
        message = change["saved"].get("message")
        if not isinstance(message, dict) or "sender_identity_type" not in message:
            return False  # Other registered source adapters retain their own semantics.
        recalled = change["kind"] == "recalled"
        incomplete = (change.get("original_available", True) is not True
                      or message["sender_identity_type"] not in {"EMPLOYEE", "CUSTOMER"}
                      or any(a["status"] != "saved" for a in change["saved"]["attachments"])
                      or (message["message_type"] != "text" and not change["saved"]["attachments"]))
        prior = [row["event"] for row in state["events"].values()
                 if row["event"]["source"] == value["source"] and row["event"]["record"] == change["record"]]
        latest = max(prior, key=lambda event: event["sequence"]) if prior else None
        already_recalled = bool(latest and latest.get("evidence_details", {}).get("recalled_message_id"))
        if not (recalled or incomplete or already_recalled) or (latest is None and not recalled):
            return False
        if self.workflow._grant(value["source"], "ingest", scope=value["scope"]) != value["authority"]:
            raise ValueError("source_unavailable")
        # A late send can never act as an implicit un-recall, even if an owner integration regresses.
        if already_recalled and not recalled:
            with self.workflow._transaction() as current:
                current["producer"]["candidates"][candidate_id].update(status="needs_review", reason="source_recalled")
            return True
        if latest and change["sequence"] <= latest["sequence"]:
            with self.workflow._transaction() as current:
                current["producer"]["candidates"][candidate_id].update(status="retained", reason="historical_owner_state")
            return True
        selection = dict(goal=latest["goal"] if latest else "unresolved", confirmed=False,
                         intent="reference" if recalled else "action", candidates=[])
        event = SavedArchive(self.workflow, source=value["source"], scope=value["scope"]).project(
            change["saved"], decision=selection)
        receipt = identity("owner-state", candidate_id)
        old_cursor = (self.workflow.coverage(value["source"]) or {}).get("cursor")
        matter = self.workflow.ingest(event, cursor=receipt, previous_cursor=old_cursor, retain_historical=True)
        with self.workflow._transaction() as current:
            current["producer"]["candidates"][candidate_id].update(status="applied", matter=matter["id"])
        return True

    def admit(self, candidate_id, decision):
        value = self.workflow._read()["producer"]["candidates"][candidate_id]
        grant = self.workflow._grant(value["source"], "ingest", scope=value["scope"])
        if grant != value["authority"]:
            raise ValueError("source_unavailable")
        if not isinstance(decision, Admission) or decision.rule_version != self.rule_version:
            raise ValueError("trusted_admission_required")
        target = decision.target
        if (not isinstance(target, dict) or set(target) != {"id", "code", "status", "edit_version", "assignee_ids"}
                or type(target["id"]) is bool or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", str(target["id"]))
                or not isinstance(target["code"], str) or not re.fullmatch(r"GD-[A-Za-z0-9-]{1,60}", target["code"])
                or target["status"] not in {"OPEN", "IN_PROGRESS", "DONE", "CANCELLED"}
                or not is_gd_edit_version(target["edit_version"])
                or not isinstance(target["assignee_ids"], list) or not target["assignee_ids"]
                or any(not isinstance(owner, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", owner)
                       for owner in target["assignee_ids"])
                or decision.goal != "gd:" + str(target["id"])
                or decision.intent not in {"action", "reference", "completed"}):
            raise ValueError("trusted_admission_required")
        admission = asdict(decision)
        receipt = identity(candidate_id, admission)
        with self.workflow._transaction() as state:
            current = state["producer"]["candidates"][candidate_id]
            if current.get("admission") and current["admission"] != admission:
                raise ValueError("admission_conflict")
            if current["status"] == "admitted":
                return current["matter"]
            current.update(admission=admission, admission_receipt=receipt, status="prepared")
        selection = dict(goal=decision.goal, confirmed=True, intent=decision.intent,
                         candidates=[decision.target["code"]])
        # Admission has a separate durable identity; never mutate a previously ingested source event.
        event = self.project(value, selection)
        event["evidence_details"]["goal_reference"] = decision.target["code"]
        event["evidence_details"]["admission_receipt"] = receipt
        old_cursor = (self.workflow.coverage(value["source"]) or {}).get("cursor")
        matter = self.workflow.ingest(event, cursor=receipt, previous_cursor=old_cursor, retain_historical=True)
        with self.workflow._transaction() as state:
            current = state["producer"]["candidates"][candidate_id]
            if matter.get("admission_held"):
                current.update(status="needs_review", reason="cross_matter_rebinding_requires_review")
                return None
            current.update(status="admitted", matter=matter["id"])
        return matter["id"]

    def defer(self, candidate_id):
        """Retain the original admission identity for one bounded attempt next cycle."""
        with self.workflow._transaction() as state:
            current = state["producer"]["candidates"][candidate_id]
            if current["status"] in {"pending", "prepared"}:
                current.update(reason="goal_readback_unavailable",
                               read_attempts=current.get("read_attempts", 0) + 1)

    def hold(self, candidate_id, reason):
        if reason not in {"needs_review", "goal_readback_unavailable"}:
            raise ValueError("invalid_review_reason")
        with self.workflow._transaction() as state:
            state["producer"]["candidates"][candidate_id].update(status="needs_review", reason=reason)

    def project(self, candidate, selection):
        projector = self.projectors.get(candidate["source"])
        if projector is not None:
            return projector.project(candidate, selection)
        return SavedArchive(self.workflow, source=candidate["source"], scope=candidate["scope"]).project(
            candidate["change"]["saved"], decision=selection)
