"""Opt-in exact-thread HTTP methods in the existing owner source process."""

from copy import deepcopy
from hashlib import sha256
import hmac
import json
from pathlib import Path

from .readonly_private import read_private_bytes
from .wechat_native_store import NativeWechatStore, digest
from .wechat_owner_client import WxOwnerClient

ACTIONS = {
    "binding",
    "changes",
    "metadata_authority",
    "original_authority",
    "descriptor",
    "original",
    "manifest",
    "chunk",
    "media",
    "materialization_records",
    "save_materialization",
    "derived",
}
BODY = {
    "original",
    "manifest",
    "chunk",
    "media",
    "derived",
    "materialization_records",
    "save_materialization",
}
DATA_QUERY = {"reference", "version", "stage", "agent"}
ROUTES = {
    "/native/materialization-operations": (
        "operation_receipt",
        {"operation_id", "stage", "agent"},
    ),
    "/native/binding": ("binding", set()),
    "/native/changes": ("changes", {"cursor", "limit"}),
    "/native/authority": (
        "metadata_authority",
        {"reference", "version", "stage", "agent", "audience_workspace"},
    ),
    "/native/descriptor": ("descriptor", {"reference", "version", "include_history"}),
    "/native/original": ("original", DATA_QUERY),
    "/native/manifest": ("manifest", DATA_QUERY),
    "/native/chunk": ("chunk", DATA_QUERY | {"part_index"}),
    "/native/media": ("media", DATA_QUERY | {"asset_id"}),
    "/native/derived": ("derived", DATA_QUERY | {"parser_version"}),
    "/native/materializations": (
        "materialization_records",
        {"cursor", "limit", "parser_version", "stage", "agent"},
    ),
}


class NativeError(ValueError):
    def __init__(self, status):
        self.status = status
        super().__init__("native_source_unavailable")


def _word(value, limit=512):
    return (
        isinstance(value, str)
        and 0 < len(value) <= limit
        and all(ord(c) >= 32 for c in value)
    )


def validate_native(config):
    value = config.get("native")
    if value is None or value == {"enabled": False}:
        return None
    if (
        not isinstance(value, dict)
        or set(value)
        != {
            "enabled",
            "parser_version",
            "activation_at",
            "sequence_floor",
            "owner",
            "readers",
        }
        or type(value["enabled"]) is not bool
        or not _word(value["parser_version"], 128)
        or not _word(value["activation_at"])
        or type(value["sequence_floor"]) is not int
        or value["sequence_floor"] < 0
        or not isinstance(value["owner"], dict)
        or set(value["owner"]) != {"endpoint", "token_file"}
        or not _word(value["owner"]["endpoint"])
        or not isinstance(value["owner"]["token_file"], str)
        or not Path(value["owner"]["token_file"]).is_absolute()
        or not isinstance(value["readers"], list)
        or not value["readers"]
    ):
        raise ValueError("native_configuration_invalid")
    from datetime import datetime

    if (
        datetime.fromisoformat(
            value["activation_at"].replace("Z", "+00:00")
        ).utcoffset()
        is None
    ):
        raise ValueError("native_configuration_invalid")
    for reader in value["readers"]:
        if (
            not isinstance(reader, dict)
            or set(reader)
            != {
                "principal",
                "workspace",
                "agents",
                "actions",
                "sharing_approved",
                "revision",
                "token_file",
                "content_types",
            }
            or any(
                not _word(reader[k], 200)
                for k in ("principal", "workspace", "revision")
            )
            or type(reader["sharing_approved"]) is not bool
            or not isinstance(reader["content_types"], list)
            or any(
                not isinstance(k, str) or k not in {"text", "image", "voice", "file"}
                for k in reader["content_types"]
            )
            or len(set(reader["content_types"])) != len(reader["content_types"])
            or not isinstance(reader["agents"], list)
            or any(not _word(a, 100) for a in reader["agents"])
            or len(set(reader["agents"])) != len(reader["agents"])
            or not isinstance(reader["actions"], list)
            or not reader["actions"]
            or any(
                not isinstance(a, str) or a not in ACTIONS for a in reader["actions"]
            )
            or len(set(reader["actions"])) != len(reader["actions"])
            or bool(set(reader["actions"]) & (BODY | {"original_authority"}))
            != bool(reader["content_types"])
            or not isinstance(reader["token_file"], str)
            or not Path(reader["token_file"]).is_absolute()
            or set(reader["actions"]) & BODY
            and not reader["agents"]
        ):
            raise ValueError("native_configuration_invalid")
    if len({r["principal"] for r in value["readers"]}) != len(value["readers"]):
        raise ValueError("native_configuration_invalid")
    return value


class NativeService:
    def __init__(self, config, *, current_configuration, owner=None):
        self.config = deepcopy(config)
        self.native = validate_native(config)
        self.current_configuration = current_configuration
        self.enabled = bool(
            config["enabled"] and self.native and self.native["enabled"]
        )
        self.owner = None
        self.last_success_at = None
        self.last_failure_at = None
        self.tokens = {}
        if self.enabled:
            legacy_token = read_private_bytes(config["read_token_file"], 4096).strip()
            owner_token = read_private_bytes(
                self.native["owner"]["token_file"], 4096
            ).strip()
            for reader in self.native["readers"]:
                token = read_private_bytes(reader["token_file"], 4096).strip()
                if (
                    len(token) < 32
                    or token in {owner_token, legacy_token}
                    or any(c <= 32 for c in token)
                ):
                    raise ValueError("native_credential_invalid")
                self.tokens[reader["principal"]] = sha256(token).hexdigest()
            if len(set(self.tokens.values())) != len(self.tokens):
                raise ValueError("native_credential_invalid")
            self.owner = owner or WxOwnerClient(
                **dict(
                    endpoint=self.native["owner"]["endpoint"],
                    token_file=self.native["owner"]["token_file"],
                    account=config["account"],
                    thread=config["thread"],
                )
            )

    def _store(self):
        return NativeWechatStore(
            self.config["database"],
            account=self.config["account"],
            thread=self.config["thread"],
            source=self.config["source"],
            scope=self.config["scope"],
            parser_version=self.native["parser_version"],
            sequence_floor=self.native["sequence_floor"],
            start_cursor=str(self.config["start_cursor"]),
        )

    def _profile(self, headers, args):
        if not self.enabled or self.current_configuration() != self.config:
            raise NativeError(403)
        principal = headers.get("X-Operator")
        found = [r for r in self.native["readers"] if r["principal"] == principal]
        if len(found) != 1:
            raise NativeError(403)
        reader = found[0]
        token = read_private_bytes(reader["token_file"], 4096).decode().strip()
        if (
            sha256(token.encode()).hexdigest() != self.tokens[principal]
            or not hmac.compare_digest(
                headers.get("Authorization", ""), "Bearer " + token
            )
            or not reader["sharing_approved"]
            or args.get("source") != self.config["source"]
            or args.get("scope") != self.config["scope"]
            or args.get("workspace") != reader["workspace"]
        ):
            raise NativeError(403)
        return reader

    def _grant(self, reader, agent):
        return dict(
            source=self.config["source"],
            scope=self.config["scope"],
            principal=reader["principal"],
            workspace=reader["workspace"],
            agent=agent,
            revision=digest([self.config, self.tokens]),
            active=True,
            read_only=True,
            workspace_allowed=True,
        )

    def _purpose(self, reader, args, *, worker=False):
        stages = {"materialize"} if worker else {"dispatch", "result", "display"}
        if args.get("stage") not in stages or args.get("agent") not in reader["agents"]:
            raise NativeError(403)

    @staticmethod
    def _content_allowed(reader, snapshot):
        # Materialization changes representation, never the original sharing category.
        kinds = {snapshot["message_type"]} | {
            a["kind"] for a in snapshot.get("assets", snapshot.get("media", []))
        }
        return kinds <= set(reader["content_types"])

    def _fresh(self, store, snapshot):
        try:
            if snapshot["recalled"]:
                raise NativeError(409)
            facts = self.owner.status()
            if (
                not isinstance(facts, dict)
                or facts.get("account") != self.config["account"]
                or facts.get("authenticated") is not True
                or facts.get("contact_sync_ready") is not True
                or facts.get("connection") != "online"
                or facts.get("incoming_transport") != "native_push"
            ):
                raise NativeError(409)
            fresh = self.owner.message(snapshot["message_id"])
            if fresh["recalled"] or store.input_hash(fresh) != snapshot["input_hash"]:
                raise NativeError(409)
        except NativeError:
            raise
        except Exception:
            raise NativeError(409) from None

    def collect(self, filename, *, max_events=1000):
        """Observe the existing owner journal; never acknowledge the wx daemon."""
        if not self.enabled or self.current_configuration() != self.config:
            raise NativeError(403)
        from datetime import datetime, timezone

        activation = datetime.fromisoformat(
            self.native["activation_at"].replace("Z", "+00:00")
        )
        store = self._store()
        examined = 0
        try:
            cursor = store.observer_cursor()
            with Path(filename).open() as stream:
                for line in stream:
                    if not line.endswith("\n"):
                        break
                    if len(line.encode()) > 1024 * 1024:
                        raise NativeError(409)
                    event = json.loads(line)
                    next_cursor = event.get("cursor")
                    if (
                        not isinstance(next_cursor, str)
                        or not next_cursor.isascii()
                        or not next_cursor.isdecimal()
                        or str(int(next_cursor)) != next_cursor
                        or not 0 < int(next_cursor) < 2**63
                    ):
                        raise NativeError(409)
                    if int(next_cursor) <= int(cursor):
                        continue
                    if examined >= max_events:
                        break
                    data = event.get("data")
                    if not isinstance(data, dict):
                        raise NativeError(409)
                    message_id = None
                    unresolved = False
                    if event.get("accountId") == self.config["account"]:
                        kind = event.get("kind")
                        if (
                            kind == "message.committed"
                            and data.get("threadId") == self.config["thread"]
                            and data.get("direction") == "incoming"
                        ):
                            message_id = data.get("messageId")
                            unresolved = message_id is None
                        elif kind == "media.ready":
                            message_id = store.find_message_by_asset(
                                data.get("assetId")
                            )
                            unresolved = message_id is None
                        elif (
                            kind == "message.recalled"
                            and data.get("threadId") == self.config["thread"]
                        ):
                            candidate = data.get("messageId")
                            if (
                                _word(candidate)
                                and store.snapshot_by_message(candidate) is not None
                            ):
                                message_id = candidate
                            else:
                                message_id = store.find_message_by_server_id(
                                    data.get("serverId")
                                )
                            unresolved = message_id is None
                    if message_id is not None and not _word(message_id):
                        message_id, unresolved = None, True
                    if message_id is not None:
                        prior = store.snapshot_by_message(message_id)
                        message = self.owner.message(message_id)
                        if prior is not None and prior["recalled"]:
                            store.advance_observer_cursor(cursor, next_cursor)
                            cursor = next_cursor
                            examined += 1
                            continue
                        baseline = (
                            message["business_at"] is None
                            or data.get("origin") not in {"live", "catchup"}
                            or datetime.fromisoformat(
                                message["business_at"].replace("Z", "+00:00")
                            )
                            < activation
                        )
                        if prior is not None:
                            baseline = prior["baseline"]
                        if (
                            event.get("kind") == "message.recalled"
                            and not message["recalled"]
                        ):
                            raise NativeError(409)
                        store.commit_native(
                            message,
                            event_cursor=next_cursor,
                            observed_at=event.get("createdAt")
                            or datetime.now(timezone.utc).isoformat(),
                            baseline=baseline,
                        )
                    elif unresolved:
                        event_id = digest(
                            ["native-unresolved", self.config["account"], next_cursor]
                        )
                        store.commit_unresolved(event_id, next_cursor)
                    store.advance_observer_cursor(cursor, next_cursor)
                    cursor = next_cursor
                    examined += 1
            if self.current_configuration() != self.config:
                raise NativeError(403)
            from datetime import timezone

            self.last_success_at = datetime.now(timezone.utc).isoformat()
            return examined
        except Exception:
            from datetime import timezone

            self.last_failure_at = datetime.now(timezone.utc).isoformat()
            raise
        finally:
            store.close()

    def authorize(self, method, route, headers, args):
        """Check every route capability before the HTTP handler reads request bodies."""
        reader = self._profile(headers, args)
        action, allowed = ROUTES.get(route, (None, set()))
        if method == "POST" and route == "/native/materializations":
            action = "save_materialization"
        elif method != "GET":
            raise NativeError(403)
        required_action = (
            "save_materialization" if action == "operation_receipt" else action
        )
        if (
            required_action not in reader["actions"]
            or set(args) - {"source", "scope", "workspace"} - allowed
        ):
            raise NativeError(403)
        if action in BODY or action == "operation_receipt":
            worker = action in {
                "materialization_records",
                "save_materialization",
                "operation_receipt",
            } or (
                args.get("stage") == "materialize"
                and "save_materialization" in reader["actions"]
            )
            self._purpose(reader, args, worker=worker)
        return reader, action

    def dispatch(self, method, route, headers, args, body=None):
        reader, action = self.authorize(method, route, headers, args)
        if action == "binding":
            return dict(
                source=self.config["source"],
                scope=self.config["scope"],
                principal=reader["principal"],
                workspace=reader["workspace"],
                revision=self._grant(reader, None)["revision"],
                account=self.config["account"],
                thread=self.config["thread"],
                origin="owner_source_binding",
            )
        if action == "metadata_authority":
            stage, agent = args.get("stage"), args.get("agent")
            if (
                stage not in {"ingest", "dispatch", "result", "display", "materialize"}
                or args.get("audience_workspace") != reader["workspace"]
                or (
                    stage == "ingest"
                    and agent is not None
                    and agent not in reader["agents"]
                )
                or stage != "ingest"
                and (
                    agent not in reader["agents"]
                    or "original_authority" not in reader["actions"]
                )
            ):
                raise NativeError(403)
        store = self._store()
        try:
            if action == "changes":
                result = store.changes(
                    args.get("cursor"), int(args.get("limit", "100"))
                )
            elif action == "operation_receipt":
                result = store.lookup_operation(args["operation_id"])
                if result is None:
                    raise NativeError(404)
            elif action == "metadata_authority":
                result = dict(
                    grant=self._grant(reader, args.get("agent")),
                    binding=dict(
                        account=self.config["account"],
                        thread=self.config["thread"],
                        revision=digest(
                            [
                                self.config["account"],
                                self.config["thread"],
                                self.native["parser_version"],
                            ]
                        ),
                    ),
                )
                facts = self.owner.status()
                if isinstance(facts, dict):
                    expected = {
                        "account",
                        "authenticated",
                        "connection",
                        "incoming_transport",
                        "contact_sync_ready",
                        "observed_at",
                    }
                    if (
                        set(facts) == expected
                        and facts["account"] == self.config["account"]
                    ):
                        result["collector"] = facts
                if ("reference" in args) != ("version" in args):
                    raise NativeError(403)
                if "reference" in args:
                    snapshot = store.snapshot(args["reference"], args["version"])
                    if args["stage"] != "ingest":
                        if snapshot["recalled"]:
                            raise NativeError(409)
                        if not self._content_allowed(reader, snapshot):
                            raise NativeError(403)
                        self._fresh(store, snapshot)
                    result["original"] = {
                        k: snapshot[k]
                        for k in (
                            "reference",
                            "version",
                            "native_version",
                            "recalled",
                            "input_hash",
                            "parser_version",
                            "result_sha256",
                        )
                    }
                    result["original"].update(
                        available=snapshot["status"] == "COMPLETE"
                        and not snapshot["recalled"],
                        dispatch_eligible=snapshot["dispatch_eligible"],
                    )
            elif action == "descriptor":
                if args.get("include_history", "false") not in {"true", "false"}:
                    raise NativeError(403)
                result = store.descriptor(
                    args["reference"],
                    args["version"],
                    include_history=args.get("include_history") == "true",
                )
            elif action == "materialization_records":
                result = store.materialization_records(
                    args.get("cursor"),
                    int(args.get("limit", "100")),
                    parser_version=args["parser_version"],
                )
                result["items"] = [
                    r for r in result["items"] if self._content_allowed(reader, r)
                ]
            else:
                payload = body if action == "save_materialization" else args
                if not isinstance(payload, dict):
                    raise NativeError(403)
                if (
                    action == "save_materialization"
                    and store.lookup_operation(payload.get("operation_id")) is not None
                ):
                    result = store.save_materialization(**payload)
                    self._profile(headers, args)
                    return result
                snapshot = store.snapshot(
                    payload["reference"],
                    payload["version"],
                    include_history=action == "save_materialization",
                )
                if snapshot["recalled"]:
                    raise NativeError(409)
                if not self._content_allowed(reader, snapshot):
                    raise NativeError(403)
                if action == "media":
                    assets = [
                        a
                        for a in snapshot["media"]
                        if a["asset_id"] == args.get("asset_id")
                    ]
                    if len(assets) != 1:
                        raise NativeError(404)
                self._fresh(store, snapshot)
                if action == "media":
                    data = self.owner.media(snapshot["message_id"], assets[0])
                    if (
                        not isinstance(data, bytes)
                        or len(data) != assets[0]["byte_length"]
                        or sha256(data).hexdigest() != assets[0]["sha256"]
                    ):
                        raise NativeError(409)
                    result = (data, assets[0]["content_type"])
                elif action == "save_materialization":
                    expected = {
                        "reference",
                        "version",
                        "input_hash",
                        "parser_version",
                        "status",
                        "content_text",
                        "parts",
                        "issues",
                        "media_hashes",
                        "operation_id",
                    }
                    if set(payload) != expected:
                        raise NativeError(403)
                    result = store.save_materialization(**payload)
                elif action == "derived":
                    result = store.read_derived(
                        args["reference"], args["version"], args["parser_version"]
                    )
                else:
                    if snapshot["status"] != "COMPLETE":
                        if action == "manifest":
                            result = dict(
                                reference=args["reference"],
                                version=args["version"],
                                kind="media",
                                native_version=snapshot["native_version"],
                                assets=deepcopy(snapshot["media"]),
                            )
                        else:
                            raise NativeError(409)
                    else:
                        text = (
                            snapshot["body"]
                            if snapshot["message_type"] == "text"
                            else store.read_derived(
                                args["reference"],
                                args["version"],
                                self.native["parser_version"],
                            )["content_text"]
                        )
                        chunks = []
                        current = ""
                        for char in text:
                            if len((current + char).encode()) > 16384:
                                chunks.append(current)
                                current = ""
                            current += char
                        chunks.append(current)
                        if action == "original":
                            result = dict(
                                reference=args["reference"],
                                version=args["version"],
                                text=text,
                            )
                        elif action == "manifest":
                            result = dict(
                                reference=args["reference"],
                                version=args["version"],
                                kind="text",
                                byte_length=len(text.encode()),
                                sha256=sha256(text.encode()).hexdigest(),
                                parts=len(chunks),
                            )
                        elif action == "chunk":
                            index = int(args["part_index"])
                            if index < 0 or index >= len(chunks):
                                raise NativeError(404)
                            result = dict(
                                reference=args["reference"],
                                version=args["version"],
                                part_index=index,
                                text=chunks[index],
                                has_more=index + 1 < len(chunks),
                            )
                        else:
                            raise NativeError(403)
                # A result write publishes a new owner ref; raw native input remains the same.
                self._fresh(store, snapshot)
            self._profile(headers, args)
            return result
        except NativeError:
            raise
        except ValueError as error:
            raise NativeError(
                404 if str(error) == "native_original_unavailable" else 409
            ) from None
        except (KeyError, TypeError):
            raise NativeError(409) from None
        finally:
            store.close()
