"""Private evidence references and review candidates; no runtime enable or business I/O.

Real evidence enters only through an injected existing-owner verifier. The CLI
intentionally imports synthetic evidence only. Neither a model nor JSON can
choose its own real provenance. This is an audit consumer, not an authority.
"""
from datetime import date, datetime, timezone
from hashlib import sha256
import json
import os
import math
import re
from pathlib import Path
import sqlite3
import stat
from zoneinfo import ZoneInfo

SAMPLES = ("normal", "no_action", "ambiguous", "complete", "correct")
RECOVERY = ("pause_resume", "backup_restore", "offline", "unknown_recovery")
RUNTIME = ("native_entry", "hermes_identity", "gd_readback", "archive_saved", "archive_index",
           "real_model", "deployment", "business_result")
METRICS = ("omissions", "duplicates", "manual_additions", "corrections", "closures", "archives",
           "source_latency_ms", "main_latency_ms", "assistant_latency_ms", "gd_latency_ms",
           "archive_latency_ms", "index_latency_ms", "main_cost", "assistant_cost", "total_cost")


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False)


def digest(value):
    return sha256(canonical(value).encode()).hexdigest()


def aware(value):
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.utcoffset() is None:
        raise ValueError("aware_time_required")
    return result


def private_file(path, *, exclusive=False, create=True):
    flags = os.O_RDWR | os.O_NOFOLLOW | (os.O_CREAT if create else 0) | (os.O_EXCL if exclusive else 0)
    fd = os.open(path, flags, 0o600)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
            raise ValueError("private_state_required")
    finally:
        os.close(fd)


def validate_configuration(config):
    try:
        if (set(config) - {"version", "timezone", "holidays", "working_dates", "rules", "uncovered_sources"}
                or type(config["version"]) is not int or config["version"] != 1):
            raise ValueError()
        ZoneInfo(config["timezone"])
        for field in ("holidays", "working_dates"):
            if not isinstance(config[field], list) or any(date.fromisoformat(d).isoformat() != d for d in config[field]):
                raise ValueError()
        if set(config["holidays"]) & set(config["working_dates"]):
            raise ValueError()
        rules = config["rules"]
        if not isinstance(rules, list) or not 1 <= len(rules) <= 100 or len({r["id"] for r in rules}) != len(rules):
            raise ValueError()
        def identifier(value):
            return isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_.:/-]{1,256}", value)
        for rule in rules:
            if (set(rule) != {"id", "version", "sources", "identity", "model_version", "switches", "resources", "budget", "rollback"}
                    or any(not identifier(rule[k]) for k in ("id", "version", "model_version", "rollback"))
                    or not isinstance(rule["sources"], list) or not rule["sources"]
                    or len({canonical(s) for s in rule["sources"]}) != len(rule["sources"])):
                raise ValueError()
            for scope in rule["sources"]:
                if set(scope) != {"source", "module"} or any(not identifier(v) for v in scope.values()):
                    raise ValueError()
            binding = rule["identity"]
            if (set(binding) != {"agent", "employee", "profile", "revision"}
                    or any(not identifier(v) for v in binding.values())
                    or binding["profile"].lower() in {"default", "admin", "root", "auto", "administrator"}):
                raise ValueError()
            switches = rule["switches"]
            if (set(switches) != {"collection", "observation", "maintenance", "notifications"}
                    or any(type(v) is not bool for v in switches.values())
                    or switches["maintenance"] or switches["notifications"]):
                raise ValueError()
            resources = rule["resources"]
            if (set(resources) != {"concurrency", "timeout_seconds"}
                    or any(type(v) is not int or v < 1 for v in resources.values())
                    or resources["concurrency"] > 4 or resources["timeout_seconds"] > 600):
                raise ValueError()
            budget = rule["budget"]
            if (set(budget) != {"currency", "limit"} or not identifier(budget["currency"])
                    or type(budget["limit"]) not in {int, float} or not math.isfinite(budget["limit"]) or budget["limit"] <= 0):
                raise ValueError()
        excluded = config.get("uncovered_sources", [])
        if not isinstance(excluded, list):
            raise ValueError()
        for scope in excluded:
            if set(scope) != {"source", "module", "reason"} or any(not identifier(v) for v in scope.values()):
                raise ValueError()
    except (ValueError, KeyError, TypeError, AttributeError):
        raise ValueError("invalid_observation_configuration") from None


class Observation:
    def __init__(self, database, configuration, *, clock=None, verify=None):
        validate_configuration(configuration)
        self.config = json.loads(canonical(configuration))
        self.zone = ZoneInfo(self.config["timezone"])
        self.rules = {r["id"]: r for r in self.config["rules"]}
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.verify = verify
        private_file(database)
        self.db = sqlite3.connect(database, timeout=10)
        self.db.execute("CREATE TABLE IF NOT EXISTS config (value TEXT NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS evidence (id TEXT PRIMARY KEY, value TEXT NOT NULL, previous TEXT NOT NULL, hash TEXT NOT NULL)")
        if self.db.execute("SELECT COUNT(*) FROM config").fetchone()[0] == 0:
            self.db.execute("INSERT INTO config VALUES (?)", (canonical(self.config),))
        self.db.commit()
        if self.db.execute("SELECT value FROM config").fetchall() != [(canonical(self.config),)]:
            self.close()
            raise ValueError("configuration_drift")

    def close(self):
        self.db.close()

    def records(self):
        result, previous = [], digest(self.config)
        for key, raw, expected_previous, fingerprint in self.db.execute("SELECT id,value,previous,hash FROM evidence ORDER BY rowid"):
            value = json.loads(raw)
            if key != value["record"]["id"] or previous != expected_previous or digest([previous, value]) != fingerprint:
                raise ValueError("evidence_integrity_failed")
            result.append(value)
            previous = fingerprint
        return result

    def _validate_record(self, record):
        try:
            if (record["rule"] not in self.rules or record["kind"] not in SAMPLES + RECOVERY + RUNTIME + ("daily", "metrics")
                    or record["outcome"] not in {"passed", "failed", "unknown", "unmeasured", "pending"}
                    or {k: record[k] for k in ("source", "module")} not in self.rules[record["rule"]]["sources"]
                    or aware(record["at"]) > self.clock()):
                raise ValueError()
            required = {"id", "rule", "source", "module", "kind", "outcome", "at", "references"}
            extra = ({"window_start", "window_end", "gd_writes", "notifications"} if record["kind"] == "daily"
                     else {"measurements"} if record["kind"] == "metrics" else set())
            if set(record) != required | extra:
                raise ValueError()
            if (not isinstance(record["id"], str) or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,256}", record["id"])
                    or not isinstance(record["references"], list) or not 1 <= len(record["references"]) <= 100
                    or any(not isinstance(ref, str) or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,512}", ref) for ref in record["references"])):
                raise ValueError()
            if record["kind"] == "metrics":
                measurements = record["measurements"]
                if (not isinstance(measurements, dict) or not measurements or measurements.keys() - set(METRICS)
                        or any(v is not None and (type(v) not in {int, float} or not math.isfinite(v) or v < 0
                            or k in METRICS[:6] and type(v) is not int) for k, v in measurements.items())):
                    raise ValueError()
            if record["kind"] == "daily":
                start, end = (aware(record[k]).astimezone(self.zone) for k in ("window_start", "window_end"))
                if (start.date() != end.date() or start.strftime("%H:%M:%S") != "00:00:00"
                        or end.strftime("%H:%M:%S") != "23:59:59" or start.microsecond or end.microsecond
                        or end.date() >= self.clock().astimezone(self.zone).date()
                        or not self.business_day(start.date()) or aware(record["at"]) < end
                        or type(record["gd_writes"]) is not int or type(record["notifications"]) is not int
                        or record["gd_writes"] != 0 or record["notifications"] != 0):
                    raise ValueError()
        except (KeyError, TypeError, ValueError, AttributeError):
            raise ValueError("invalid_evidence") from None

    def synthetic(self, record):
        return self._append(record, "synthetic", None)

    def real(self, request):
        """Opaque operator request, resolved by current trusted source/runtime owner.

        The verifier must independently check the original receipts, complete
        source windows, read-only observation and exact configured identities.
        Echoing caller JSON is a fixture, never a production verifier.
        """
        try:
            proof = self.verify(request)
            if (proof["active"] is not True or proof["provenance"] != "real_observation"
                    or proof["configuration_hash"] != digest(self.config)
                    or not isinstance(proof["authority"], str)
                    or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,512}", proof["authority"])):
                raise ValueError()
            record = proof["record"]
        except Exception:
            raise ValueError("real_authority_required") from None
        return self._append(record, "real_observation", proof["authority"])

    def _append(self, record, provenance, authority):
        self._validate_record(record)
        value = dict(record=json.loads(canonical(record)), provenance=provenance, authority=authority)
        self.db.execute("BEGIN IMMEDIATE")
        try:
            records = self.records()
            previous = next((r for r in records if r["record"]["id"] == record["id"]), None)
            if previous is not None:
                if previous != value:
                    raise ValueError("evidence_identity_conflict")
                self.db.rollback()
                return record["id"]
            last = self.db.execute("SELECT hash FROM evidence ORDER BY rowid DESC LIMIT 1").fetchone()
            chain = last[0] if last else digest(self.config)
            self.db.execute("INSERT INTO evidence VALUES (?,?,?,?)", (record["id"], canonical(value), chain, digest([chain, value])))
            self.db.commit()
        except BaseException:
            self.db.rollback()
            raise
        return record["id"]

    def backup(self, destination):
        """SQLite-consistent evidence snapshot only, not a Workspace/connector backup."""
        destination = Path(destination)
        private_file(destination, exclusive=True)
        target = sqlite3.connect(destination)
        try:
            self.db.backup(target)
            if target.execute("PRAGMA integrity_check").fetchone() != ("ok",):
                raise ValueError("backup_integrity_failed")
        finally:
            target.close()
        checked = Observation(destination, self.config, clock=self.clock)
        try:
            count = len(checked.records())
        finally:
            checked.close()
        return dict(sha256=sha256(destination.read_bytes()).hexdigest(), evidence_count=count,
                    configuration_hash=digest(self.config), scope="observation_ledger_only")

    @classmethod
    def restore(cls, backup, destination, configuration, *, checksum, clock=None, verify=None):
        backup, destination = Path(backup), Path(destination)
        private_file(backup, create=False)
        if sha256(backup.read_bytes()).hexdigest() != checksum:
            raise ValueError("backup_checksum_mismatch")
        # Check provenance/configuration before creating a new destination.
        source = cls(backup, configuration, clock=clock)
        try:
            source.records()
            source.backup(destination)
        finally:
            source.close()
        return cls(destination, configuration, clock=clock, verify=verify)

    def candidates(self):
        report = self.report()
        candidates = []
        for gate in report["rules"]:
            rule = self.rules[gate["rule"]]
            candidates.append(dict(rule=rule["id"], rule_version=rule["version"],
                scope=rule["sources"], identity=rule["identity"], model_version=rule["model_version"],
                resources=rule["resources"], budget=rule["budget"],
                eligible_for_review=gate["eligible_for_review"], gaps=gate["gaps"],
                receipts=[e["record"]["id"] for e in self.records() if e["record"]["rule"] == rule["id"]],
                enable=dict(switches=rule["switches"],
                            proposed_switches={**rule["switches"], "maintenance": gate["eligible_for_review"], "notifications": False},
                            requires="existing_scope_and_deployment_approval"),
                rollback=dict(switches={**rule["switches"], "maintenance": False, "notifications": False},
                              method=rule["rollback"], preserve_unknown_requests=True,
                              preserve_evidence=True, undo_business_facts=False)))
        return json.loads(canonical(dict(schema="enterprise-release-candidate-v1", rules=candidates,
                    uncovered_sources=self.config.get("uncovered_sources", []), formal_enablement=False)))

    @staticmethod
    def _metrics(rows, provenance):
        result = {}
        for metric in METRICS:
            records = [e["record"] for e in rows if e["provenance"] == provenance
                       and e["record"]["kind"] == "metrics" and metric in e["record"]["measurements"]]
            measured = [r for r in records if r["measurements"][metric] is not None and r["outcome"] == "passed"]
            unknown = len(records) - len(measured)
            result[metric] = dict(state="partial" if measured and unknown else "measured" if measured else "unmeasured",
                values=[r["measurements"][metric] for r in measured], evidence=[r["id"] for r in measured], unmeasured=unknown)
        return result

    def business_day(self, day):
        return (day.isoformat() in self.config["working_dates"] or
                day.weekday() < 5 and day.isoformat() not in self.config["holidays"])

    def report(self):
        entries = self.records()
        rules = []
        for rule in self.rules.values():
            gaps, days_by_scope, coverage = [], {}, []
            if not rule["switches"]["collection"] or not rule["switches"]["observation"]:
                gaps.append("observation_switches_disabled")
            rows = [e for e in entries if e["record"]["rule"] == rule["id"]]
            simulation_times = []
            for scope in rule["sources"]:
                for kind in SAMPLES + RECOVERY:
                    matching = [e["record"] for e in rows if e["provenance"] == "synthetic"
                                and e["record"]["kind"] == kind
                                and all(e["record"][k] == v for k, v in scope.items())]
                    latest = sorted(matching, key=lambda r: aware(r["at"]))[-1] if matching else None
                    if latest and latest["outcome"] == "passed":
                        simulation_times.append(aware(latest["at"]))
            simulation_ready = (max(simulation_times) if len(simulation_times) ==
                                len(rule["sources"]) * len(SAMPLES + RECOVERY) else None)
            for scope in rule["sources"]:
                scope_id = scope['source'] + '/' + scope['module']
                scoped = [e for e in rows if all(e["record"][k] == v for k, v in scope.items())]
                real = [e["record"] for e in scoped if e["provenance"] == "real_observation"]
                synthetic = [e["record"] for e in scoped if e["provenance"] == "synthetic"]
                daily = {}
                for row in sorted((r for r in real if r["kind"] == "daily"), key=lambda r: aware(r["at"])):
                    daily[aware(row["window_start"]).astimezone(self.zone).date().isoformat()] = row
                days = sorted(day for day, row in daily.items() if row["outcome"] == "passed")
                days_by_scope[scope_id] = days
                if len(days) < 3:
                    gaps.append("three_business_days:" + scope_id)
                cell = dict(**scope, real={}, synthetic={},
                            metrics=self._metrics(scoped, "real_observation"),
                            qualified_business_days=[day for day in days if simulation_ready is not None
                                and aware(daily[day]["window_start"]) > simulation_ready])
                if simulation_ready is not None and len(cell["qualified_business_days"]) < 3:
                    gaps.append("simulation_before_observation:" + scope_id)
                coverage.append(cell)
                for prefix, records, kinds in (("synthetic", synthetic, SAMPLES + RECOVERY),
                                                ("real", real, SAMPLES + RUNTIME)):
                    for kind in kinds:
                        matching = [r for r in records if r["kind"] == kind]
                        if prefix == "real" and kind in SAMPLES:
                            matching = [r for r in matching if aware(r["at"]).astimezone(self.zone).date().isoformat()
                                        in cell["qualified_business_days"]]
                        latest = sorted(matching, key=lambda r: aware(r["at"]))[-1] if matching else None
                        cell[prefix][kind] = dict(outcome=latest["outcome"] if latest else "unmeasured",
                                                  evidence=latest["id"] if latest else None)
                        if latest is None or latest["outcome"] != "passed":
                            gaps.append(prefix + ":" + kind + ":" + scope_id)
            metrics = self._metrics(rows, "real_observation")
            synthetic_metrics = self._metrics(rows, "synthetic")
            rules.append(dict(rule=rule["id"], eligible_for_review=not gaps,
                business_days=sorted(set.intersection(*(set(d) for d in days_by_scope.values()))),
                days_by_scope=days_by_scope, coverage=coverage, gaps=gaps, metrics=metrics, synthetic_metrics=synthetic_metrics))
        return dict(schema="enterprise-observation-v1", rules=rules, evidence_count=len(entries),
                    uncovered_sources=json.loads(canonical(self.config.get("uncovered_sources", []))),                    full_system_accepted=False, formal_enablement=False)


def main():
    import argparse
    parser = argparse.ArgumentParser(description="Observation evidence and disabled review candidates; no runtime actions")
    parser.add_argument("--config", required=True)
    parser.add_argument("--database", required=True)
    commands = parser.add_subparsers(dest="command", required=True)
    for command in ("report", "check", "candidates"):
        commands.add_parser(command)
    commands.add_parser("synthetic").add_argument("--evidence", required=True)
    commands.add_parser("backup").add_argument("--destination", required=True)
    restore = commands.add_parser("restore")
    restore.add_argument("--backup", required=True)
    restore.add_argument("--checksum", required=True)
    args = parser.parse_args()
    app = None
    def load(path):
        raw = Path(path).read_bytes()
        if len(raw) > 262144:
            raise ValueError("input_too_large")
        def unique(pairs):
            value = {}
            for key, item in pairs:
                if key in value:
                    raise ValueError("duplicate_member")
                value[key] = item
            return value
        return json.loads(raw, object_pairs_hook=unique)
    try:
        config = load(args.config)
        if args.command == "restore":
            app = Observation.restore(args.backup, args.database, config, checksum=args.checksum)
            result = app.report()
        else:
            app = Observation(args.database, config)
            if args.command == "synthetic":
                result = dict(id=app.synthetic(load(args.evidence)), provenance="synthetic")
            elif args.command == "backup":
                result = app.backup(args.destination)
            elif args.command == "candidates":
                result = app.candidates()
            else:
                result = app.report()
        print(json.dumps(result, ensure_ascii=False, allow_nan=False))
        return int(args.command == "check" and any(r["gaps"] for r in result["rules"]))
    except (OSError, ValueError, KeyError, TypeError, sqlite3.Error):
        print(json.dumps(dict(error="observation_operation_rejected")))
        return 2
    finally:
        if app is not None:
            app.close()


if __name__ == "__main__":
    raise SystemExit(main())
