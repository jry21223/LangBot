"""Versioned personal-WeChat evidence, without Finance or employee claims."""

from copy import deepcopy
from datetime import datetime
import re


class SavedWechat:
    version = "personal-wechat-text-v1"

    def project(self, candidate, selection):
        try:
            change = candidate["change"]
            saved = change["saved"]
            fields = {
                "account_id",
                "thread_id",
                "message_id",
                "sender_id",
                "server_id",
                "message_type",
                "direction",
                "body_available",
            }
            if (
                set(saved) != fields
                or saved["direction"] != "incoming"
                or saved["message_type"] != "text"
                or type(saved["body_available"]) is not bool
                or set(selection) != {"goal", "confirmed", "intent", "candidates"}
            ):
                raise ValueError()
            for key in fields - {"body_available"}:
                value = saved[key]
                if (
                    not isinstance(value, str)
                    or not 1 <= len(value) <= 512
                    or any(ord(c) < 32 for c in value)
                ):
                    raise ValueError()
            for key in ("record", "version"):
                if not re.fullmatch(r"[a-f0-9]{64}", change[key]):
                    raise ValueError()
            if (
                change["original"]
                != f"wechat:message/{change['record']}/{change['version']}"
                or type(change["sequence"]) is not int
                or change["sequence"] < 1
            ):
                raise ValueError()
            for key in ("business_at", "observed_at"):
                if (
                    datetime.fromisoformat(
                        change[key].replace("Z", "+00:00")
                    ).utcoffset()
                    is None
                ):
                    raise ValueError()
            event = {
                key: deepcopy(change[key])
                for key in (
                    "record",
                    "version",
                    "sequence",
                    "business_at",
                    "observed_at",
                )
            }
            event.update(
                source=candidate["source"],
                scope=candidate["scope"],
                evidence=change["original"],
                approval_status="not_applicable",
                evidence_details=deepcopy(saved),
                **deepcopy(selection),
            )
            if not saved["body_available"]:
                event["review_required"] = True
            return event
        except (ValueError, KeyError, TypeError, AttributeError):
            raise ValueError("invalid_saved_wechat") from None
