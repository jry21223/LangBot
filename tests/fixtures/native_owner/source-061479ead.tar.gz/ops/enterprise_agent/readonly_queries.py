"""Assistant-requested SERVICE reads in the existing outbox, with private receipts."""

from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import re
import time

from .business_read_http import (
    QueryOutcomeUnknown,
    ReadOnlyBusiness,
    validated_server_request_id,
)
from .readonly_private import read_private_bytes, read_record, write_record
from .workflow import action_identity, identity


def validate_readonly_business(config, *, agents=None, sources=None, private_root=None):
    if config is None:
        return False
    if config == {"enabled": False}:
        return False
    if (
        not isinstance(config, dict)
        or set(config)
        != {
            "enabled",
            "endpoint",
            "service_id",
            "token_file",
            "private_root",
            "agents",
            "sources",
            "max_queries",
        }
        or config["enabled"] is not True
        or not isinstance(config["agents"], list)
        or not config["agents"]
        or any(
            not isinstance(a, str) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,100}", a)
            for a in config["agents"]
        )
        or len(set(config["agents"])) != len(config["agents"])
        or not isinstance(config["sources"], list)
        or not 1 <= len(config["sources"]) <= 20
        or any(
            not isinstance(s, dict)
            or set(s) != {"source", "scope"}
            or any(
                not isinstance(s[k], str)
                or not re.fullmatch(r"[A-Za-z0-9_.:/-]{1,200}", s[k])
                for k in ("source", "scope")
            )
            for s in config["sources"]
        )
        or len({(s["source"], s["scope"]) for s in config["sources"]})
        != len(config["sources"])
        or type(config["max_queries"]) is not int
        or not 1 <= config["max_queries"] <= 20
        or any(
            not isinstance(config[k], str)
            or not Path(config[k]).is_absolute()
            or "\x00" in config[k]
            for k in ("token_file", "private_root")
        )
    ):
        raise ValueError("readonly_business_configuration_invalid")
    if agents is not None and not set(config["agents"]) <= set(agents):
        raise ValueError("readonly_business_agent_binding_invalid")
    if sources is not None and not {
        (s["source"], s["scope"]) for s in config["sources"]
    } <= set(sources):
        raise ValueError("readonly_business_source_binding_invalid")
    if private_root is not None and config["private_root"] != private_root:
        raise ValueError("readonly_business_private_root_mismatch")
    ReadOnlyBusiness(
        endpoint=config["endpoint"],
        token_file=config["token_file"],
        service_id=config["service_id"],
    )
    return True


def read_bound_proposal(root, workspace, parent, reference):
    if not isinstance(reference, str) or not re.fullmatch(
        r"readonly:proposal/[a-f0-9]{64}", reference
    ):
        raise ValueError("readonly_proposal_invalid")
    digest = reference.rsplit("/", 1)[1]
    proposal, _ = read_record(
        root, "readonly-proposals", digest, expected_hash=digest, limit=32768
    )
    binding = sha256(f"{workspace}/{parent['agent']}".encode()).hexdigest() + ".binding"
    namespace = read_private_bytes(Path(root) / binding, 64).decode()
    if (
        not re.fullmatch(r"[a-f0-9]{64}", namespace)
        or set(proposal)
        != {
            "version",
            "namespace",
            "agent",
            "workspace",
            "channel",
            "trigger",
            "query",
        }
        or type(proposal["version"]) is not int
        or proposal["version"] != 1
        or proposal["namespace"] != namespace
        or proposal["agent"] != parent["agent"]
        or proposal["workspace"] != workspace
        or proposal["channel"] != parent["matter"]
        or proposal["trigger"]
        != dict(
            id=parent["remote_id"],
            source="system:enterprise-agent-1324",
            delivery_key=parent["id"],
        )
        or not isinstance(proposal["query"], dict)
        or set(proposal["query"]) != {"tool", "arguments"}
        or not isinstance(proposal["query"]["tool"], str)
        or not re.fullmatch(
            r"[A-Za-z][A-Za-z0-9_.:-]{0,120}", proposal["query"]["tool"]
        )
        or not isinstance(proposal["query"]["arguments"], dict)
    ):
        raise ValueError("readonly_proposal_binding_invalid")
    return proposal["query"]


class ReadonlyQueries:
    def __init__(self, workflow, config):
        validate_readonly_business(config, agents=workflow.assistants)
        self.workflow, self.config = workflow, deepcopy(config)
        self.root = config["private_root"]
        self.client = ReadOnlyBusiness(
            endpoint=config["endpoint"],
            token_file=config["token_file"],
            service_id=config["service_id"],
        )
        self.scopes = {(s["source"], s["scope"]) for s in config["sources"]}
        workflow.readonly_queries = self

    def _authorize(self, matter, action, stage):
        if (
            action["agent"] not in self.config["agents"]
            or not self.workflow._execution_current(matter, action)
            or not {(e["source"], e["scope"]) for e in matter["evidence"]}
            <= self.scopes
        ):
            raise ValueError("readonly_business_source_denied")
        self.workflow._authorize_matter(matter, stage, action["agent"])

    def prepare_task(self, action, matter):
        if (
            action["stage"] != "assistant"
            or action["agent"] not in self.config["agents"]
        ):
            return False
        self._authorize(matter, action, "dispatch")
        current = self.client.catalog()["binding"]
        with self.workflow._transaction() as state:
            stored = state["outbox"][action["id"]]
            if stored.get("business_manifest", current) != current:
                raise ValueError("readonly_business_catalog_changed")
            stored["business_manifest"] = current
        return True

    def _proposal(self, parent, reference):
        return read_bound_proposal(
            self.root, self.workflow.workspace, parent, reference
        )

    def receive(self, reply):
        state = self.workflow._read()
        parent = next(
            (
                a
                for a in state["outbox"].values()
                if a.get("remote_id") == reply.get("metadata", {}).get("in_reply_to")
            ),
            None,
        )
        if (
            parent is None
            or parent["stage"] != "assistant"
            or parent["status"] != "sent"
            or reply.get("source") != "openagents:" + parent["agent"]
            or reply.get("target") != "channel/" + parent["matter"]
            or reply.get("type") != "workspace.message.posted"
            or reply.get("metadata", {}).get("status_kind") != "completed"
        ):
            return False
        content = json.loads(reply.get("payload", {}).get("content", ""))
        if (
            set(content) != {"decision", "query_ref"}
            or content["decision"] != "readonly_query"
        ):
            raise ValueError("readonly_proposal_invalid")
        matter = state["matters"][parent["matter"]]
        self._authorize(matter, parent, "result")
        if "business_manifest" not in parent:
            raise ValueError("readonly_business_not_offered")
        query = self._proposal(parent, content["query_ref"])
        key = action_identity(parent["id"], "business_read", identity(query))
        with self.workflow._transaction() as current:
            if current["outbox"].get(
                parent["id"]
            ) != parent or not self.workflow._execution_current(
                current["matters"][matter["id"]], parent
            ):
                raise ValueError("readonly_query_stale")
            existing = [
                a
                for a in current["outbox"].values()
                if a["matter"] == matter["id"]
                and a["stage"] == "business_read"
                and a["revision"] == matter["revision"]
                and a.get("run_id") == parent.get("run_id")
            ]
            if len(existing) >= self.config["max_queries"]:
                raise ValueError("readonly_query_budget_exhausted")
            current["outbox"][parent["id"]]["status"] = "completed"
            current["outbox"][key] = dict(
                id=key,
                matter=matter["id"],
                revision=matter["revision"],
                agent=parent["agent"],
                stage="business_read",
                status="pending",
                parent_action=parent["id"],
                proposal_ref=content["query_ref"],
                business_manifest=parent["business_manifest"],
                **{
                    k: parent[k]
                    for k in ("source_document_manifests", "source_document_input")
                    if k in parent
                },
                requested_by=parent["agent"],
                execution_subject="service:" + self.config["service_id"],
                **({k: parent[k] for k in ("run_id", "trigger") if k in parent}),
            )
            current["matters"][matter["id"]]["status"] = "awaiting_business_read"
        return True

    def _current(self, key, stage):
        state = self.workflow._read()
        action = state["outbox"][key]
        matter = state["matters"][action["matter"]]
        self._authorize(matter, action, stage)
        parent = state["outbox"][action["parent_action"]]
        if (
            parent["status"] != "completed"
            or parent["stage"] != "assistant"
            or parent.get("business_manifest") != action["business_manifest"]
        ):
            raise ValueError("readonly_query_stale")
        return action, matter, parent

    def _receipt(self, action):
        receipt, digest = read_record(self.root, "readonly-results", action["id"])
        validated_server_request_id(receipt.get("server_request_id"))
        if (
            receipt.get("query_key") != action["id"]
            or receipt.get("parent_action") != action["parent_action"]
            or receipt.get("proposal_ref") != action["proposal_ref"]
            or receipt.get("requested_by") != action["agent"]
            or receipt.get("execution_subject")
            != "service:" + self.config["service_id"]
            or receipt.get("manifest") != action["business_manifest"]
        ):
            raise ValueError("readonly_receipt_binding_invalid")
        return receipt, digest

    def _complete(self, key):
        action, matter, _ = self._current(key, "result")
        receipt, digest = self._receipt(action)
        if self.client.catalog()["binding"] != receipt["manifest"]:
            raise ValueError("readonly_business_catalog_changed")
        continuation = action_identity(key, "assistant_continuation")
        with self.workflow._transaction() as state:
            current = state["outbox"][key]
            if current != action or not self.workflow._execution_current(
                state["matters"][matter["id"]], current
            ):
                raise ValueError("readonly_query_stale")
            current.update(
                status="completed",
                receipt_sha256=digest,
                receipt_ref="readonly:result/" + digest,
                completed_at=receipt["observed_at"],
            )
            state["outbox"].setdefault(
                continuation,
                dict(
                    id=continuation,
                    matter=matter["id"],
                    revision=action["revision"],
                    agent=action["agent"],
                    stage="assistant",
                    status="pending",
                    business_manifest=action["business_manifest"],
                    **{
                        k: action[k]
                        for k in ("source_document_manifests", "source_document_input")
                        if k in action
                    },
                    readonly_receipt=dict(
                        key=key, sha256=digest, reference="readonly:result/" + digest
                    ),
                    **({k: action[k] for k in ("run_id", "trigger") if k in action}),
                ),
            )
            state["matters"][matter["id"]]["status"] = "awaiting_assistant"

    def step(self, *, limit=20, deadline=None):
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("invalid_readonly_query_limit")
        actions = [
            a
            for a in self.workflow._read()["outbox"].values()
            if a["stage"] == "business_read"
            and a["status"] in {"pending", "running", "query_unknown"}
        ]
        report = dict(completed=0, failed=0, unknown=0)
        for initial in actions[:limit]:
            if deadline is not None and time.monotonic() >= deadline:
                break
            try:
                action, matter, parent = self._current(initial["id"], "dispatch")
                if action["status"] != "pending":
                    try:
                        self._receipt(action)
                    except FileNotFoundError:
                        with self.workflow._transaction() as state:
                            state["outbox"][action["id"]]["status"] = "query_unknown"
                            state["matters"][matter["id"]]["status"] = (
                                "readonly_query_unknown"
                            )
                        report["unknown"] += 1
                        continue
                else:
                    query = self._proposal(parent, action["proposal_ref"])
                    with self.workflow._transaction() as state:
                        if state["outbox"][action["id"]] != action:
                            raise ValueError("readonly_query_stale")
                        state["outbox"][action["id"]]["status"] = "running"
                    result = self.client.execute(
                        query["tool"],
                        query["arguments"],
                        expected=action["business_manifest"],
                        authorize=lambda: self._current(action["id"], "result"),
                    )
                    self._current(action["id"], "result")
                    receipt = dict(
                        result,
                        query_key=action["id"],
                        parent_action=parent["id"],
                        proposal_ref=action["proposal_ref"],
                        requested_by=action["agent"],
                        observed_at=datetime.now(timezone.utc).isoformat(),
                    )
                    write_record(self.root, "readonly-results", action["id"], receipt)
                self._complete(action["id"])
                report["completed"] += 1
            except QueryOutcomeUnknown:
                with self.workflow._transaction() as state:
                    current = state["outbox"].get(initial["id"])
                    if current and current["status"] == "running":
                        current.update(
                            status="query_unknown",
                            failure="readonly_query_outcome_unknown",
                        )
                        state["matters"][current["matter"]]["status"] = (
                            "readonly_query_unknown"
                        )
                report["unknown"] += 1
            except (ValueError, OSError, KeyError, TypeError):
                with self.workflow._transaction() as state:
                    current = state["outbox"].get(initial["id"])
                    if current and current["status"] in {
                        "pending",
                        "running",
                        "query_unknown",
                    }:
                        current.update(
                            status="failed", failure="readonly_query_unavailable"
                        )
                        state["matters"][current["matter"]]["status"] = (
                            "readonly_query_failed"
                        )
                report["failed"] += 1
        return report

    def read_receipt(self, continuation):
        state = self.workflow._read()
        matter = state["matters"][continuation["matter"]]
        self._authorize(matter, continuation, "result")
        descriptor = continuation.get("readonly_receipt", {})
        action = state["outbox"][descriptor["key"]]
        if (
            action["status"] != "completed"
            or action["agent"] != continuation["agent"]
            or action["matter"] != continuation["matter"]
            or action["revision"] != continuation["revision"]
            or action.get("run_id") != continuation.get("run_id")
            or descriptor.get("sha256") != action.get("receipt_sha256")
        ):
            raise ValueError("readonly_receipt_binding_invalid")
        receipt, digest = self._receipt(action)
        if (
            digest != descriptor["sha256"]
            or self.client.catalog()["binding"] != receipt["manifest"]
        ):
            raise ValueError("readonly_receipt_changed")
        return receipt


QUERY_CONTRACT = dict(
    decision="readonly_query",
    tool="one currently authorized readonly tool name",
    arguments="JSON object",
)


def private_business_context(config, state, action):
    """Read-only resolver; never constructs Workflow or writes coordination state."""
    if (
        not validate_readonly_business(config)
        or action["stage"] != "assistant"
        or action["agent"] not in config["agents"]
    ):
        return {}
    matter = state["matters"][action["matter"]]
    if not {(event["source"], event["scope"]) for event in matter["evidence"]} <= {
        (source["source"], source["scope"]) for source in config["sources"]
    }:
        raise ValueError("readonly_business_source_denied")
    client = ReadOnlyBusiness(
        endpoint=config["endpoint"],
        token_file=config["token_file"],
        service_id=config["service_id"],
    )
    catalog = client.catalog()
    if catalog["binding"] != action.get("business_manifest"):
        raise ValueError("readonly_business_catalog_changed")
    result = dict(
        readonly_tools=catalog["tools"], readonly_query_contract=QUERY_CONTRACT
    )
    if "readonly_receipt" in action:
        descriptor = action["readonly_receipt"]
        if set(descriptor) != {"key", "sha256", "reference"}:
            raise ValueError("readonly_receipt_binding_invalid")
        query = state["outbox"][descriptor["key"]]
        receipt, digest = read_record(
            config["private_root"],
            "readonly-results",
            query["id"],
            expected_hash=descriptor["sha256"],
        )
        if (
            query["status"] != "completed"
            or query["stage"] != "business_read"
            or query["agent"] != action["agent"]
            or query["matter"] != action["matter"]
            or query["revision"] != action["revision"]
            or query.get("run_id") != action.get("run_id")
            or action["id"] != action_identity(query["id"], "assistant_continuation")
            or query.get("receipt_sha256") != digest
            or descriptor["reference"] != "readonly:result/" + digest
            or receipt.get("query_key") != query["id"]
            or receipt.get("parent_action") != query["parent_action"]
            or receipt.get("requested_by") != action["agent"]
            or receipt.get("manifest") != catalog["binding"]
            or receipt.get("execution_subject") != "service:" + config["service_id"]
            or receipt.get("proposal_ref") != query["proposal_ref"]
        ):
            raise ValueError("readonly_receipt_binding_invalid")
        validated_server_request_id(receipt.get("server_request_id"))
        result["readonly_result"] = receipt
    if len(json.dumps(result, ensure_ascii=False).encode()) > 262144:
        raise ValueError("readonly_private_context_budget_exceeded")
    if client.catalog()["binding"] != catalog["binding"]:
        raise ValueError("readonly_business_catalog_changed")
    return result


class ReadonlyDispatcher:
    """One existing outbox, with distinct SERVICE and source-owner authorities."""

    def __init__(self, workflow, *, business=None, documents=None):
        self.business, self.documents = business, documents
        workflow.readonly_queries = self

    def prepare_task(self, action, matter):
        available = False
        for controller in (self.documents, self.business):
            if controller is not None and (
                controller.can_prepare(action, matter)
                if hasattr(controller, "can_prepare")
                else action["agent"] in controller.config["agents"]
                and {(e["source"], e["scope"]) for e in matter["evidence"]}
                <= controller.scopes
            ):
                available = controller.prepare_task(action, matter) or available
        return available

    def receive(self, reply):
        if self.documents is not None and self.documents.receive(reply):
            return True
        accepted = self.business is not None and self.business.receive(reply)
        if accepted and self.documents is not None:
            self.documents.acknowledge_reply(reply)
        return accepted

    def step(self, *, limit=20, deadline=None):
        report = dict(completed=0, failed=0, unknown=0)
        for controller in (self.documents, self.business):
            if controller is not None:
                result = controller.step(limit=limit, deadline=deadline)
                for key in report:
                    report[key] += result[key]
        return report

    def final_status(self, state, action, matter):
        return (
            self.documents.final_status(state, action, matter)
            if self.documents is not None
            else "read_only_result"
        )
