"""Explicit test-only result outlet with durable keys and unknown-send reconciliation."""

from copy import deepcopy
import argparse
import json
import subprocess

from ._ledger import PrivateJsonLedger
from .workflow import identity


class WechatReplies(PrivateJsonLedger):
    def __init__(
        self,
        database,
        *,
        account,
        thread,
        source,
        scope,
        goal,
        assistant,
        label="Router 测试结果",
    ):
        self.binding = dict(
            account=account,
            thread=thread,
            source=source,
            scope=scope,
            goal=goal,
            assistant=assistant,
            label=label,
        )
        self._open_ledger(database, "state")
        self.db.execute(
            "INSERT OR IGNORE INTO state VALUES(1, ?)",
            (json.dumps(dict(binding=self.binding, outbox={})),),
        )
        self.db.commit()
        if self._read()["binding"] != self.binding:
            raise ValueError("reply_binding_drift")

    def close(self):
        self.db.close()

    def deliver(self, matter, send, *, qualify, lookup=None):
        """Caller supplies a currently authorized Workflow matter, never raw model routing."""
        event, result = matter.get("event", {}), matter.get("result", {})
        details = event.get("evidence_details", {})
        if (
            matter.get("status") != "read_only_result"
            or event.get("source") != self.binding["source"]
            or event.get("scope") != self.binding["scope"]
            or event.get("goal") != self.binding["goal"]
            or details.get("account_id") != self.binding["account"]
            or details.get("thread_id") != self.binding["thread"]
            or result.get("agent") != self.binding["assistant"]
            or not isinstance(result.get("content"), str)
            or not result["content"].strip()
            or len(result["content"].encode()) > 4096
            or not result.get("event_id")
        ):
            raise ValueError("unapproved_reply")
        key = (
            "wechat-router-lab-"
            + identity(matter["id"], matter["revision"], result["event_id"])[:48]
        )
        text = "[" + self.binding["label"] + "]\n" + result["content"]
        with self._transaction() as state:
            old = state["outbox"].get(key)
            if old is None:
                state["outbox"][key] = dict(
                    key=key,
                    text=text,
                    status="pending",
                    matter=matter["id"],
                    result_event=result["event_id"],
                    submitted=False,
                )
            elif old["text"] != text:
                raise ValueError("reply_content_conflict")
            elif old["status"] == "accepted":
                return deepcopy(old)
        try:
            if not qualify():
                with self._transaction() as state:
                    row = state["outbox"][key]
                    row["blocked"] = True
                    if not row["submitted"]:
                        row["status"] = "held"
                    return deepcopy(row)
            # Unknown outcomes are queried under the ORIGINAL provider key. No
            # blind resend, new key, destination change, or fallback identity.
            if old is not None and old["submitted"]:
                if lookup is None:
                    return deepcopy(old)
                receipt = lookup(key)
            else:
                with self._transaction() as state:
                    state["outbox"][key].update(submitted=True, blocked=False)
                receipt = send(self.binding["thread"], text, key)
            if (
                receipt.get("accountId") != self.binding["account"]
                or receipt.get("destination") != self.binding["thread"]
                or not receipt.get("id")
            ):
                raise ValueError("reply_receipt_mismatch")
            accepted = receipt.get("state") == "accepted" and bool(
                receipt.get("serverId")
            )
            update = dict(status="accepted" if accepted else "unknown", receipt=receipt)
        except Exception:
            update = dict(status="unknown")
        with self._transaction() as state:
            state["outbox"][key].update(update)
            return deepcopy(state["outbox"][key])


def main():
    """One explicitly invoked, bounded test return; no background auto-reply installation."""
    from .run_host import open_host, private_json, runtime_grant
    from .wechat_source import configuration

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host-config", required=True)
    parser.add_argument("--source-config", required=True)
    parser.add_argument("--database", required=True)
    parser.add_argument("--goal", required=True)
    parser.add_argument("--assistant", required=True)
    parser.add_argument("--label", default="Router 测试结果")
    args = parser.parse_args()
    config, source = private_json(args.host_config), configuration(args.source_config)
    if (
        not source["enabled"]
        or source["workspace"] != config["workspace"]
        or args.assistant not in config["assistants"]
        or args.assistant not in source["agents"]
    ):
        raise ValueError("unapproved_reply")
    host, _ = open_host(config)
    replies = None
    try:
        runtime_grant(config, timeout=10, expected_digest=host.runtime_digest)
        replies = WechatReplies(
            args.database,
            account=source["account"],
            thread=source["thread"],
            source=source["source"],
            scope=source["scope"],
            goal=args.goal,
            assistant=args.assistant,
            label=args.label,
        )

        def wx(arguments):
            run = subprocess.run(
                [source["wx"], "--json", "messages", *arguments],
                capture_output=True,
                text=True,
                timeout=40,
                env={"PATH": "/usr/bin:/bin", "NO_PROXY": "*", "no_proxy": "*"},
            )
            if run.returncode:
                raise ValueError("wechat_send_unavailable")
            return json.loads(run.stdout)

        receipts = []

        def current(expected):
            runtime_grant(config, timeout=10, expected_digest=host.runtime_digest)
            if configuration(args.source_config) != source:
                return False
            return any(
                matter == expected for matter in host.workflow.available_matters()
            )

        for matter in host.workflow.available_matters()[:20]:
            if (
                matter["status"] != "read_only_result"
                or matter["event"]["goal"] != args.goal
            ):
                continue
            receipt = replies.deliver(
                matter,
                lambda thread, text, key: wx(
                    [
                        "send",
                        thread,
                        "--text",
                        text,
                        "--idempotency-key",
                        key,
                        "--wait",
                        "30",
                    ]
                ),
                qualify=lambda: current(matter),
                lookup=lambda key: wx(["sends", "lookup", "--idempotency-key", key]),
            )
            receipts.append(
                dict(
                    matter=matter["id"],
                    status=receipt["status"],
                    send_id=receipt.get("receipt", {}).get("id"),
                    server_id=receipt.get("receipt", {}).get("serverId"),
                )
            )
        print(json.dumps(dict(receipts=receipts)))
    finally:
        if replies is not None:
            replies.close()
        host.close()
        host.workflow.close()


if __name__ == "__main__":
    main()
