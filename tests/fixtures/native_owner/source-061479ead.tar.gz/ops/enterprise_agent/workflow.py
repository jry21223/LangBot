"""Durable coordination records, never a GD, payment or knowledge master.

Only trusted adapters may supply projections and current owner authorization.
The protected host consumes those grants; a scheduler cannot manufacture them.
SQLite holds references, not original documents.
"""

from hashlib import sha256
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime
import re
import json
import time
from uuid import UUID, NAMESPACE_URL, uuid5

from ._ledger import PrivateJsonLedger
from ._http_budget import current_deadline


def action_identity(*parts):
    return str(UUID(identity(*parts)[:32], version=5))


def identity(*parts):
    return sha256(json.dumps(parts, ensure_ascii=False).encode()).hexdigest()


@contextmanager
def _operation_budget(deadline):
    previous = current_deadline.get()
    effective = previous if deadline is None else min(deadline, previous or float("inf"))
    token = current_deadline.set(effective)
    try:
        yield
    finally:
        current_deadline.reset(token)


class Workflow(PrivateJsonLedger):
    def _read(self):
        state = super()._read()
        migration = state.get('binding_migration')
        if migration is not None and migration.get('phase') != 'VERIFIED':
            raise ValueError('binding_migration_incomplete')
        return state

    def __init__(self, database, *, workspace, coordinator, assistants, authorize, authorize_evidence=None):
        self.workspace = workspace
        self.coordinator = coordinator
        self.assistants = frozenset(assistants)
        self.authorize = authorize
        self.authorize_evidence = authorize_evidence
        self.understanding = None
        self.readonly_queries = None
        self._open_ledger(database, "state")
        configuration = {
            "workspace": workspace,
            "coordinator": coordinator,
            "assistants": sorted(self.assistants),
        }
        self.db.execute(
            "INSERT OR IGNORE INTO state VALUES (1, ?)",
            (
                json.dumps(
                    {
                        "configuration": configuration,
                        "events": {},
                        "matters": {},
                        "coverage": {},
                        "outbox": {},
                    }
                ),
            ),
        )
        self.db.commit()
        try:
            current_configuration = self._read().get("configuration")
        except BaseException:
            self.db.close()
            raise
        if current_configuration != configuration:
            self.db.close()
            raise ValueError("configuration_drift")

    @contextmanager
    def _transaction(self):
        # Authorize against a detached snapshot, then CAS it in a short SQLite
        # transaction. Source/Workspace HTTP never holds BEGIN IMMEDIATE open.
        baseline = self._read()
        proposed = deepcopy(baseline)
        yield proposed
        with super()._transaction() as current:
            if current != baseline:
                raise ValueError("concurrent_state_change")
            current.clear()
            current.update(proposed)

    def close(self):
        self.db.close()

    def matters(self):
        matters = list(self._read()["matters"].values())
        for matter in matters:
            self._authorize_matter(matter, "display", None)
        return matters

    def available_matters(self):
        """Independent authorized projection; unavailable records stay in the ledger."""
        visible = []
        unavailable = []
        for matter in self._read()["matters"].values():
            try:
                self._authorize_matter(matter, "display", None)
            except ValueError:
                unavailable.append(dict(id=matter["id"], reason="source_unavailable"))
            else:
                visible.append(matter)
        with self._transaction() as state:
            state["unavailable"] = unavailable
        return visible

    def unavailable_matters(self):
        self.available_matters()
        return self._read().get("unavailable", [])

    def coverage(self, source):
        return self._read()["coverage"].get(source)

    def pending(self):
        return [x for x in self.actions() if x["status"] == "pending"]

    def tick(self, workspace, *, max_actions=None, max_matters=None, deadline=None):
        """One bounded scheduler iteration; caller owns scheduling, not a new daemon."""
        if self.understanding is not None:
            proposal_deadline = None if deadline is None else time.monotonic() + max(0, deadline - time.monotonic()) / 3
            self.understanding.poll(workspace, limit=max_matters or 100, deadline=proposal_deadline)
        # Preserve a dispatch share even when one source authorization or reply
        # endpoint consumes its entire polling allowance.
        reply_deadline = (None if deadline is None else
                          time.monotonic() + max(0, deadline - time.monotonic()) / 2)
        matters = (self.available_matters() if max_matters is None and deadline is None else
                   list(self._read()["matters"].values()))
        limit = max_matters if max_matters is not None else (100 if deadline else None)
        selected = self._work_window(matters, "reply_position", limit, deadline=reply_deadline)
        count = min(max_matters or 100, len(matters))
        for index, matter in enumerate(selected):
            if reply_deadline is not None and time.monotonic() >= reply_deadline:
                break
            matter_deadline = (None if reply_deadline is None else time.monotonic() +
                               max(0, reply_deadline - time.monotonic()) / (count - index))
            with _operation_budget(matter_deadline):
                try:
                    # Polling uses the current service read/display grant.
                    # receive/reconcile recheck the exact result agent.
                    self._authorize_matter(matter, "display", None)
                    unresolved = any(
                        a["matter"] == matter["id"] and "message" in a
                        and a["status"] in {"pending", "delivery_unknown"}
                        for a in self._read()["outbox"].values()
                    )
                    replies, cursor = workspace.replies(
                        matter["id"], matter.get("delivery_cursor") if unresolved else matter.get("reply_cursor")
                    )
                    for reply in replies:
                        self.reconcile_delivery(reply)
                        self.receive(reply)
                except Exception:
                    continue  # Source failure cannot consume another matter's budget.
                with self._transaction() as state:
                    state["matters"][matter["id"]][
                        "delivery_cursor" if unresolved else "reply_cursor"
                    ] = cursor
        if self.readonly_queries is not None and (deadline is None or time.monotonic()<deadline):
            self.readonly_queries.step(limit=max_actions or 20,deadline=deadline)
        self.dispatch(workspace, available_only=True, max_actions=max_actions, deadline=deadline)

    def _work_window(self, values, cursor, limit, *, deadline=None):
        """Advance only attempted work, preserving restart fairness after a slow item."""
        if limit is None:
            return iter(values)
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("invalid_dispatch_limit")

        def selected():
            for _ in range(min(limit, len(values))):
                if deadline is not None and time.monotonic() >= deadline:
                    break
                yield self._window(values, cursor, 1)[0]

        return selected()

    def _window(self, values, cursor, limit):
        """Rotate bounded work so an unavailable first record cannot starve later ones."""
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("invalid_dispatch_limit")
        if not values:
            return []
        with self._transaction() as state:
            start = state.get(cursor, 0) % len(values)
            count = min(limit, len(values))
            state[cursor] = (start + count) % len(values)
        return (values[start:] + values[:start])[:count]

    def actions(self):
        state = self._read()
        actions = list(state["outbox"].values())
        for action in actions:
            if action.get("subject_type") == "proposal":
                if self.understanding is None:
                    raise ValueError("understanding_unavailable")
                self.understanding.authorize(action, "display", None)
            else:
                self._authorize_matter(state["matters"][action["matter"]], "display", None)
        return actions

    def _authorize_matter(self, matter, stage, agent):
        # ACLs cover every contributing source. Exact owner-current checks cover
        # only the latest active revision; superseded originals remain audit refs.
        latest = {}
        for event in matter["evidence"]:
            key = (event["source"], event["record"])
            if key not in latest or event["sequence"] > latest[key]["sequence"]:
                latest[key] = event
        participants = {self.coordinator, *self.assistants} if stage == "dispatch" else {agent}
        sources = {(e["source"], e["scope"]) for e in matter["evidence"]}
        for source, scope in sources:
            for participant in participants:
                current = self._grant(source, stage, participant, scope)
                pinned = matter["authorities"][source]
                if any(current[k] != pinned[k] for k in ("principal", "revision", "scope")):
                    raise ValueError("source_unavailable")
        if self.authorize_evidence is not None and stage != "ingest":
            for event in latest.values():
                self.authorize_evidence(event, stage, agent)

    def dispatch(self, workspace, *, available_only=False, max_actions=None, deadline=None):
        if deadline is not None and time.monotonic() >= deadline:
            return
        with _operation_budget(deadline):
            if not workspace.supports_idempotency():
                raise ValueError("idempotent_delivery_required")
            failures = []
            # Bounded dispatch qualifies each action immediately before I/O,
            # rather than pre-scanning every matter through network ACL checks.
            visible = ({m["id"] for m in self.available_matters()}
                       if available_only and max_actions is None and deadline is None else None)
            actions = [
                a for a in self._read()["outbox"].values()
                if a["status"] == "pending" and a['stage'] not in {'business_read','source_read'} and (visible is None or a["matter"] in visible
                                                or a.get("subject_type") == "proposal")
            ]
            limit = max_actions if max_actions is not None else (100 if deadline else None)
            selected = self._work_window(actions, "dispatch_position", limit, deadline=deadline)
            count = min(max_actions or 100, len(actions))
            for index, action in enumerate(selected):
                if deadline is not None and time.monotonic() >= deadline:
                    break
                action_deadline = (None if deadline is None else time.monotonic() +
                                   max(0, deadline - time.monotonic()) / (count - index))
                with _operation_budget(action_deadline):
                    try:
                        self._dispatch_one(workspace, action)
                    except Exception as error:
                        failures.append(error)
            if failures:
                raise failures[0]

    def _dispatch_one(self, workspace, action):
        if action.get("subject_type") == "proposal":
            if self.understanding is None:
                raise ValueError("understanding_unavailable")
            return self.understanding.dispatch_one(workspace, action)
        matter = self._read()["matters"][action["matter"]]
        if not self._execution_current(matter, action):
            return
        self._authorize_matter(matter, "dispatch", action["agent"])
        business_available = (self.readonly_queries is not None
                              and self.readonly_queries.prepare_task(action,matter))
        workspace.ensure_thread(matter["id"], self.coordinator, self.assistants)
        context = {
            "matter": matter["id"],
            "revision": matter["revision"],
            "mode": "observe",
            "association": matter["association"],
            "goal": matter["event"]["goal"],
            "evidence": [
                {
                    k: e[k]
                    for k in (
                        "source",
                        "record",
                        "version",
                        "evidence",
                        "approval_status",
                    )
                }
                | ({"evidence_details": e["evidence_details"]} if "evidence_details" in e else {})
                for e in { (row["source"], row["record"]): row for row in
                    sorted(matter["evidence"], key=lambda item: item["sequence"]) }.values()
            ],
            "payment_status": "unverified",
            "allowed_action": "read_only_analysis",
        }
        if "run_id" in action:
            context["run_id"] = action["run_id"]
        if business_available:
            context['readonly_business_available']=True
            context['reply_contract']=dict(decision='readonly_query or final readonly analysis',
                                           tool='one authorized readonly tool',arguments='JSON object')
        if 'readonly_receipt' in action:
            context['readonly_result']=action['readonly_receipt']
        if action.get("trigger", {}).get("kind") == "recheck":
            context["recheck"] = action["trigger"]
        if action["stage"] == "main":
            context["assistants"] = sorted(self.assistants)
            context["reply_contract"] = {
                "decision": "delegate|record|needs_review",
                "assistant": "explicit allowed agent for delegate",
            }
        message = {
            "network": self.workspace,
            "source": "system:enterprise-agent-1324",
            "type": "workspace.message.posted",
            "target": "channel/" + matter["id"],
            "idempotency_key": action["id"],
            "metadata": {"target_agents": [action["agent"]], "delivery_key": action["id"]},
            "payload": {
                "message_type": "chat",
                "content": json.dumps(context, ensure_ascii=False),
            },
        }
        self._deliver(workspace, action, message)

    def _deliver(self, workspace, action, message):
        """One outbox delivery/recovery path for matters and intake proposals."""
        with self._transaction() as state:
            current = state["outbox"][action["id"]]
            if (current["status"] != "pending" or not self._delivery_current(state, current)
                    or (current.get("subject_type") != "proposal"
                        and not self._execution_current(state["matters"][current["matter"]], current))):
                return
            message = current.setdefault("message", message)
            current["attempts"] = current.get("attempts", 0) + 1
        try:
            remote_id = workspace.post(message)
            if not isinstance(remote_id, str) or not remote_id:
                raise ValueError("delivery_unknown")
        except Exception:
            with self._transaction() as state:
                current = state["outbox"][action["id"]]
                if current["status"] == "pending" and current["attempts"] >= 3:
                    current["status"] = "delivery_unknown"
            raise
        with self._transaction() as state:
            current = state["outbox"][action["id"]]
            if current["status"] == "pending":
                current.update(status="sent", remote_id=remote_id)

    def reconcile_delivery(self, event):
        """Accept only the exact original message read from the trusted native stream."""
        with self._transaction() as state:
            action = state["outbox"].get(
                event.get("idempotency_key") or event.get("metadata", {}).get("delivery_key")
            )
            if action is None:
                # Compatibility for persisted messages predating delivery_key.
                action = next((a for a in state["outbox"].values() if "message" in a
                    and str(uuid5(NAMESPACE_URL, "openagents:message-delivery:" + json.dumps(
                        [a["message"]["network"], a["message"]["source"], a["id"]],
                        separators=(",", ":")))) == event.get("id")), None)
            if not action or action["status"] not in {"pending", "delivery_unknown"}:
                return False
            if not self._delivery_current(state, action):
                return False
            message = action.get("message")
            if (not message or not isinstance(event.get("id"), str) or not event["id"]
                    or any(event.get(k) != message[k] for k in ("source", "target", "type", "payload"))
                    or any(event.get("metadata", {}).get(k) != v for k, v in message["metadata"].items())
                    or event.get("network", message["network"]) != message["network"]):
                return False
            if action.get("subject_type") == "proposal":
                if self.understanding is None:
                    return False
                self.understanding.authorize(action, "result", action["agent"])
            else:
                self._authorize_matter(state["matters"][action["matter"]], "result", action["agent"])
            action.update(status="sent", remote_id=event["id"])
            return True

    def receive(self, reply):
        proposal = next((a for a in self._read()["outbox"].values()
                         if a.get("remote_id") == reply.get("metadata", {}).get("in_reply_to")
                         and a.get("subject_type") == "proposal"), None)
        if proposal:
            return self.understanding is not None and self.understanding.receive(reply, proposal)
        try:
            requested = json.loads(reply.get('payload', {}).get('content', ''))
        except (ValueError, TypeError):
            requested = None
        if isinstance(requested, dict) and requested.get('decision') == 'readonly_query':
            return self.readonly_queries is not None and self.readonly_queries.receive(reply)
        with self._transaction() as state:
            action = next(
                (
                    a
                    for a in state["outbox"].values()
                    if a.get("remote_id")
                    == reply.get("metadata", {}).get("in_reply_to")
                ),
                None,
            )
            if not action or action["status"] != "sent":
                return False
            matter = state["matters"][action["matter"]]
            if (
                reply.get("source") != "openagents:" + action["agent"]
                or reply.get("target") != "channel/" + matter["id"]
                or reply.get("type") != "workspace.message.posted"
            ):
                return False
            if not self._execution_current(matter, action):
                return False
            self._authorize_matter(matter, "result", action["agent"])
            status = reply.get("metadata", {}).get("status_kind")
            if status not in {"completed", "error"}:
                return False
            content = reply.get("payload", {}).get("content")
            if not isinstance(content, str) or len(content) > 16000:
                raise ValueError("invalid_result")
            action["status"] = "completed" if status == "completed" else "failed"
            if status == "error":
                matter["status"] = "execution_failed"
            elif action["stage"] == "main":
                try:
                    decision = json.loads(content)
                    if (
                        decision["decision"] == "delegate"
                        and decision["assistant"] in self.assistants
                    ):
                        matter.update(
                            status="awaiting_assistant", assistant=decision["assistant"]
                        )
                        key = action_identity(
                            matter["id"], (action["run_id"] if action.get("trigger", {}).get("kind") == "recheck"
                                           else matter["revision"]), "assistant"
                        )
                        state["outbox"][key] = {
                            "id": key,
                            "matter": matter["id"],
                            "revision": matter["revision"],
                            "agent": decision["assistant"],
                            "stage": "assistant",
                            "status": "pending",
                            **({"run_id": action["run_id"], "trigger": action["trigger"]}
                               if "run_id" in action else {}),
                        }
                    elif decision["decision"] in {"record", "needs_review"}:
                        matter["status"] = (
                            "recorded"
                            if decision["decision"] == "record"
                            else "needs_review"
                        )
                    else:
                        raise ValueError()
                except (ValueError, KeyError, TypeError):
                    matter["status"] = "needs_review"
            else:
                matter.update(
                    status=(self.readonly_queries.final_status(state,action,matter)
                        if self.readonly_queries is not None and hasattr(self.readonly_queries,"final_status")
                        else "read_only_result"),
                    mode="observe",
                    result={
                        "content": content,
                        "event_id": reply.get("id"),
                        "agent": action["agent"],
                    },
                )
            return True

    @classmethod
    def _execution_current(cls, matter, action):
        """A held association fences execution, independently of delivery audit."""
        return not matter.get("review_required", False) and cls._action_current(matter, action)

    @staticmethod
    def _action_current(matter, action):
        """Evidence revision and execution round are independent fencing tokens."""
        if action["revision"] != matter["revision"]:
            return False
        return (matter.get("current_run_id") is None
                or action.get("run_id") == matter["current_run_id"])

    def _delivery_current(self, state, action):
        if action.get("subject_type") == "proposal":
            candidate = state["producer"]["candidates"][action["candidate"]]
            judgment = candidate.get("understanding", {})
            return judgment.get("action") == action["id"] and judgment.get("version") == action["judgment_version"]
        return self._action_current(state["matters"][action["matter"]], action)

    def _grant(self, source, stage, agent=None, scope=None):
        failure_status = "sync_failed"
        try:
            g = self.authorize(source, stage, agent)
            failure_status = "permission_denied"
            if (
                g["active"] is not True
                or g["read_only"] is not True
                or g["workspace_allowed"] is not True
                or g["source"] != source
                or g["agent"] != agent
                or not g["principal"]
                or not g["revision"]
                or (scope is not None and g["scope"] != scope)
            ):
                raise ValueError()
            return {k: g[k] for k in ("source", "scope", "principal", "revision")}
        except Exception as cause:
            error = ValueError("source_unavailable")
            error.status = getattr(cause, "status", failure_status)
            raise error from None

    def record_coverage(self, source, *, status, cursor=None, previous_cursor=None):
        if status not in {
            "disabled",
            "permission_denied",
            "credential_expired",
            "missing_page",
            "sync_failed",
            "filing_wait",
            "uncovered",
            "success_zero",
        }:
            raise ValueError("invalid_coverage")
        if status == "success_zero":
            self._grant(source, "ingest")
        with self._transaction() as state:
            old = state["coverage"].get(source, {})
            if status == "success_zero" and old.get("cursor") != previous_cursor:
                raise ValueError("cursor_gap")
            state["coverage"][source] = {
                "status": status,
                "cursor": cursor if status == "success_zero" else old.get("cursor"),
            }

    def ingest_page(self, source, events, *, cursor, previous_cursor):
        """Commit each event durably; advance the page only with its final event.

        A crash partway through intentionally replays the page. Already ingested
        records are deduplicated, and an incomplete/invalid page retains its old
        cursor. The caller must never pass a truncated page as a complete one.
        """
        if (
            not isinstance(events, list)
            or len(events) > 100
            or any(e.get("source") != source for e in events)
        ):
            raise ValueError("invalid_projection")
        if self.coverage(source) and self.coverage(source)["cursor"] != previous_cursor:
            if self.coverage(source)["cursor"] == cursor:
                return
            raise ValueError("cursor_gap")
        if not events:
            self.record_coverage(
                source,
                status="success_zero",
                cursor=cursor,
                previous_cursor=previous_cursor,
            )
        for index, e in enumerate(events):
            self.ingest(
                e,
                cursor=cursor if index == len(events) - 1 else previous_cursor,
                previous_cursor=previous_cursor,
            )

    def ingest(self, event, *, cursor, previous_cursor, retain_historical=False, semantic_admission=None):
        e = dict(event)
        required = {
            "source",
            "record",
            "version",
            "sequence",
            "business_at",
            "observed_at",
            "scope",
            "evidence",
            "approval_status",
            "intent",
            "goal",
            "confirmed",
        }
        try:
            if not required <= e.keys() or e.keys() - required - {"candidates", "evidence_details", "review_required"}:
                raise ValueError()
            for field in required - {"sequence", "confirmed"}:
                if (
                    not isinstance(e[field], str)
                    or not e[field]
                    or len(e[field]) > 512
                    or any(ord(c) < 32 for c in e[field])
                ):
                    raise ValueError()
            if (
                type(e["sequence"]) is not int
                or e["sequence"] < 1
                or type(e["confirmed"]) is not bool
            ):
                raise ValueError()
            if type(e.get("review_required", False)) is not bool:
                raise ValueError()
            if "evidence_details" in e and (
                not isinstance(e["evidence_details"], dict)
                or len(json.dumps(e["evidence_details"])) > 65536
            ):
                raise ValueError()
            if e["intent"] not in {"action", "chat", "completed", "reference"}:
                raise ValueError()
            if not re.fullmatch(r"[a-zA-Z0-9_.:/-]+", e["evidence"]):
                raise ValueError()
            if not isinstance(e.get("candidates", []), list) or any(
                not isinstance(c, str) for c in e.get("candidates", [])
            ):
                raise ValueError()
            for field in ("business_at", "observed_at"):
                if (
                    datetime.fromisoformat(e[field].replace("Z", "+00:00")).utcoffset()
                    is None
                ):
                    raise ValueError()
        except (ValueError, TypeError):
            raise ValueError("invalid_projection") from None
        authority = self._grant(e["source"], "ingest", scope=e["scope"])
        if self.authorize_evidence is not None:
            self.authorize_evidence(e, "ingest", None)
        key = identity(e["source"], e["record"], e["version"])
        with self._transaction() as state:
            def admitted(matter):
                if semantic_admission is not None:
                    current = state["producer"]["candidates"][semantic_admission["id"]]
                    current.update(status="admitted", matter=matter["id"])
                    current["understanding"]["status"] = "admitted"
                return matter
            if semantic_admission is not None:
                current = state.get("producer", {}).get("candidates", {}).get(semantic_admission["id"])
                if (self.understanding is None or not self.understanding.admission_current(state, semantic_admission)
                        or current.get("status") != "prepared_semantic" or current.get("admission_receipt") != cursor):
                    raise ValueError("judgment_changed")
            def fingerprint(value):
                return {k: v for k, v in value.items() if k != "observed_at"}

            if key in state["events"]:
                if fingerprint(state["events"][key]["event"]) != fingerprint(e):
                    raise ValueError("version_conflict")
                if (
                    state["coverage"].get(e["source"], {}).get("cursor")
                    == previous_cursor
                ):
                    state["coverage"][e["source"]] = {
                        "cursor": cursor,
                        "status": "success",
                    }
                matter = state["matters"][state["events"][key]["matter"]]
                self._authorize_matter(matter, "display", None)
                return admitted(matter)
            # Held projections never become admitted events, but their immutable
            # source version has the same replay/conflict contract. Read existing
            # review history too, so ledgers from before this fence stay protected.
            held = [review for matter in state["matters"].values()
                    for review in matter.get("association_reviews", [])
                    if identity(review["event"]["source"], review["event"]["record"],
                                review["event"]["version"]) == key]
            for review in held:
                if fingerprint(review["event"]) == fingerprint(e):
                    continue
                controlled = False
                if semantic_admission is not None and review.get("candidate") == current["id"]:
                    old = review["judgment"]
                    controlled = any(h["version"] == old["version"] and h["action"] == old["action"]
                        and h.get("review_actor") in self.understanding.reviewers
                        and h.get("review_reason") in {"association_correction", "missing_evidence_resolved"}
                        for h in current.get("judgment_history", []))
                    controlled = controlled and current["understanding"]["version"] > old["version"]
                    # Control can revise the interpretation, never the source.
                    interpretation = {"goal", "intent", "confirmed", "candidates", "review_required",
                                      "evidence_details", "observed_at"}
                    details = {"admission_receipt", "judgment_version", "recommendation",
                               "result_reference", "goal_reference"}
                    controlled = (controlled
                        and {k: v for k, v in review["event"].items() if k not in interpretation}
                            == {k: v for k, v in e.items() if k not in interpretation}
                        and {k: v for k, v in review["event"].get("evidence_details", {}).items() if k not in details}
                            == {k: v for k, v in e.get("evidence_details", {}).items() if k not in details})
                if not controlled:
                    raise ValueError("version_conflict")
            if state["coverage"].get(e["source"], {}).get("cursor") != previous_cursor:
                raise ValueError("cursor_gap")
            prior = [
                x["event"]
                for x in state["events"].values()
                if x["event"]["source"] == e["source"]
                and x["event"]["record"] == e["record"]
            ]
            if prior and e["sequence"] <= max(x["sequence"] for x in prior):
                if not retain_historical:
                    raise ValueError("stale_revision")
                if any(x["sequence"] == e["sequence"] for x in prior):
                    raise ValueError("version_conflict")
                latest = max(prior, key=lambda item: item["sequence"])
                previous = state["events"][identity(e["source"], e["record"], latest["version"])]
                matter = state["matters"][previous["matter"]]
                self._authorize_matter(matter, "ingest", None)
                matter["evidence"].append(e)
                state["events"][key] = {"matter": matter["id"], "event": e}
                state["coverage"][e["source"]] = {"cursor": cursor, "status": "success"}
                self._authorize_matter(matter, "display", None)
                return admitted(matter)
            certain = (
                e.get("confirmed") is True
                and bool(e.get("goal"))
                and len(e.get("candidates", [])) <= 1
            )
            matter_id = (
                identity(self.workspace, e["scope"], "goal", e["goal"])
                if certain and e["intent"] == "action"
                else identity(self.workspace, e["scope"], e["source"], e["record"])
            )
            if prior:
                latest = max(prior, key=lambda item: item["sequence"])
                previous = state["events"][
                    identity(e["source"], e["record"], latest["version"])
                ]
                matter_id = previous["matter"]
                established = state["matters"][matter_id]
                anchors = [x["goal"] for x in established["evidence"] if x.get("confirmed") is True
                           and x["intent"] == "action" and len(x.get("candidates", [])) <= 1
                           and not x.get("review_required", False)]
                anchor = established.get("confirmed_goal") or (anchors[0] if anchors else None)
                if anchor is not None:
                    established.setdefault("confirmed_goal", anchor)
                if anchor is not None and e["goal"] != anchor:
                    # An unaccepted proposal cannot become the baseline for a
                    # later owner revision. Preserve the canonical event/run and
                    # any unknown original action; retain the proposal separately.
                    review = dict(id=identity(key, e["goal"], e.get("evidence_details", {}).get("judgment_version")),
                                  status="pending", confirmed_goal=anchor, event=deepcopy(e))
                    if semantic_admission is not None:
                        current = state["producer"]["candidates"][semantic_admission["id"]]
                        review.update(candidate=current["id"], judgment=deepcopy(current["understanding"]))
                        current.update(status="needs_review", reason="cross_matter_rebinding_requires_review")
                        current["understanding"].update(status="needs_review", reason="cross_matter_rebinding_requires_review")
                    history = established.setdefault("association_reviews", [])
                    if not any(r["id"] == review["id"] for r in history):
                        history.append(review)
                    established.update(status="needs_review", review_required=True)
                    # This is a held-admission receipt, not a projection of all
                    # sources on the existing matter under the incoming grant.
                    return {"id": matter_id, "status": "needs_review", "admission_held": True}
            for action in state["outbox"].values():
                if action["matter"] == matter_id and action["status"] in {
                    "pending",
                    "sent",
                    "delivery_unknown",
                }:
                    action["status"] = "superseded"
            matter = state["matters"].setdefault(
                matter_id, {"id": matter_id, "evidence": [], "authorities": {}}
            )
            plan = state.get("wake_plans", {}).get(matter_id)
            if plan and plan["status"] not in {"invalidated", "closed"}:
                plan.update(status="invalidated", invalidated_reason="new_evidence")
            if "result" in matter:
                matter.setdefault("result_history", []).append(matter.pop("result"))
            matter.pop("assistant", None)
            if matter["evidence"]:
                self._authorize_matter(matter, "ingest", None)
            matter["authorities"][e["source"]] = authority
            latest_evidence = {}
            for evidence in [*matter["evidence"], e]:
                record = (evidence["source"], evidence["record"])
                if record not in latest_evidence or evidence["sequence"] > latest_evidence[record]["sequence"]:
                    latest_evidence[record] = evidence
            review_required = any(x.get("review_required", False) for x in latest_evidence.values())
            status = "awaiting_main" if certain and not review_required else "needs_review"
            if e["intent"] != "action":
                status = "recorded"
            matter.update(
                status=status,
                payment_status="unverified",
                event=e,
                revision=key,
                mode="observe",
                association="confirmed_goal" if certain else "ambiguous",
                review_required=review_required,
                current_run_id=identity(matter_id, key, "evidence"),
            )
            if certain and e["intent"] == "action" and not review_required:
                matter.setdefault("confirmed_goal", e["goal"])
            matter["evidence"].append(e)
            fingerprint = sha256(
                json.dumps(
                    {k: v for k, v in e.items() if k != "observed_at"}, sort_keys=True
                ).encode()
            ).hexdigest()
            state["events"][key] = {
                "matter": matter_id,
                "event": e,
                "fingerprint": fingerprint,
            }
            state["coverage"][e["source"]] = {"cursor": cursor, "status": "success"}
            if status == "awaiting_main":
                action_id = action_identity(matter_id, key, "main")
                state["outbox"][action_id] = {
                    "id": action_id,
                    "matter": matter_id,
                    "revision": key,
                    "agent": self.coordinator,
                    "stage": "main",
                    "status": "pending",
                    "run_id": matter["current_run_id"],
                    "trigger": {"kind": "evidence", "revision": key},
                }
            self._authorize_matter(matter, "display", None)
            return admitted(matter)
