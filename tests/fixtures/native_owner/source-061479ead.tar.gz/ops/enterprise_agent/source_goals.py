"""Fixed owner-configured goal catalogs; source grants never imply cross-source goals."""
import re


def observation_goal_id(source, scope):
    from .workflow import identity
    return 'observation:' + identity(source, scope)


def is_observation_goal(goal, source, scope):
    return (goal.get('observation_source') == dict(source=source, scope=scope)
            and goal.get('id') == observation_goal_id(source, scope)
            and goal.get('kind') == 'research' and goal.get('status') == 'OPEN'
            and 'gd_code' not in goal and not goal.get('allow_new', False))

def catalog_identity(goals, goal_scopes=None):
    from .workflow import identity
    return identity(goals) if goal_scopes is None else identity(goals, goal_scopes)


def validate_goal_scopes(goals, goal_scopes):
    if goal_scopes is None:
        return None
    if not isinstance(goal_scopes, list) or not 1 <= len(goal_scopes) <= 20:
        raise ValueError("invalid_source_goal_catalog")
    by_id = {g["id"]: g for g in goals}
    scopes = {}
    for item in goal_scopes:
        if (not isinstance(item, dict) or set(item) != {"source", "scope", "goal_ids", "require_gd"}
                or any(not isinstance(item[k], str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,200}", item[k])
                       for k in ("source", "scope"))
                or type(item["require_gd"]) is not bool
                or not isinstance(item["goal_ids"], list) or len(item["goal_ids"]) > 100
                or any(not isinstance(value, str) or value not in by_id for value in item["goal_ids"])
                or len(set(item["goal_ids"])) != len(item["goal_ids"])):
            raise ValueError("invalid_source_goal_catalog")
        key = (item["source"], item["scope"])
        if key in scopes or any(("gd_code" in by_id[value]) != item["require_gd"] for value in item["goal_ids"]):
            raise ValueError("invalid_source_goal_catalog")
        if any('observation_source' in by_id[value]
               and not is_observation_goal(by_id[value], *key) for value in item['goal_ids']):
            raise ValueError('invalid_source_goal_catalog')
        scopes[key] = item
    return scopes


def source_goals(goals, goal_scopes, source, scope):
    scopes = validate_goal_scopes(goals, goal_scopes)
    if scopes is None:
        return goals
    binding = scopes.get((source, scope))
    if binding is None:
        raise ValueError("source_goal_scope_unavailable")
    allowed = set(binding["goal_ids"])
    return [goal for goal in goals if goal["id"] in allowed]


def require_verified_binding(state):
    migration = state.get("binding_migration")
    if migration is not None and migration.get("phase") != "VERIFIED":
        raise ValueError("binding_migration_incomplete")
