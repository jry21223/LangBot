"""Public source-store invariants; synthetic messages and no live account."""
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from enterprise_agent.wechat_native_store import NativeWechatStore

NOW = '2026-11-08T03:00:00Z'


def message(kind='image'):
    return dict(account_id='account-a', thread_id='thread-a', message_id='message-1', sender_id='sender-a',
                server_id='server-1', message_type=kind, direction='incoming', native_version='raw-v1',
                body='hello' if kind == 'text' else '<native metadata>', recalled=False, business_at=NOW,
                media=[] if kind == 'text' else [dict(asset_id='asset-a', kind=kind, state='available',
                    sha256='a' * 64, byte_length=12, content_type='image/png')])


def store(path):
    return NativeWechatStore(path, account='account-a', thread='thread-a', source='personal',
                             scope='test-thread', parser_version='native-parser-v1')


def test_materialization_publishes_new_immutable_reference_without_moving_raw_cursor(tmp_path):
    source = store(tmp_path / 'source.sqlite')
    first = source.commit_native(message(), event_cursor='901', observed_at=NOW)
    assert first['qualification'] == 'media_materialization_required'
    assert first['dispatch_eligible'] is False
    reference, version = first['change']['original'], first['change']['version']
    pending = source.materialization_records(parser_version='native-parser-v1')['items'][0]
    receipt = source.save_materialization(reference, version, pending['input_hash'], 'native-parser-v1',
        'COMPLETE', '图片中的报价', [dict(path='$.image', type='image', text='图片中的报价')], [],
        {'asset-a': 'a' * 64}, 'extract-operation-1')
    assert receipt['version'] != version
    assert receipt['reference'] != reference
    assert receipt['source_sequence'] > first['change']['sequence']
    assert source.snapshot(receipt['reference'], receipt['version'])['event_cursor'] == '901'
    assert source.read_derived(receipt['reference'], receipt['version'], 'native-parser-v1')['content_text'] == '图片中的报价'
    page = source.changes()
    assert len(page['items']) == 2
    assert page['items'][1]['change']['kind'] == 'attachments_changed'
    assert page['items'][1]['dispatch_eligible'] is True
    again = source.save_materialization(reference, version, pending['input_hash'], 'native-parser-v1',
        'COMPLETE', '图片中的报价', [dict(path='$.image', type='image', text='图片中的报价')], [],
        {'asset-a': 'a' * 64}, 'extract-operation-1')
    assert again == receipt
    assert len(source.changes()['items']) == 2
    source.close()


def test_unknown_identity_stays_unknown_and_cannot_dispatch(tmp_path):
    source = store(tmp_path / 'source.sqlite')
    unknown = message('text')
    unknown['sender_id'] = unknown['server_id'] = None
    item = source.commit_native(unknown, event_cursor='902', observed_at=NOW)
    assert item['change']['saved']['sender_id'] is None
    assert item['dispatch_eligible'] is False
    assert item['qualification'] == 'unknown_identity'


def test_unresolved_is_persistent_metadata_not_a_fabricated_message(tmp_path):
    source = store(tmp_path / 'source.sqlite')
    first = source.commit_unresolved('gap-a', '903')
    assert set(first) == {'event_id','kind','source_sequence','event_cursor','reason','source','scope'}
    assert first['kind'] == 'unresolved' and 'change' not in first
    assert source.commit_unresolved('gap-a', '903') == first
    assert len(source.changes()['items']) == 1


def test_scoped_message_and_assets_rejected_without_publishing(tmp_path):
    source = store(tmp_path / 'source.sqlite')
    for altered in [dict(message(), thread_id='other'), dict(message(), account_id='other')]:
        with pytest.raises(ValueError):
            source.commit_native(altered, event_cursor='1', observed_at=NOW)
    invalid = message()
    invalid['media'][0]['sha256'] = ''
    with pytest.raises(ValueError):
        source.commit_native(invalid, event_cursor='1', observed_at=NOW)
    assert source.changes()['items'] == []


def test_recall_invalidates_original_and_blocks_late_materialization(tmp_path):
    source = store(tmp_path / 'source.sqlite')
    first = source.commit_native(message(), event_cursor='904', observed_at=NOW)
    pending = source.materialization_records(parser_version='native-parser-v1')['items'][0]
    recalled = message()
    recalled.update(recalled=True, native_version='raw-recalled')
    second = source.commit_native(recalled, event_cursor='905', observed_at=NOW)
    assert second['change']['kind'] == 'recalled'
    assert second['dispatch_eligible'] is False
    assert source.descriptor(first['change']['original'], first['change']['version'], include_history=True)['original_available'] is False
    with pytest.raises(ValueError):
        source.snapshot(first['change']['original'], first['change']['version'])
    with pytest.raises(ValueError):
        source.save_materialization(first['change']['original'], first['change']['version'], pending['input_hash'],
            'native-parser-v1','COMPLETE','late',[],[],{'asset-a':'a'*64},'late-op')
    with pytest.raises(ValueError):
        source.commit_native(message(), event_cursor='906', observed_at=NOW)


def test_partial_can_progress_to_complete_without_mutating_previous_version(tmp_path):
    source = store(tmp_path / 'source.sqlite')
    initial = source.commit_native(message(), event_cursor='907', observed_at=NOW)
    pending = source.materialization_records(parser_version='native-parser-v1')['items'][0]
    partial = source.save_materialization(initial['change']['original'], initial['change']['version'],pending['input_hash'],
        'native-parser-v1','PARTIAL','prefix',[{'text':'prefix'}],[{'code':'INCOMPLETE'}],{'asset-a':'a'*64},'partial-op')
    complete = source.save_materialization(partial['reference'],partial['version'],pending['input_hash'],
        'native-parser-v1','COMPLETE','full',[{'text':'full'}],[],{'asset-a':'a'*64},'complete-op')
    assert complete['version'] != partial['version']
    assert source.snapshot(partial['reference'],partial['version'],include_history=True)['status']=='PARTIAL'
    assert source.read_derived(complete['reference'],complete['version'],'native-parser-v1')['status']=='COMPLETE'
    with pytest.raises(ValueError):
        source.save_materialization(complete['reference'],complete['version'],pending['input_hash'],
            'native-parser-v1','COMPLETE','different',[],[],{'asset-a':'a'*64},'different-op')


def test_legacy_sequence_requires_an_explicit_nonreset_floor(tmp_path):
    import sqlite3
    path = tmp_path / 'legacy.sqlite'
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE messages(seq INTEGER PRIMARY KEY, body TEXT)')
        db.execute("INSERT INTO messages VALUES(55,'legacy private body')")
    with pytest.raises(ValueError, match='native_source_migration_required'):
        store(path)
    source = NativeWechatStore(path,account='account-a',thread='thread-a',source='personal',scope='test-thread',
                              parser_version='native-parser-v1',sequence_floor=55)
    item = source.commit_native(message('text'),event_cursor='200',observed_at=NOW,baseline=True)
    assert item['change']['sequence'] == 56
    assert item['change']['kind'] == 'baseline' and item['dispatch_eligible'] is False
    source.close()
    with sqlite3.connect(path) as db:
        assert db.execute('SELECT body FROM messages WHERE seq=55').fetchone()[0]=='legacy private body'


def test_pending_media_preserves_unknown_integrity_facts(tmp_path):
    source = store(tmp_path / 'source.sqlite')
    pending = message()
    pending['media'][0].update(state='pending',sha256=None,byte_length=None,content_type=None)
    item=source.commit_native(pending,event_cursor='908',observed_at=NOW)
    assert item['media'][0]['sha256'] is None
    assert item['qualification']=='media_pending' and item['dispatch_eligible'] is False


def test_parser_pin_transition_changes_owner_reference_and_stales_old_results(tmp_path):
    source=store(tmp_path/'source.sqlite')
    item=source.commit_native(message(),event_cursor='909',observed_at=NOW)
    source.set_parser_version('native-parser-v2',observed_at=NOW)
    latest=source.changes()['items'][-1]
    assert latest['change']['version']!=item['change']['version']
    assert latest['native_version']=='raw-v1' and latest['event_cursor']=='909'
    with pytest.raises(ValueError):
        source.materialization_records(parser_version='native-parser-v1')


def test_media_hash_and_operation_conflicts_never_publish_result(tmp_path):
    source=store(tmp_path/'source.sqlite')
    first=source.commit_native(message(),event_cursor='910',observed_at=NOW)
    row=source.materialization_records(parser_version='native-parser-v1')['items'][0]
    args=[first['change']['original'],first['change']['version'],row['input_hash'],'native-parser-v1',
          'COMPLETE','answer',[{'text':'answer'}],[],{'asset-a':'wrong'},'extract-op']
    with pytest.raises(ValueError,match='native_media_integrity_failed'):
        source.save_materialization(*args)
    assert len(source.changes()['items'])==1
    args[-2]={'asset-a':'a'*64}
    receipt=source.save_materialization(*args)
    args[5]='different answer'
    with pytest.raises(ValueError,match='native_operation_conflict'):
        source.save_materialization(*args)
    assert len(source.changes()['items'])==2
    assert source.read_derived(receipt['reference'],receipt['version'],'native-parser-v1')['content_text']=='answer'


def test_restart_preserves_cursor_receipts_and_ordered_parts(tmp_path):
    path=tmp_path/'source.sqlite'
    source=store(path)
    first=source.commit_native(message(),event_cursor='911',observed_at=NOW)
    row=source.materialization_records(parser_version='native-parser-v1')['items'][0]
    parts=[{'text':'first','from':'sender-a','msgtime':100},{'text':'second','from':'sender-b','msgtime':101}]
    args=[first['change']['original'],first['change']['version'],row['input_hash'],'native-parser-v1',
          'COMPLETE','first\nsecond',parts,[],{'asset-a':'a'*64},'restart-op']
    receipt=source.save_materialization(*args)
    cursor=source.changes()['next_cursor']
    source.close()
    source=store(path)
    assert source.save_materialization(*args)==receipt
    assert source.changes()['next_cursor']==cursor
    assert source.read_derived(receipt['reference'],receipt['version'],'native-parser-v1')['parts']==parts
    assert source.changes(cursor)['items']==[]


def test_native_record_reuses_parser_engine_without_any_finance_identity(tmp_path):
    from hashlib import sha256
    import importlib.util
    parser_path=Path(__file__).resolve().parents[2]/'zimu/wecom-archive-parser/archive_parser/parser.py'
    spec=importlib.util.spec_from_file_location('native_record_parser',parser_path)
    parser=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    source=store(tmp_path/'source.sqlite')
    raw=b'synthetic image bytes'
    native=message()
    native['media'][0].update(sha256=sha256(raw).hexdigest(),byte_length=len(raw))
    source.commit_native(native,event_cursor='912',observed_at=NOW)
    record=source.materialization_records(parser_version='native-parser-v1')['items'][0]
    class Extractor:
        def extract(self,kind,content,filename):
            assert kind=='image' and content==raw
            return {'text':'synthetic readable image','engine':'synthetic-test'}
    result=parser.parse_record(record,lambda asset: raw,Extractor())
    assert result['status']=='COMPLETE'
    assert result['content_text']=='synthetic readable image'
    assert 'corp_id' not in record and 'employee_id' not in record


def test_lost_operation_receipt_can_be_looked_up_after_recall_without_old_body(tmp_path):
    source=store(tmp_path/'source.sqlite')
    first=source.commit_native(message(),event_cursor='913',observed_at=NOW)
    row=source.materialization_records(parser_version='native-parser-v1')['items'][0]
    receipt=source.save_materialization(first['change']['original'],first['change']['version'],row['input_hash'],
        'native-parser-v1','COMPLETE','readable',[],[],{'asset-a':'a'*64},'lookup-op')
    recalled=message()
    recalled.update(recalled=True,native_version='recalled-v2')
    source.commit_native(recalled,event_cursor='914',observed_at=NOW)
    assert source.lookup_operation('lookup-op')==receipt
    assert source.lookup_operation('unknown-op') is None
    with pytest.raises(ValueError):
        source.read_derived(receipt['reference'],receipt['version'],'native-parser-v1')


def test_absent_native_body_is_not_fabricated_as_empty_text(tmp_path):
    source=store(tmp_path/'source.sqlite')
    native=message('text')
    native['body']=None
    item=source.commit_native(native,event_cursor='915',observed_at=NOW)
    snapshot=source.snapshot(item['change']['original'],item['change']['version'])
    assert snapshot['body'] is None and snapshot['body_hash'] is None
    assert item['dispatch_eligible'] is False


def test_observer_cursor_cas_and_exact_scoped_indexes_survive_restart(tmp_path):
    path=tmp_path/'source.sqlite'
    source=store(path)
    assert source.observer_cursor()=='0'
    source.commit_native(message(),event_cursor='916',observed_at=NOW)
    source.advance_observer_cursor('0','916')
    with pytest.raises(ValueError):
        source.advance_observer_cursor('0','917')
    with pytest.raises(ValueError):
        source.advance_observer_cursor('916','900')
    assert source.find_message_by_asset('asset-a')=='message-1'
    assert source.snapshot_by_message('message-1')['baseline'] is False
    assert source.snapshot_by_message('unknown-message') is None
    assert source.find_message_by_asset('unknown') is None
    assert source.find_message_by_server_id('server-1')=='message-1'
    duplicate=message()
    duplicate['message_id']='message-2'
    source.commit_native(duplicate,event_cursor='917',observed_at=NOW)
    assert source.find_message_by_asset('asset-a') is None
    assert source.find_message_by_server_id('server-1') is None
    source.close()
    source=store(path)
    assert source.observer_cursor()=='916'


def test_unavailable_media_can_record_partial_without_claiming_content_ready(tmp_path):
    source=store(tmp_path/'source.sqlite')
    native=message()
    native['media'][0].update(state='pending',sha256=None,byte_length=None,content_type=None)
    first=source.commit_native(native,event_cursor='918',observed_at=NOW)
    record=source.materialization_records(parser_version='native-parser-v1')['items'][0]
    receipt=source.save_materialization(first['change']['original'],first['change']['version'],record['input_hash'],
        'native-parser-v1','PARTIAL','',[],[{'code':'MEDIA_NOT_AVAILABLE'}],{'asset-a':None},'pending-partial')
    derived=source.read_derived(receipt['reference'],receipt['version'],'native-parser-v1')
    assert derived['status']=='PARTIAL'
    assert source.descriptor(receipt['reference'],receipt['version'])['original_available'] is False


def test_reviewed_native_floor_does_not_follow_later_legacy_capture_domain(tmp_path):
    import sqlite3
    path=tmp_path/'source.sqlite'
    with sqlite3.connect(path) as db:
        db.execute('CREATE TABLE messages(seq INTEGER PRIMARY KEY, body TEXT)')
        db.execute("INSERT INTO messages VALUES(10,'old')")
    kwargs=dict(account='account-a',thread='thread-a',source='personal',scope='test-thread',
                parser_version='native-parser-v1',sequence_floor=10)
    source=NativeWechatStore(path,**kwargs)
    first=source.commit_native(message('text'),event_cursor='100',observed_at=NOW)
    source.close()
    with sqlite3.connect(path) as db:
        db.execute("INSERT INTO messages VALUES(200,'later legacy capture')")
    source=NativeWechatStore(path,**kwargs)
    assert source.changes()['items'][0]==first
    assert source.changes()['next_cursor']=='11'


def test_profile_generation_is_provenance_not_message_semantic_revision(tmp_path):
    source=store(tmp_path/'source.sqlite')
    first_message=message('text')
    first=source.commit_native(first_message,event_cursor='1000',observed_at=NOW)
    generation_only=message('text')
    generation_only['native_version']='reader-generation-g2'
    assert source.input_hash(generation_only)==source.input_hash(first_message)
    again=source.commit_native(generation_only,event_cursor='1001',observed_at=NOW)
    assert again==first
    assert len(source.changes()['items'])==1
    snapshot=source.snapshot(first['change']['original'],first['change']['version'])
    assert snapshot['native_version']=='raw-v1' and snapshot['event_cursor']=='1000'
    body_changed=dict(generation_only,body='actual edited text')
    changed=source.commit_native(body_changed,event_cursor='1002',observed_at=NOW)
    assert changed['change']['version']!=first['change']['version']
    assert changed['change']['sequence']>first['change']['sequence']
    assert changed['change']['kind']=='changed'
    with pytest.raises(ValueError):
        source.snapshot(first['change']['original'],first['change']['version'])


def test_media_change_uses_media_facts_not_profile_generation_for_kind(tmp_path):
    source=store(tmp_path/'source.sqlite')
    first=source.commit_native(message(),event_cursor='1003',observed_at=NOW)
    edited=message()
    edited['native_version']='reader-generation-g3'
    edited['media'][0]['sha256']='b'*64
    second=source.commit_native(edited,event_cursor='1004',observed_at=NOW)
    assert second['change']['kind']=='attachments_changed'
    assert second['change']['version']!=first['change']['version']


def test_unknown_time_is_private_unqualified_index_not_a_business_change(tmp_path):
    source=store(tmp_path/'source.sqlite')
    raw=message('text')
    raw.update(direction=None,business_at=None)
    item=source.commit_native(raw,event_cursor='1100',observed_at=NOW)
    assert item['kind']=='unresolved' and 'change' not in item
    snapshot=source.snapshot_by_message('message-1')
    assert snapshot['business_at'] is None and snapshot['direction'] is None
    assert snapshot['reference'] is None and snapshot['version'] is None
    assert snapshot['status']=='UNQUALIFIED' and snapshot['baseline'] is False
    assert source.find_message_by_server_id('server-1')=='message-1'
    assert source.commit_native(raw,event_cursor='1100',observed_at='2026-11-08T04:00:00Z')==item
    assert len(source.changes()['items'])==1
    raw.update(direction='incoming',business_at=NOW)
    qualified=source.commit_native(raw,event_cursor='1101',observed_at=NOW)
    assert qualified['change']['business_at']==NOW
    assert qualified['dispatch_eligible'] is True


def test_known_nullable_recall_uses_original_proven_time_and_never_restores_body(tmp_path):
    source=store(tmp_path/'source.sqlite')
    initial=source.commit_native(message('text'),event_cursor='1102',observed_at=NOW)
    raw=message('text')
    raw.update(direction=None,business_at=None,sender_id=None,recalled=True)
    recall=source.commit_native(raw,event_cursor='1103',observed_at='2026-11-08T04:00:00Z')
    assert recall['change']['kind']=='recalled'
    assert recall['change']['business_at']==NOW
    snapshot=source.snapshot(recall['change']['original'],recall['change']['version'])
    assert snapshot['business_at'] is None and snapshot['direction'] is None
    assert snapshot['source_business_at']==NOW
    assert recall['dispatch_eligible'] is False
    assert source.commit_native(raw,event_cursor='1103',observed_at='2026-11-08T05:00:00Z')==recall
    assert len(source.changes()['items'])==2
    with pytest.raises(ValueError,match='native_recall_terminal'):
        source.commit_native(message('text'),event_cursor='1104',observed_at=NOW)
    assert source.descriptor(initial['change']['original'],initial['change']['version'],include_history=True)['original_available'] is False


@pytest.mark.parametrize('transition', ['text', 'derived', 'recall'])
def test_replayed_frames_and_gaps_are_immutable_after_owner_transition(tmp_path, transition):
    from enterprise_agent.wechat_native_store import canonical, digest

    source = store(tmp_path / 'source.sqlite')
    raw = message('image' if transition == 'derived' else 'text')
    first = source.commit_native(raw, event_cursor='1', observed_at=NOW)
    reference, version = first['change']['original'], first['change']['version']
    replay_cursor = '0'
    if transition == 'derived':
        snapshot = source.snapshot(reference, version)
        receipt = source.save_materialization(reference, version, snapshot['input_hash'], 'native-parser-v1',
            'COMPLETE', 'parsed image', [], [], {'asset-a': 'a' * 64}, 'immutable-derived')
        reference, version = receipt['reference'], receipt['version']
        replay_cursor = str(first['change']['sequence'])
    before = source.changes(cursor=replay_cursor, limit=1)
    frame_bytes = canonical(before['items'][0])
    if transition == 'derived':
        source.set_parser_version('native-parser-v2', observed_at=NOW)
    else:
        raw.update(body='updated text', native_version='generation-2')
        if transition == 'recall':
            raw['recalled'] = True
        source.commit_native(raw, event_cursor='2', observed_at=NOW)
    after = source.changes(cursor=replay_cursor, limit=1)
    assert canonical(after['items'][0]) == frame_bytes
    assert after['gaps'] == before['gaps']
    assert after['next_cursor'] == before['next_cursor']
    change = dict(after['items'][0]['change'])
    projection_hash = change.pop('projection_hash')
    assert digest(change) == projection_hash
    with pytest.raises(ValueError, match='native_original_stale'):
        source.snapshot(reference, version)
    assert source.descriptor(reference, version, include_history=True)['original_available'] is False
    source.close()


def test_generation_observation_does_not_mutate_persisted_feed_frame(tmp_path):
    from enterprise_agent.wechat_native_store import canonical

    source = store(tmp_path / 'source.sqlite')
    raw = message('text')
    source.commit_native(raw, event_cursor='1', observed_at=NOW)
    before = canonical(source.changes(cursor='0', limit=1))
    raw['native_version'] = 'generation-2'
    source.commit_native(raw, event_cursor='2', observed_at='2026-11-08T04:00:00Z')
    assert canonical(source.changes(cursor='0', limit=1)) == before
    source.close()
