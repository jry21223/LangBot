"""Approved source → exact GD admission → native read-only result (#1389)."""
from contextlib import contextmanager
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
import time
from threading import Thread
from urllib.parse import parse_qs, urlsplit
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from enterprise_agent.workflow import Workflow
from test_enterprise_agent_1324 import Workspace, response, event

APPROVED_OWNERS = {(source, "finance-read"): {"fixture-owner"} for source in ("wecom-fixture", "slow")}


def saved_change():
    return {
        "source": "wecom-fixture", "scope": "finance-read", "record": "msg-17",
        "version": "owner-v1", "sequence": 1, "kind": "created",
        "business_at": "2026-11-02T01:00:00Z", "observed_at": "2026-11-02T01:00:01Z",
        "original": "wecom:message/msg-17/owner-v1", "goal_reference": "GD-20261102-0001",
        "projection_hash": "a" * 64,
        "saved": {
            "version": "owner-v1", "sequence": 1,
            "observed_at": "2026-11-02T01:00:01Z",
            "original": "wecom:message/msg-17/owner-v1", "attachments": [],
            "message": {
                "source_seq": 17, "message_id": "msg-17", "chat_id": "approved-chat",
                "chat_type": "group", "sender_user_id": "known-employee",
                "sender_identity_type": "EMPLOYEE", "sender_access_type": "INTERNAL",
                "message_type": "text", "sent_at": "2026-11-02T01:00:00Z", "action": "send",
            },
        },
    }


@contextmanager
def owner_server(*, source_name="wecom-fixture"):
    calls = []
    change = saved_change()
    change["source"] = source_name
    state = {"active": True, "changes": [change]}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def send_json(self, value, code=200):
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Mcp-Session-Id", "fixture-session")
            self.end_headers()
            raw = json.dumps(value).encode()
            slow = ((state.get("slow_changes") and self.path.startswith("/source/changes"))
                    or (state.get("slow_mcp") and "content" in value.get("result", {})))
            try:
                if "content" in value.get("result", {}) and state.get("mcp_delay"):
                    time.sleep(state["mcp_delay"])
                if slow:
                    for offset in range(0, len(raw), 8):
                        self.wfile.write(raw[offset:offset + 8])
                        self.wfile.flush()
                        time.sleep(0.02)
                else:
                    self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            assert self.headers["Authorization"] == "Bearer source-fixture-token"
            assert self.headers["X-Operator"] == "fixture-source-reader"
            query = parse_qs(urlsplit(self.path).query)
            if self.path.startswith("/source/authority"):
                if query.get("stage", [None])[0] in {"dispatch", "result"} and "agent" not in query:
                    self.send_json({"error": "explicit_agent_required"}, 403)
                    return
                if query.get("agent", [None])[0] in state.get("denied_agents", []):
                    self.send_json({"error": "denied"}, 403)
                    return
                reference = query.get("reference", [None])[0]
                if reference and "current_references" in state and reference not in state["current_references"]:
                    self.send_json({"error": "unavailable"}, 403)
                    return
                state["authority_calls"] = state.get("authority_calls", 0) + 1
                if query.get("stage") == ["ingest"] and state["authority_calls"] >= state.get("deny_ingest_from", float("inf")):
                    self.send_json({"error": "denied"}, 403)
                    return
                self.send_json(dict(
                    active=state["active"], source=source_name, scope="finance-read",
                    principal="fixture-source-reader", revision="grant-v1", read_only=True,
                    workspace_allowed=True, workspace=state.get("grant_workspace", "test-workspace"),
                    agent=query.get("agent", [None])[0],
                ))
                return
            if "changes_started" in state:
                state["changes_started"].set()
                state["release_changes"].wait(5)
            cursor = query.get("cursor", [None])[0]
            self.send_json(dict(
                source=source_name, scope="finance-read", complete_page=True,
                previous_cursor=cursor, next_cursor=state.get("cursor", "page-1"), gaps=[], coverage="success",
                items=deepcopy(state["changes"]) if cursor != state.get("cursor", "page-1") else [],
            ))

        def do_POST(self):
            assert self.headers["Authorization"] == "Bearer readonly-mcp-token-0123456789abcdef"
            frame = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            if frame["method"] == "notifications/initialized":
                self.send_json({})
            elif frame["method"] == "initialize":
                self.send_json({"jsonrpc": "2.0", "id": frame["id"], "result": {}})
            else:
                name, args = frame["params"]["name"], frame["params"]["arguments"]
                calls.append((name, args))
                assert name == "get_work_item_detail"
                self.send_json({"jsonrpc": "2.0", "id": frame["id"], "result": {
                    "content": [{"type": "text", "text": json.dumps(state.get("target_detail") or {
                        "id": state.get("target_id", 42), "code": state.get("target_code", args["code"]), "status": "OPEN", "edit_version": state.get("target_edit_version", "3" * 64),
                        "assignees": [{"assignee_user_id": owner} for owner in state.get("target_owners", ["fixture-owner"])],
                    })}], "isError": False,
                }})

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield "http://127.0.0.1:" + str(server.server_port), calls, state
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


class Native(Workspace):
    def __init__(self):
        super().__init__()
        self.returned = []
        self.threads = {}

    def ensure_thread(self, channel, coordinator, assistants):
        self.threads.setdefault(channel, (coordinator, tuple(sorted(assistants))))

    def replies(self, channel, after=None):
        start = int(after or 0)
        return self.returned[start:], str(len(self.returned))


def test_owner_http_event_automatically_admits_exact_goal_and_resumes_original_thread(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host

    with owner_server() as (base, calls, _):
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize, authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="exact-gd-1", model_version="approved-main-v1")
        rule = ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"), version="exact-gd-1", allowed_owners=APPROVED_OWNERS)
        native = Native()
        host = Host(producer, sources=[source], workspace=native, admit=rule)
        host.step(now="2026-11-02T01:00:02Z")
        assert calls == [("get_work_item_detail", {"code": "GD-20261102-0001"})]
        assert producer.coverage("wecom-fixture")["cursor"] == "page-1"
        assert len(producer.candidates()) == 1
        assert producer.candidates()[0]["status"] == "admitted"
        assert app.matters()[0]["event"]["goal"] == "gd:42"
        main = app.actions()[0]
        native.returned.append(response(main, '{"decision":"delegate","assistant":"finance-assistant"}'))
        host.step(now="2026-11-02T01:00:03Z")
        assistant = app.actions()[-1]
        native.returned.append(response(assistant, "Read-only: waiting for the tasting result."))
        host.step(now="2026-11-02T01:00:04Z")
        matter = app.matters()[0]
        assert matter["status"] == "read_only_result"
        assert matter["payment_status"] == "unverified"
        assert len(native.events) == 2
        app.close()


def test_readonly_mcp_body_has_an_absolute_deadline_without_leaking_transport_details():
    from enterprise_agent.source_http import ReadOnlyGd
    with owner_server() as (base, calls, state):
        state["slow_mcp"] = True
        reader = ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef", timeout=0.12)
        started = time.monotonic()
        with pytest.raises(ValueError, match="^goal_readback_unavailable$"):
            reader.get("GD-20261102-0001")
        assert time.monotonic() - started < 0.6
        assert len(calls) == 1


def test_host_admission_budget_counts_held_candidates_as_work(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host, Limits
    with owner_server() as (base, calls, state):
        state["changes"] = []
        for index in range(3):
            change = saved_change()
            change["record"] = change["saved"]["message"]["message_id"] = "msg-" + str(index)
            change["goal_reference"] = None
            state["changes"].append(change)
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize, authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="exact-gd-1", model_version="approved-main-v1")
        host = Host(producer, sources=[source], workspace=Native(),
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
                                        version="exact-gd-1", allowed_owners=APPROVED_OWNERS))
        host.step(now="2026-11-02T01:00:02Z", limits=Limits(admissions=1))
        statuses = [c["status"] for c in producer.candidates()]
        assert statuses.count("needs_review") == 1
        assert statuses.count("pending") == 2
        assert producer.coverage("wecom-fixture")["cursor"] == "page-1"
        assert calls == []
        host.step(now="2026-11-02T01:00:03Z", limits=Limits(admissions=1))
        assert [c["status"] for c in producer.candidates()].count("needs_review") == 2
        host.close()
        app.close()


def test_source_total_body_deadline_bounds_slow_drip_not_just_each_socket_read():
    from enterprise_agent.source_http import HttpSource, SourceUnavailable
    with owner_server() as (base, _, state):
        state["slow_changes"] = True
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token", timeout=0.12)
        started = time.monotonic()
        with pytest.raises(SourceUnavailable):
            source.read_changes()
        assert time.monotonic() - started < 0.6


def test_unknown_sender_is_durably_held_without_reading_gd_or_dispatching(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server() as (base, calls, state):
        state["changes"][0]["saved"]["message"]["sender_identity_type"] = "UNKNOWN"
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize, authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="exact-gd-1", model_version="approved-main-v1")
        native = Native()
        host = Host(producer, sources=[source], workspace=native,
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
                                        version="exact-gd-1", allowed_owners=APPROVED_OWNERS))
        host.step(now="2026-11-02T01:00:02Z")
        assert producer.coverage("wecom-fixture")["cursor"] == "page-1"
        assert producer.candidates()[0]["status"] == "needs_review"
        assert calls == []
        assert app.matters() == []
        assert native.events == {}
        host.close()
        app.close()


def test_host_native_dispatch_obeys_action_budget_and_eventually_visits_other_matters(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host, Limits
    with owner_server() as (base, _, state):
        state["changes"] = []
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize, authorize_evidence=source.authorize_evidence)
        for index in range(3):
            app.ingest(event(source="wecom-fixture", record="record-" + str(index), goal="goal:" + str(index)),
                       cursor=str(index), previous_cursor=str(index - 1) if index else None)
        producer = Producer(app, rule_version="exact-gd-1", model_version="approved-main-v1")
        native = Native()
        host = Host(producer, sources=[source], workspace=native,
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
                                        version="exact-gd-1", allowed_owners=APPROVED_OWNERS))
        host.step(now="2026-11-02T01:00:02Z", limits=Limits(actions=1))
        assert len(native.events) == 1
        for _ in range(3):
            host.step(now="2026-11-02T01:00:03Z", limits=Limits(actions=1))
        assert len(native.events) == 3
        host.close()
        app.close()


def test_held_history_does_not_authorize_the_entire_ledger_before_pending_budget(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host, Limits
    with owner_server() as (base, _, state):
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize, authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="exact-gd-1", model_version="approved-main-v1")
        older = []
        for index in range(30):
            change = saved_change()
            change["record"] = change["saved"]["message"]["message_id"] = "older-" + str(index)
            older.append(change)
        producer.prepare("wecom-fixture", dict(source="wecom-fixture", scope="finance-read",
            complete_page=True, previous_cursor=None, next_cursor="older", items=older, gaps=[]))
        for candidate in producer.candidates():
            producer.hold(candidate["id"], "needs_review")
        producer.prepare("wecom-fixture", dict(source="wecom-fixture", scope="finance-read",
            complete_page=True, previous_cursor="older", next_cursor="current", items=[saved_change()], gaps=[]),
            previous_cursor="older")
        state["changes"] = []
        state["authority_calls"] = 0
        host = Host(producer, sources=[source], workspace=Native(),
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
                                        version="exact-gd-1", allowed_owners=APPROVED_OWNERS))
        host.step(now="2026-11-02T01:00:02Z", limits=Limits(admissions=1))
        assert state["authority_calls"] <= 20
        assert app.matters()[0]["event"]["goal"] == "gd:42"
        host.close()
        app.close()


def test_incomplete_owner_page_leaves_no_candidates_or_cursor_and_retains_failure(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server() as (base, _, state):
        broken = saved_change()
        broken["record"] = "broken"
        broken["saved"] = None
        state["changes"].append(broken)
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize, authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="exact-v1", model_version="none")
        host = Host(producer, sources=[source], workspace=Native(),
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
                                        version="exact-v1", allowed_owners=APPROVED_OWNERS))
        try:
            report = host.step(now="2026-11-02T02:00:00Z")
            assert report["sources"] == {"wecom-fixture": "sync_failed"}
            assert producer.candidates() == []
            assert producer.coverage("wecom-fixture").get("cursor") is None
            assert app.matters() == []
        finally:
            host.close()
            app.close()


def test_disabled_host_entry_never_reads_credentials_or_starts_runtime(tmp_path):
    import subprocess
    config = tmp_path / "host.json"
    config.write_text('{"version":1,"enabled":false}')
    config.chmod(0o600)
    result = subprocess.run([sys.executable, "-m", "ops.enterprise_agent.run_host", "--config", str(config)],
                            capture_output=True, text=True, timeout=5)
    assert result.returncode == 0, result.stderr
    assert json.loads(result.stdout) == {"status": "disabled"}
    assert sorted(p.name for p in tmp_path.iterdir()) == ["host.json"]


@pytest.mark.parametrize("wrong", ["code", "owner"])
def test_wrong_exact_target_is_held_without_admission_or_dispatch(tmp_path, wrong):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server() as (base, calls, state):
        state["target_code" if wrong == "code" else "target_owners"] = "GD-OTHER" if wrong == "code" else ["unrelated-owner"]
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize,
                       authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="exact-v1", model_version="none")
        native = Native()
        host = Host(producer, sources=[source], workspace=native,
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
                                        version="exact-v1", allowed_owners=APPROVED_OWNERS))
        try:
            host.step(now="2026-11-02T02:00:00Z")
            assert calls == [("get_work_item_detail", {"code": "GD-20261102-0001"})]
            assert producer.candidates()[0]["reason"] == "goal_readback_unavailable"
            assert app.matters() == []
            assert native.events == {}
        finally:
            host.close()
            app.close()


def test_new_owner_revision_reuses_matter_while_old_result_and_recalled_original_are_fenced(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server() as (base, _, state):
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader",
                            token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize,
                       authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="exact-v1", model_version="none")
        native = Native()
        host = Host(producer, sources=[source], workspace=native,
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
                                        version="exact-v1", allowed_owners=APPROVED_OWNERS))
        try:
            host.step(now="2026-11-02T02:00:00Z")
            original = app.matters()[0]
            first = app.actions()[0]
            updated = saved_change()
            updated.update(version="owner-v2", sequence=2, original="wecom:message/msg-17/owner-v2")
            updated["saved"].update(version="owner-v2", sequence=2, original=updated["original"])
            state.update(cursor="page-2", changes=[updated], current_references=[updated["original"]])
            host.step(now="2026-11-02T02:01:00Z")
            assert app.matters()[0]["id"] == original["id"]
            assert app.matters()[0]["event"]["version"] == "owner-v2"
            assert len(native.events) == 2
            assert not app.receive(response(first, '{"decision":"record"}'))
            latest = app.actions()[-1]
            prompt = json.loads(native.events[latest["id"]]["payload"]["content"])
            assert [e["version"] for e in prompt["evidence"]] == ["owner-v2"]
            state["current_references"] = []
            assert app.available_matters() == []
            with pytest.raises(ValueError):
                app.receive(response(latest, '{"decision":"delegate","assistant":"finance-assistant"}'))
            assert len(native.events) == 2
        finally:
            host.close()
            app.close()


@pytest.mark.parametrize("drip", ["headers", "chunk_framing"])
def test_source_deadline_covers_slow_headers_and_chunk_framing(drip):
    import socket
    from enterprise_agent.source_http import HttpSource, SourceUnavailable
    class Drip(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass
        def do_GET(self):
            wire = (b"HTTP/1.1 200 OK\r\nX-Slow: " + b"x" * 120 + b"\r\n\r\n{}")
            if drip == "chunk_framing":
                self.wfile.write(b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n")
                self.wfile.flush()
                wire = b"00000000000000000000000000000000000000000000000002\r\n{}\r\n0\r\n\r\n"
            try:
                for char in wire:
                    self.wfile.write(bytes([char]))
                    self.wfile.flush()
                    time.sleep(0.015)
            except (BrokenPipeError, ConnectionResetError, socket.timeout):
                pass
    server = ThreadingHTTPServer(("127.0.0.1", 0), Drip)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        source = HttpSource(f"http://127.0.0.1:{server.server_port}", source="wecom-fixture",
                            scope="finance-read", workspace="test-workspace", principal="reader",
                            token="source-fixture-token", timeout=0.12)
        started = time.monotonic()
        with pytest.raises(SourceUnavailable):
            source.read_changes()
        assert time.monotonic() - started < 0.6
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def test_slow_source_cannot_starve_independent_admission_and_native_dispatch(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host, Limits
    with owner_server(source_name="slow") as (slow_base, _, slow_state), owner_server() as (base, _, _):
        slow_state["slow_changes"] = True
        sources = [HttpSource(endpoint + "/source", source=name, scope="finance-read",
                              workspace="test-workspace", principal="fixture-source-reader",
                              token="source-fixture-token") for endpoint, name in
                   [(slow_base, "slow"), (base, "wecom-fixture")]]
        by_source = {s.source: s for s in sources}
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"],
                       authorize=lambda source, stage, agent=None: by_source[source].authorize(source, stage, agent),
                       authorize_evidence=lambda event, stage, agent=None: by_source[event["source"]].authorize_evidence(event, stage, agent))
        producer = Producer(app, rule_version="exact-v1", model_version="none")
        native = Native()
        host = Host(producer, sources=sources, workspace=native,
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
                                        version="exact-v1", allowed_owners=APPROVED_OWNERS))
        try:
            started = time.monotonic()
            report = host.step(now="2026-11-02T02:00:00Z", limits=Limits(seconds=1, admissions=1))
            assert time.monotonic() - started < 1.4
            assert report["sources"] == {"slow": "sync_failed", "wecom-fixture": "success"}
            assert report["admitted"] == 1
            assert len(native.events) == 1
        finally:
            host.close()
            app.close()


def test_prepared_admission_after_restart_rechecks_current_target_access(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server() as (base, _, state):
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader", token="source-fixture-token")
        def open_workflow():
            return Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                            assistants=["finance-assistant"], authorize=source.authorize,
                            authorize_evidence=source.authorize_evidence)
        app = open_workflow()
        producer = Producer(app, rule_version="exact-v1", model_version="none")
        producer.prepare("wecom-fixture", source.read_changes())
        candidate = producer.candidates()[0]
        rule = ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"), version="exact-v1", allowed_owners=APPROVED_OWNERS)
        decision = rule(candidate)
        state.update(authority_calls=0, deny_ingest_from=2)
        with pytest.raises(ValueError):
            producer.admit(candidate["id"], decision)
        assert producer.candidates()[0]["status"] == "prepared"
        app.close()
        del state["deny_ingest_from"]
        state["target_code"] = "GD-OTHER"
        app = open_workflow()
        producer = Producer(app, rule_version="exact-v1", model_version="none")
        native = Native()
        host = Host(producer, sources=[source], workspace=native, admit=rule)
        try:
            report = host.step(now="2026-11-02T02:00:00Z")
            assert report["admitted"] == 0
            assert producer.candidates()[0]["reason"] == "goal_readback_unavailable"
            assert app.matters() == []
            assert native.events == {}
        finally:
            host.close()
            app.close()


def test_one_unshared_configured_assistant_prevents_native_thread_publication(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server() as (base, _, state):
        state["denied_agents"] = ["unshared-assistant"]
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader", token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant", "unshared-assistant"], authorize=source.authorize,
                       authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="exact-v1", model_version="none")
        native = Native()
        host = Host(producer, sources=[source], workspace=native,
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"), version="exact-v1", allowed_owners=APPROVED_OWNERS))
        try:
            host.step(now="2026-11-02T02:00:00Z")
            assert native.events == {}
            assert native.threads == {}
            assert app.matters()[0]["status"] == "awaiting_main"
        finally:
            host.close()
            app.close()


def test_second_process_reports_busy_while_host_is_waiting_on_source_http(tmp_path):
    import subprocess
    from threading import Event
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server() as (base, _, state):
        state.update(changes_started=Event(), release_changes=Event())
        outcomes = []
        def first_executor():
            source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                                workspace="test-workspace", principal="fixture-source-reader", token="source-fixture-token")
            app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                           assistants=["finance-assistant"], authorize=source.authorize)
            host = Host(Producer(app, rule_version="exact-v1", model_version="none"), sources=[source], workspace=Native(),
                        admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"), version="exact-v1", allowed_owners=APPROVED_OWNERS))
            try:
                outcomes.append(host.step(now="2026-11-02T02:00:00Z"))
            finally:
                host.close()
                app.close()
        first = Thread(target=first_executor)
        first.start()
        try:
            assert state["changes_started"].wait(3)
            script = '''import sys,json
from pathlib import Path
sys.path[:0]=[str(Path.cwd()/"ops"),str(Path.cwd()/"ops/tests")]
from enterprise_agent.workflow import Workflow
from enterprise_agent.producer import Producer
from enterprise_agent.source_http import HttpSource
from enterprise_agent.host import Host
from test_enterprise_agent_host_1389 import Native
source=HttpSource(sys.argv[1]+"/source",source="wecom-fixture",scope="finance-read",workspace="test-workspace",principal="fixture-source-reader",token="source-fixture-token")
app=Workflow(sys.argv[2],workspace="test-workspace",coordinator="main-agent",assistants=["finance-assistant"],authorize=source.authorize)
host=Host(Producer(app,rule_version="exact-v1",model_version="none"),sources=[source],workspace=Native(),admit=lambda candidate:None)
try: print(json.dumps(host.step(now="2026-11-02T02:00:00Z")))
finally: host.close();app.close()
'''
            second = subprocess.run([sys.executable, "-c", script, base, str(tmp_path / "state.sqlite")],
                                    capture_output=True, text=True, timeout=5)
            assert second.returncode == 0, second.stderr
            assert json.loads(second.stdout) == {"status": "busy"}
        finally:
            state["release_changes"].set()
            first.join(5)
        assert not first.is_alive()
        assert outcomes[0]["admitted"] == 1


def test_owner_replay_preserves_cursor_and_immutable_conflict_rolls_back_complete_page(tmp_path):
    from enterprise_agent.producer import Producer
    from enterprise_agent.source_http import HttpSource
    with owner_server() as (base, _, _):
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read",
                            workspace="test-workspace", principal="fixture-source-reader", token="source-fixture-token")
        app = Workflow(tmp_path / "state.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize)
        producer = Producer(app, rule_version="exact-v1", model_version="none")
        try:
            page = source.read_changes()
            page["gaps"] = ["history_before_feed_unverified"]
            producer.prepare("wecom-fixture", page)
            replay = deepcopy(page)
            replay["items"][0]["original_available"] = False
            producer.prepare("wecom-fixture", replay)
            assert len(producer.candidates()) == 1
            assert producer.candidates()[0]["change"]["original_available"] is False
            assert producer.coverage("wecom-fixture")["gaps"] == ["history_before_feed_unverified"]
            corrupt = deepcopy(replay)
            new = saved_change()
            new["record"] = new["saved"]["message"]["message_id"] = "new-in-failed-page"
            corrupt["items"].insert(0, new)
            corrupt["items"][1]["goal_reference"] = "GD-OTHER"
            corrupt.update(previous_cursor="page-1", next_cursor="page-2")
            with pytest.raises(ValueError, match="version_conflict"):
                producer.prepare("wecom-fixture", corrupt, previous_cursor="page-1")
            assert len(producer.candidates()) == 1
            assert producer.coverage("wecom-fixture")["cursor"] == "page-1"
        finally:
            app.close()


def test_default_admission_budget_uses_actual_single_slow_candidate(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server() as (base, _, state):
        # A single delayed response exceeds the old 24s/20 candidate allocation.
        # The separate trickle-body test covers absolute transport deadlines;
        # hundreds of scheduler-dependent sleeps would test load, not allocation.
        state.update(mcp_delay=3.0, target_owners=["fixture-owner"] + ["owner-" + str(n) for n in range(20)])
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read", workspace="test-workspace",
                            principal="fixture-source-reader", token="source-fixture-token")
        app = Workflow(tmp_path / "slow.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize, authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="r1", model_version="m1")
        host = Host(producer, sources=[source], workspace=Native(),
                    admit=ExactGoalRule(ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"), version="r1", allowed_owners=APPROVED_OWNERS))
        try:
            host.step(now="2026-11-03T00:00:00Z")
            assert producer.candidates()[0]["status"] == "admitted"
            assert app.matters()[0]["event"]["version"] == "owner-v1"
        finally:
            host.close()
            app.close()


def test_temporary_target_failure_recovers_next_cycle_while_other_source_advances(tmp_path):
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.host import Host
    with owner_server(source_name="slow") as (slow, _, waiting), owner_server() as (fast, _, _):
        waiting["slow_mcp"] = True
        sources = {name: HttpSource(base + "/source", source=name, scope="finance-read", workspace="test-workspace",
            principal="fixture-source-reader", token="source-fixture-token") for name, base in [("slow", slow), ("wecom-fixture", fast)]}
        readers = {name: ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef", timeout=0.1 if name == "slow" else 10)
                   for name, base in [("slow", slow), ("wecom-fixture", fast)]}
        rules = {name: ExactGoalRule(reader, version="r1", allowed_owners=APPROVED_OWNERS) for name, reader in readers.items()}
        class Rules:
            def __call__(self, candidate):
                return rules[candidate["source"]](candidate)
            def requalify(self, candidate, decision):
                return rules[candidate["source"]].requalify(candidate, decision)
        app = Workflow(tmp_path / "recover.sqlite", workspace="test-workspace", coordinator="main-agent",
            assistants=["finance-assistant"], authorize=lambda name, stage, agent=None: sources[name].authorize(name, stage, agent),
            authorize_evidence=lambda e, stage, agent=None: sources[e["source"]].authorize_evidence(e, stage, agent))
        producer = Producer(app, rule_version="r1", model_version="m1")
        host = Host(producer, sources=list(sources.values()), workspace=Native(), admit=Rules())
        try:
            host.step(now="2026-11-03T00:00:00Z")
            first = {c["source"]: c for c in producer.candidates()}
            assert first["slow"]["status"] == "pending"
            assert first["wecom-fixture"]["status"] == "admitted"
            readers["slow"].timeout = 10
            waiting["slow_mcp"] = False
            host.step(now="2026-11-03T00:00:30Z")
            current = {c["source"]: c for c in producer.candidates()}
            assert current["slow"]["status"] == "admitted"
            assert current["slow"]["id"] == first["slow"]["id"]
            assert producer.coverage("slow")["cursor"] == "page-1"
        finally:
            host.close()
            app.close()


def test_exact_goal_conflict_is_held_without_counting_an_admission(tmp_path):
    from enterprise_agent.host import Host
    from enterprise_agent.producer import Producer, ExactGoalRule
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    with owner_server() as (base, _, state):
        source = HttpSource(base + "/source", source="wecom-fixture", scope="finance-read", workspace="test-workspace",
                            principal="fixture-source-reader", token="source-fixture-token")
        app = Workflow(tmp_path / "exact-anchor.sqlite", workspace="test-workspace", coordinator="main-agent",
                       assistants=["finance-assistant"], authorize=source.authorize, authorize_evidence=source.authorize_evidence)
        producer = Producer(app, rule_version="r1", model_version="m1")
        host = Host(producer, sources=[source], workspace=Native(), admit=ExactGoalRule(
            ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"), version="r1", allowed_owners=APPROVED_OWNERS))
        try:
            host.step(now="2026-11-03T00:00:00Z")
            original = app.matters()[0]
            change = deepcopy(state["changes"][0])
            change.update(version="owner-v2", sequence=2, original="wecom:message/msg-17/owner-v2",
                          goal_reference="GD-20261102-0002", projection_hash="b" * 64)
            change["saved"].update(version=change["version"], sequence=2, original=change["original"])
            state.update(changes=[change], cursor="page-2", target_id=43)
            report = host.step(now="2026-11-03T00:00:01Z")
            assert report["admitted"] == 0
            current = next(c for c in producer.candidates() if c["change"]["version"] == "owner-v2")
            assert current["status"] == "needs_review"
            assert app.matters()[0]["event"]["goal"] == "gd:42"
            assert app.matters()[0]["revision"] == original["revision"]
        finally:
            host.close()
            app.close()


@pytest.mark.parametrize("version", [True, 1, "", "3" * 63, "G" * 64])
def test_gd_read_rejects_versions_outside_actual_owner_digest_contract(version):
    from enterprise_agent.source_http import ReadOnlyGd
    with owner_server() as (base, _, state):
        state["target_edit_version"] = version
        reader = ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef")
        with pytest.raises(ValueError, match="^goal_readback_unavailable$"):
            reader.get("GD-20261102-0001")
