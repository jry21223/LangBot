"""Public event→matter→native-agent boundary; no live services or credentials."""

from copy import deepcopy
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from enterprise_agent.workflow import Workflow
from enterprise_agent.openagents import OpenAgents


def event(**changes):
    return {
        "source": "fixture-payments",
        "record": "approval-17",
        "version": "v1",
        "sequence": 1,
        "business_at": "2026-10-30T01:00:00Z",
        "observed_at": "2026-10-30T02:00:00Z",
        "scope": "finance-read",
        "evidence": "archive:payment/17",
        "approval_status": "approved",
        "intent": "action",
        "goal": "internal-sample:17",
        "confirmed": True,
        **changes,
    }


def grant(source, stage, agent=None):
    return {
        "active": True,
        "source": source,
        "scope": "finance-read",
        "principal": "fixture-reader",
        "revision": "binding-1",
        "read_only": True,
        "workspace_allowed": True,
        "agent": agent,
    }


def workflow(tmp_path, **kw):
    options = {
        "workspace": "test-workspace",
        "coordinator": "main-agent",
        "assistants": ["finance-assistant"],
        "authorize": grant,
        **kw,
    }
    return Workflow(tmp_path / "state.sqlite", **options)


def test_new_event_is_durable_and_replay_does_not_create_another_matter(tmp_path):
    app = workflow(tmp_path)
    first = app.ingest(event(), cursor="page-1", previous_cursor=None)
    assert first["status"] == "awaiting_main"
    assert first["payment_status"] == "unverified"
    app.close()
    app = workflow(tmp_path)
    replay = app.ingest(event(), cursor="page-1", previous_cursor=None)
    assert replay["id"] == first["id"]
    assert len(app.matters()) == 1
    assert app.coverage("fixture-payments")["cursor"] == "page-1"
    assert len(app.pending()) == 1


def test_correction_updates_same_goal_and_retains_history_without_replaying_stale_versions(
    tmp_path,
):
    app = workflow(tmp_path)
    first = app.ingest(event(), cursor="1", previous_cursor=None)
    corrected = app.ingest(
        event(version="v2", sequence=2, approval_status="revoked"),
        cursor="2",
        previous_cursor="1",
    )
    assert corrected["id"] == first["id"]
    assert corrected["event"]["approval_status"] == "revoked"
    assert len(corrected["evidence"]) == 2
    assert len(app.pending()) == 1
    app.ingest(event(), cursor="1", previous_cursor=None)
    assert app.matters()[0]["event"]["version"] == "v2"
    with pytest.raises(ValueError, match="version_conflict"):
        app.ingest(event(approval_status="different"), cursor="3", previous_cursor="2")
    with pytest.raises(ValueError, match="stale_revision"):
        app.ingest(event(version="old", sequence=1), cursor="3", previous_cursor="2")
    assert app.coverage("fixture-payments")["cursor"] == "2"


@pytest.mark.parametrize(
    "changes, status",
    [
        ({"confirmed": False}, "needs_review"),
        ({"candidates": ["GD-1", "GD-2"]}, "needs_review"),
        ({"intent": "chat"}, "recorded"),
        ({"intent": "completed"}, "recorded"),
        ({"intent": "reference"}, "recorded"),
    ],
)
def test_uncertain_goals_and_non_actions_are_recorded_without_dispatch(
    tmp_path, changes, status
):
    app = workflow(tmp_path)
    result = app.ingest(event(**changes), cursor="1", previous_cursor=None)
    assert result["status"] == status
    assert app.pending() == []


def test_confirmed_goal_links_sources_but_same_amount_or_names_cannot_merge(tmp_path):
    app = workflow(tmp_path)
    first = app.ingest(event(), cursor="1", previous_cursor=None)
    other = app.ingest(
        event(source="fixture-expenses", record="expense-19"),
        cursor="1",
        previous_cursor=None,
    )
    assert other["id"] == first["id"]
    uncertain = app.ingest(
        event(record="approval-18", confirmed=False), cursor="2", previous_cursor="1"
    )
    assert uncertain["id"] != first["id"]
    assert len(app.matters()) == 2


def test_projection_permissions_gaps_and_empty_success_are_distinct(tmp_path):
    active = {"value": True}

    def authority(source, stage, agent=None):
        return {**grant(source, stage, agent), "active": active["value"]}

    app = Workflow(
        tmp_path / "state.sqlite",
        workspace="test-workspace",
        coordinator="main-agent",
        assistants=["finance-assistant"],
        authorize=authority,
    )
    active["value"] = False
    with pytest.raises(ValueError, match="source_unavailable"):
        app.ingest(event(), cursor="1", previous_cursor=None)
    assert app.matters() == []
    active["value"] = True
    app.ingest(event(), cursor="1", previous_cursor=None)
    with pytest.raises(ValueError, match="cursor_gap"):
        app.ingest(
            event(version="v2", sequence=2), cursor="3", previous_cursor="missing"
        )
    assert app.coverage("fixture-payments")["cursor"] == "1"
    app.record_coverage("fixture-payments", status="credential_expired")
    assert app.coverage("fixture-payments")["status"] == "credential_expired"
    app.record_coverage(
        "fixture-payments", status="success_zero", cursor="2", previous_cursor="1"
    )
    assert app.coverage("fixture-payments")["status"] == "success_zero"
    assert app.coverage("fixture-payments")["cursor"] == "2"
    with pytest.raises(ValueError, match="invalid_projection"):
        app.ingest(event(raw_document="PRIVATE"), cursor="3", previous_cursor="2")


class Workspace:
    """External Workspace API stand-in with durable delivery keys."""

    def __init__(self):
        self.events = {}
        self.drop = False
        self.idempotent = True

    def supports_idempotency(self):
        return self.idempotent

    def ensure_thread(self, channel, coordinator, assistants):
        pass

    def post(self, message):
        key = message["idempotency_key"]
        self.events.setdefault(key, {**deepcopy(message), "id": "remote-" + key})
        if self.drop:
            self.drop = False
            raise TimeoutError("SECRET unavailable")
        return self.events[key]["id"]


def response(action, content, *, status="completed", agent=None):
    return {
        "id": "reply-" + action["id"],
        "source": "openagents:" + (agent or action["agent"]),
        "target": "channel/" + action["matter"],
        "type": "workspace.message.posted",
        "metadata": {"in_reply_to": action["remote_id"], "status_kind": status},
        "payload": {"content": content},
    }


def test_automatic_main_selection_and_assistant_result_are_read_only_and_restart_safe(
    tmp_path,
):
    app = workflow(tmp_path)
    workspace = Workspace()
    matter = app.ingest(event(), cursor="1", previous_cursor=None)
    app.dispatch(workspace)
    main = app.actions()[0]
    main_message = workspace.events[main["id"]]
    assert main_message["metadata"]["target_agents"] == ["main-agent"]
    assert main_message["target"] == "channel/" + matter["id"]
    assert main_message["payload"]["message_type"] == "chat"
    app.receive(
        response(main, '{"decision":"delegate","assistant":"finance-assistant"}')
    )
    app.dispatch(workspace)
    assistant = app.actions()[-1]
    app.close()
    app = workflow(tmp_path)
    app.receive(response(assistant, "审批已通过；实际付款仍待核实。只建议核对原单。"))
    result = app.matters()[0]
    assert result["status"] == "read_only_result"
    assert result["assistant"] == "finance-assistant"
    assert result["payment_status"] == "unverified"
    assert (
        result["result"]["content"] == "审批已通过；实际付款仍待核实。只建议核对原单。"
    )
    assert result["mode"] == "observe"
    app.receive(response(assistant, "审批已通过；实际付款仍待核实。只建议核对原单。"))
    assert app.pending() == []
    assert len(workspace.events) == 2


def test_lost_dispatch_receipt_reuses_identity_and_old_or_forged_replies_cannot_advance(
    tmp_path,
):
    app = workflow(tmp_path)
    workspace = Workspace()
    app.ingest(event(), cursor="1", previous_cursor=None)
    workspace.drop = True
    with pytest.raises(TimeoutError):
        app.dispatch(workspace)
    app.close()
    app = workflow(tmp_path)
    app.dispatch(workspace)
    assert len(workspace.events) == 1
    main = app.actions()[0]
    assert (
        app.receive(response(main, '{"decision":"delegate","assistant":"admin"}'))
        is True
    )
    assert app.matters()[0]["status"] == "needs_review"
    app.ingest(event(version="v2", sequence=2), cursor="2", previous_cursor="1")
    app.dispatch(workspace)
    latest = app.actions()[-1]
    assert app.receive(response(latest, "{}", agent="impostor")) is False
    assert (
        app.receive(
            response(main, '{"decision":"delegate","assistant":"finance-assistant"}')
        )
        is False
    )
    assert app.matters()[0]["status"] == "awaiting_main"
    app.receive(response(latest, "completed", status="error"))
    assert app.matters()[0]["status"] == "execution_failed"
    assert "result" not in app.matters()[0]


def test_missing_idempotency_and_revoked_access_block_dispatch_and_result_readback(
    tmp_path,
):
    enabled = {"value": True}

    def authority(source, stage, agent=None):
        return {**grant(source, stage, agent), "active": enabled["value"]}

    app = Workflow(
        tmp_path / "state.sqlite",
        workspace="test-workspace",
        coordinator="main-agent",
        assistants=["finance-assistant"],
        authorize=authority,
    )
    workspace = Workspace()
    app.ingest(event(), cursor="1", previous_cursor=None)
    workspace.idempotent = False
    with pytest.raises(ValueError, match="idempotent_delivery_required"):
        app.dispatch(workspace)
    assert workspace.events == {}
    workspace.idempotent = True
    app.dispatch(workspace)
    main = app.actions()[0]
    enabled["value"] = False
    with pytest.raises(ValueError, match="source_unavailable"):
        app.receive(
            response(main, '{"decision":"delegate","assistant":"finance-assistant"}')
        )
    with pytest.raises(ValueError, match="source_unavailable"):
        app.matters()


def test_correction_clears_current_result_and_binding_drift_does_not_reuse_old_authority(
    tmp_path,
):
    revision = {"value": "binding-1"}

    def authority(source, stage, agent=None):
        return {**grant(source, stage, agent), "revision": revision["value"]}

    app = Workflow(
        tmp_path / "state.sqlite",
        workspace="test-workspace",
        coordinator="main-agent",
        assistants=["finance-assistant"],
        authorize=authority,
    )
    workspace = Workspace()
    app.ingest(event(), cursor="1", previous_cursor=None)
    app.dispatch(workspace)
    app.receive(
        response(
            app.actions()[0], '{"decision":"delegate","assistant":"finance-assistant"}'
        )
    )
    app.dispatch(workspace)
    app.receive(response(app.actions()[-1], "read-only plan"))
    app.ingest(
        event(version="v2", sequence=2, approval_status="revoked"),
        cursor="2",
        previous_cursor="1",
    )
    assert "result" not in app.matters()[0]
    assert app.matters()[0]["result_history"][0]["content"] == "read-only plan"
    revision["value"] = "binding-2"
    with pytest.raises(ValueError, match="source_unavailable"):
        app.dispatch(workspace)


def test_native_http_tick_dispatches_and_reads_correlated_results(tmp_path):
    import json
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from threading import Thread
    from urllib.parse import urlsplit, parse_qs

    events, channels = [], []

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def do_GET(self):
            if self.path.startswith("/v1/events/delivery-capabilities"):
                data = {"idempotent_messages": True}
            elif self.path.startswith("/v1/discover"):
                data = {"channels": channels}
            else:
                query = parse_qs(urlsplit(self.path).query)
                after = int(query.get("after", ["0"])[0])
                data = {
                    "events": [e for e in events if int(e["id"]) > after],
                    "next_cursor": str(len(events)),
                }
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps({"data": data}).encode())

        def do_POST(self):
            message = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            assert self.headers["X-Workspace-Token"] == "fixture-workspace-token"
            if message["type"] == "network.channel.create":
                channels.append(
                    {
                        "address": message["target"],
                        "created_by": message["source"],
                        "status": "active",
                        "master": message["payload"]["master"],
                        "participants": message["payload"]["participants"],
                    }
                )
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'{"data": {"id": "thread-created"}}')
                return
            from uuid import UUID

            UUID(message["idempotency_key"])
            existing = next(
                (
                    e
                    for e in events
                    if e.get("idempotency_key") == message["idempotency_key"]
                ),
                None,
            )
            if existing is None:
                existing = {**message, "id": str(len(events) + 1)}
                events.append(existing)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(json.dumps({"data": {"id": existing["id"]}}).encode())

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        native = OpenAgents(
            "http://127.0.0.1:" + str(server.server_port),
            "test-workspace",
            "fixture-workspace-token",
        )
        app = workflow(tmp_path)
        matter = app.ingest(event(), cursor="1", previous_cursor=None)
        app.tick(native)
        main = app.actions()[0]
        events.append(
            {
                **response(
                    main, '{"decision":"delegate","assistant":"finance-assistant"}'
                ),
                "id": "2",
            }
        )
        app.tick(native)
        assistant = app.actions()[-1]
        events.append({**response(assistant, "read-only result"), "id": "4"})
        app.tick(native)
        app.close()
        app = workflow(tmp_path)
        app.tick(native)
        assert app.matters()[0]["result"]["content"] == "read-only result"
        assert len(events) == 4
        context = json.loads(events[0]["payload"]["content"])
        assert context["allowed_action"] == "read_only_analysis"
        assert context["evidence"][0]["record"] == "approval-17"
        assert matter["id"] in events[0]["target"]
    finally:
        server.shutdown()
        server.server_close()
        thread.join()
