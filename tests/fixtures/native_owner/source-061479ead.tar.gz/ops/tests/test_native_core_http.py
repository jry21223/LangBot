"""Actual bounded HTTP on proposed protected Core routes; no live receiver/key."""

from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
from threading import Thread
import time
from urllib.parse import parse_qs, urlsplit

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from test_native_ingress_foundation import page

BOT = "4f8736ca-57d8-450a-859e-a7ce9e3d34a8"
WORKSPACE = "core-workspace-1"
KEY = "normal-core-key-0123456789abcdef-0001"


@pytest.fixture
def protected_core(tmp_path):
    from enterprise_agent.native_core_http import NativeCoreHttp

    prefix = f"/api/v1/native-ingress/{BOT}/router"
    state = dict(
        calls=[],
        page=page(),
        receipts={},
        drop_ack=False,
        delay=0,
        status=200,
        override=None,
        redirect=False,
    )

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def handle_request(self, method):
            route = urlsplit(self.path)
            query = parse_qs(route.query)
            body = (
                json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
                if method == "POST"
                else None
            )
            state["calls"].append(
                dict(
                    method=method,
                    path=route.path,
                    query=query,
                    body=body,
                    workspace=self.headers.get("X-Workspace-Id"),
                    authorization=self.headers.get("Authorization"),
                )
            )
            if state["delay"]:
                time.sleep(state["delay"])
            status = state["status"]
            if (
                self.headers.get("X-API-Key") != KEY
                or self.headers.get("X-Workspace-Id") != WORKSPACE
            ):
                status = 403
            if status != 200 or not route.path.startswith(prefix + "/"):
                self.send_response(403)
                self.end_headers()
                self.wfile.write(
                    json.dumps(dict(code=403, data=None, msg="denied")).encode()
                )
                return
            if state["redirect"]:
                self.send_response(302)
                self.send_header("Location", "/must-not-follow")
                self.end_headers()
                return
            if route.path == prefix + "/changes":
                assert (
                    method == "GET"
                    and set(query) <= {"cursor", "limit"}
                    and query.get("limit") == ["100"]
                )
                result = deepcopy(state["page"])
            elif route.path == prefix + "/ack":
                assert method == "POST" and set(body) == {
                    "page_id",
                    "page_sha256",
                    "receipts",
                }
                assert body["page_sha256"] == state["page"]["page_sha256"]
                for receipt in body["receipts"]:
                    state["receipts"][receipt["event_id"]] = deepcopy(receipt)
                if state["drop_ack"]:
                    state["drop_ack"] = False
                    self.connection.close()
                    return
                result = dict(
                    status="accepted",
                    page_id=body["page_id"],
                    next_cursor=state["page"]["next_cursor"],
                )
            else:
                assert (
                    method == "GET"
                    and route.path.startswith(prefix + "/receipts/")
                    and not query
                )
                event_id = route.path.rsplit("/", 1)[1]
                result = state["receipts"].get(event_id)
            wrapper = (
                dict(code=0, data=result, msg="ok")
                if state["override"] is None
                else state["override"]
            )
            raw = json.dumps(wrapper).encode()
            self.send_response(status)
            self.end_headers()
            try:
                self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            self.handle_request("GET")

        def do_POST(self):
            self.handle_request("POST")

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    keyfile = tmp_path / "core.key"
    keyfile.write_text(KEY)
    keyfile.chmod(0o600)
    endpoint = f"http://127.0.0.1:{server.server_port}"

    def client(**overrides):
        return NativeCoreHttp(
            **dict(
                dict(
                    endpoint=endpoint,
                    bot_uuid=BOT,
                    workspace=WORKSPACE,
                    api_key_file=str(keyfile),
                    source="fixture-payments",
                    scope="finance-read",
                ),
                **overrides,
            )
        )

    try:
        yield client(), state, client, keyfile
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


def test_public_http_client_uses_final_routes_and_normal_core_identity_without_serializing_authorize(
    protected_core,
):
    from enterprise_agent.native_ingress import accepted_receipt

    client, state, _, _ = protected_core

    def forbidden(*_):
        raise AssertionError("a client callback is not the server authorizer")

    received = client.read_router_page(None, 100, authorize=forbidden)
    assert received == state["page"]
    assert client.lookup_router_receipt("core-event-1", authorize=forbidden) is None
    item = received["items"][0]
    receipt = accepted_receipt(item["event_id"], item["envelope"])
    proof = client.ack_router_page(
        received["page_id"], received["page_sha256"], [receipt], authorize=forbidden
    )
    assert proof == dict(
        status="accepted",
        page_id=received["page_id"],
        next_cursor=received["next_cursor"],
    )
    assert (
        client.lookup_router_receipt(item["event_id"], authorize=forbidden) == receipt
    )
    assert all(
        call["workspace"] == WORKSPACE and call["authorization"] is None
        for call in state["calls"]
    )
    assert "cursor" not in state["calls"][0]["query"]
    assert all("authorize" not in json.dumps(call) for call in state["calls"])


@pytest.mark.parametrize("identity", ["wrong_workspace", "wrong_key", "business_token"])
def test_wrong_core_identity_is_rejected_without_borrowing_finance_or_business_credentials(
    protected_core, identity
):
    client, state, factory, keyfile = protected_core
    if identity == "wrong_workspace":
        client = factory(workspace="another-workspace")
    else:
        keyfile.write_text(
            "wrong-normal-key-0123456789abcdef"
            if identity == "wrong_key"
            else "business-token-0123456789abcdef"
        )
    with pytest.raises(ValueError, match="native_core_unavailable"):
        client.read_router_page(None, 100, authorize=lambda *_: True)
    assert len(state["calls"]) == 1


@pytest.mark.parametrize(
    "fault",
    [
        "http403",
        "code",
        "extra_wrapper",
        "wrong_body",
        "bool_code",
        "redirect",
        "wrong_page_scope",
    ],
)
def test_invalid_core_wrapper_status_or_scope_never_becomes_an_accepted_page(
    protected_core, fault
):
    client, state, _, _ = protected_core
    if fault == "http403":
        state["status"] = 403
    elif fault == "code":
        state["override"] = dict(
            code=1001, data=None, msg="PRIVATE BACKEND URL/KEY MUST NOT BE ECHOED"
        )
    elif fault == "extra_wrapper":
        state["override"] = dict(code=0, data=state["page"], msg="ok", unexpected=True)
    elif fault == "wrong_body":
        state["override"] = dict(code=0, data=[], msg="ok")
    elif fault == "bool_code":
        state["override"] = dict(code=False, data=state["page"], msg="ok")
    elif fault == "redirect":
        state["redirect"] = True
    else:
        state["page"]["scope"] = "another-scope"
    with pytest.raises(ValueError, match="^native_core_unavailable$"):
        client.read_router_page(None, 100, authorize=lambda *_: True)
    assert len(state["calls"]) == 1


def test_overall_http_deadline_is_finite(protected_core):
    _, state, factory, _ = protected_core
    client = factory(timeout=0.08)
    state["delay"] = 0.3
    started = time.monotonic()
    with pytest.raises(ValueError, match="native_core_unavailable"):
        client.read_router_page(None, 100, authorize=lambda *_: True)
    assert time.monotonic() - started < 0.25


def test_native_owner_denial_precedes_any_core_read_and_ack_recovery(
    protected_core, tmp_path
):
    from enterprise_agent.native_ingress import NativeIngress
    from enterprise_agent.producer import Producer
    from enterprise_agent.workflow import Workflow

    client, state, _, _ = protected_core

    class Owner:
        source = "fixture-payments"
        scope = "finance-read"

        def authorize(self, *_):
            raise ValueError("owner_denied")

    ingress = NativeIngress(Owner(), transport=client)
    app = Workflow(
        tmp_path / "state.sqlite",
        workspace="test-workspace",
        coordinator="main-agent",
        assistants=["finance-assistant"],
        authorize=ingress.authorize,
    )
    try:
        producer = Producer(app, rule_version="fixture", model_version="none")
        with pytest.raises(ValueError, match="owner_denied"):
            ingress.poll(producer, limit=100)
        assert state["calls"] == []
    finally:
        app.close()


def test_actual_core_http_lost_ack_rebuilds_same_ledger_and_retries_same_keys(
    protected_core, tmp_path
):
    from enterprise_agent.native_ingress import NativeIngress
    from enterprise_agent.producer import Producer
    from enterprise_agent.workflow import Workflow
    from test_enterprise_agent_1324 import grant

    client, state, _, _ = protected_core
    owner_change = deepcopy(state["page"]["items"][0]["envelope"])
    authority = dict(active=True, descriptors=0)

    class Owner:
        source = "fixture-payments"
        scope = "finance-read"

        def authorize(self, source, stage, agent=None):
            if not authority["active"]:
                raise ValueError("owner_denied")
            return grant(source, stage, agent)

        def authorize_evidence(self, event, stage, agent=None):
            return self.authorize(event["source"], stage, agent)

        def read_descriptor(self, event, *, include_history=False):
            assert include_history is True
            authority["descriptors"] += 1
            return dict(
                reference=owner_change["original"],
                version=owner_change["version"],
                projection_hash=owner_change["projection_hash"],
                kind=owner_change["kind"],
                original_available=True,
            )

    def reopen():
        ingress = NativeIngress(Owner(), transport=client)
        app = Workflow(
            tmp_path / "recovery.sqlite",
            workspace="test-workspace",
            coordinator="main-agent",
            assistants=["finance-assistant"],
            authorize=ingress.authorize,
            authorize_evidence=ingress.authorize_evidence,
        )
        return ingress, app, Producer(app, rule_version="fixture", model_version="none")

    ingress, app, producer = reopen()
    state["drop_ack"] = True
    try:
        with pytest.raises(ValueError, match="native_core_unavailable"):
            ingress.poll(producer, limit=100)
        committed = producer.coverage("fixture-payments")["native_ingress"]
        assert committed["ack_pending"] is True and len(producer.candidates()) == 1
        first_ack = next(
            c["body"] for c in state["calls"] if c["path"].endswith("/ack")
        )
        count = len(state["calls"])
        authority["active"] = False
        with pytest.raises(ValueError, match="owner_denied"):
            ingress.poll(producer, limit=100)
        assert len(state["calls"]) == count
    finally:
        app.close()
    authority["active"] = True
    ingress, restarted, producer = reopen()
    try:
        assert ingress.poll(producer, limit=100)["acknowledged"] is True
        acks = [c["body"] for c in state["calls"] if c["path"].endswith("/ack")]
        assert acks == [first_ack, first_ack]
        assert sum(c["path"].endswith("/changes") for c in state["calls"]) == 1
        assert any("/receipts/core-event-1" in c["path"] for c in state["calls"])
        assert (
            producer.coverage("fixture-payments")["native_ingress"]["ack_pending"]
            is False
        )
        assert len(producer.candidates()) == 1 and authority["descriptors"] == 1
    finally:
        restarted.close()


@pytest.mark.parametrize("fault", ["mode", "symlink", "hardlink", "fifo"])
def test_private_core_key_file_is_required_and_invalid_files_never_read_core(
    protected_core, fault
):
    import os

    client, state, _, keyfile = protected_core
    if fault == "mode":
        keyfile.chmod(0o644)
    elif fault == "hardlink":
        os.link(keyfile, keyfile.with_suffix(".linked"))
    elif fault == "symlink":
        real = keyfile.with_suffix(".real")
        keyfile.rename(real)
        keyfile.symlink_to(real)
    else:
        keyfile.unlink()
        os.mkfifo(keyfile, 0o600)
    started = time.monotonic()
    with pytest.raises(ValueError, match="native_core_unavailable"):
        client.read_router_page(None, 100)
    assert time.monotonic() - started < 0.3 and state["calls"] == []


def test_core_key_has_no_environment_or_finance_identity_fallback(
    protected_core, monkeypatch
):
    client, state, _, keyfile = protected_core
    keyfile.unlink()
    for name in (
        "CORE_API_KEY",
        "LANGBOT_API_KEY",
        "OPENAGENTS_TOKEN",
        "FINANCE_TOKEN",
    ):
        monkeypatch.setenv(name, KEY)
    with pytest.raises(ValueError, match="native_core_unavailable"):
        client.read_router_page(None, 100)
    assert state["calls"] == []


def test_http_operation_inherits_and_restores_the_host_deadline(protected_core):
    from enterprise_agent._http_budget import current_deadline

    client, state, _, _ = protected_core
    state["delay"] = 0.3
    deadline = time.monotonic() + 0.07
    binding = current_deadline.set(deadline)
    try:
        with pytest.raises(ValueError, match="native_core_unavailable"):
            client.read_router_page(None, 100)
        assert current_deadline.get() == deadline
    finally:
        current_deadline.reset(binding)


@pytest.mark.parametrize(
    "bad_receipt",
    [
        dict(event_id="other-event"),
        dict(source="different-source"),
        dict(secret="extra-field"),
    ],
)
def test_lookup_receipt_identity_and_exact_shape_are_not_trusted_from_wrapper(
    protected_core, bad_receipt
):
    from enterprise_agent.native_ingress import accepted_receipt

    client, state, _, _ = protected_core
    receipt = accepted_receipt("core-event-1", state["page"]["items"][0]["envelope"])
    receipt.update(bad_receipt)
    state["override"] = dict(code=0, data=receipt, msg="ok")
    with pytest.raises(ValueError, match="native_core_unavailable"):
        client.lookup_router_receipt("core-event-1")


def test_a_registered_workspace_and_key_cannot_select_another_receiver_uuid(
    protected_core,
):
    _, state, factory, _ = protected_core
    client = factory(bot_uuid="854c9117-ef1a-4abb-969f-6252f86c0be9")
    with pytest.raises(ValueError, match="native_core_unavailable"):
        client.read_router_page(None, 100)
    assert len(state["calls"]) == 1


@pytest.mark.parametrize("event_id", ["../escape", ".", ".."])
def test_unaddressable_event_ids_are_rejected_before_a_page_can_commit(
    protected_core, event_id
):
    from enterprise_agent.native_ingress import sourcepage_digest

    client, state, _, _ = protected_core
    state["page"]["items"][0]["event_id"] = event_id
    state["page"]["page_sha256"] = sourcepage_digest(state["page"])
    with pytest.raises(ValueError, match="native_core_unavailable"):
        client.read_router_page(None, 100)


def test_consumer_binding_is_normalized_nonsecret_configuration_and_does_not_read_the_key(
    protected_core, tmp_path
):
    _, state, factory, _ = protected_core
    client = factory(
        endpoint="https://CORE.EXAMPLE.INVALID:443/",
        api_key_file=str(tmp_path / "not-created.key"),
    )
    binding = client.consumer_binding()
    assert binding == dict(
        endpoint="https://core.example.invalid",
        workspace=WORKSPACE,
        bot_uuid=BOT,
        source="fixture-payments",
        scope="finance-read",
        flavor="finance",
    )
    assert state["calls"] == []
    assert all("key" not in name for name in binding)
