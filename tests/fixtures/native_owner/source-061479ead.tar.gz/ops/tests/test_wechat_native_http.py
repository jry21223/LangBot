"""Real scoped source HTTP with isolated SQLite and synthetic owner reads."""

from copy import deepcopy
import json
from pathlib import Path
import socket
import sys
from threading import Thread
import urllib.error
import urllib.request

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture
def scoped(tmp_path):
    from enterprise_agent.wechat_source import WechatJournal, source_server
    from enterprise_agent.wechat_native_store import NativeWechatStore

    message = dict(
        account_id="account",
        thread_id="test@chatroom",
        message_id="message-1",
        sender_id="sender",
        server_id="server-1",
        message_type="text",
        direction="incoming",
        native_version="native-1",
        body="PRIVATE ORIGINAL",
        media=[],
        recalled=False,
        business_at="2026-11-08T00:00:00Z",
    )
    legacy = WechatJournal(
        tmp_path / "source.sqlite",
        account="account",
        thread="test@chatroom",
        start_cursor=0,
    )
    store = NativeWechatStore(
        tmp_path / "source.sqlite",
        account="account",
        thread="test@chatroom",
        source="wx-test",
        scope="test-only",
        parser_version="parser-1",
        sequence_floor=0,
    )
    item = store.commit_native(
        message, event_cursor="1", observed_at="2026-11-08T00:00:01Z"
    )
    change = item["change"]
    store.close()

    def credential(name):
        p = tmp_path / name
        p.write_text("synthetic-" + name + "-credential-0123456789abcdef")
        p.chmod(0o600)
        return str(p)

    readers = []
    for principal, workspace, agents, actions in [
        (
            "metadata",
            "core-workspace",
            [],
            ["binding", "changes", "metadata_authority", "descriptor"],
        ),
        (
            "original",
            "oa-workspace",
            ["analysis-lab"],
            [
                "binding",
                "metadata_authority",
                "original_authority",
                "descriptor",
                "original",
                "manifest",
                "chunk",
                "media",
                "derived",
            ],
        ),
        (
            "worker",
            "worker-workspace",
            ["native-parser"],
            [
                "metadata_authority",
                "original_authority",
                "media",
                "materialization_records",
                "save_materialization",
                "derived",
            ],
        ),
    ]:
        readers.append(
            dict(
                principal=principal,
                workspace=workspace,
                agents=agents,
                actions=actions,
                sharing_approved=True,
                revision="approval-1",
                token_file=credential(principal),
                content_types=[]
                if principal == "metadata"
                else ["text", "image", "voice", "file"],
            )
        )
    for principal, types in [
        ("text-only", ["text"]),
        ("image-only", ["image"]),
        ("file-only", ["file"]),
    ]:
        reader = deepcopy(readers[1])
        reader.update(
            principal=principal,
            workspace=principal + "-workspace",
            token_file=credential(principal),
            content_types=types,
        )
        readers.append(reader)
    sock = socket.socket()
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
    sock.close()
    config = dict(
        version=1,
        enabled=True,
        account="account",
        thread="test@chatroom",
        start_cursor=0,
        events=str(tmp_path / "events"),
        wx="/unused/wx",
        database=str(tmp_path / "source.sqlite"),
        listen_port=port,
        source="wx-test",
        scope="test-only",
        workspace="legacy",
        principal="legacy",
        agents=["analysis-lab"],
        read_token_file=credential("legacy"),
        native=dict(
            enabled=True,
            parser_version="parser-1",
            activation_at="2026-11-08T00:00:00Z",
            sequence_floor=0,
            owner=dict(
                endpoint="http://127.0.0.1:1/v1", token_file=credential("owner")
            ),
            readers=readers,
        ),
    )
    path = tmp_path / "source.json"
    path.write_text(json.dumps(config))
    path.chmod(0o600)

    class Owner:
        calls = []
        mutate = False
        connected = True
        media_data = None

        def status(self):
            return (
                dict(
                    account="account",
                    authenticated=self.connected,
                    connection="online" if self.connected else "disconnected",
                    incoming_transport="native_push"
                    if self.connected
                    else "disconnected",
                    contact_sync_ready=self.connected,
                    observed_at="2026-11-08T00:00:00Z",
                )
                if self.connected is not None
                else None
            )

        def message(self, message_id):
            self.calls.append(("message", message_id))
            result = deepcopy(self.message_data)
            if self.mutate and len(self.calls) > 1:
                result["body"] = "CHANGED PRIVATE ORIGINAL"
            return result

        def media(self, *args):
            self.calls.append(("media", args))
            if self.media_data is None:
                raise AssertionError("unknown media must not reach owner")
            return self.media_data

    owner = Owner()
    owner.message_data = message
    server = source_server(str(path), legacy, native_owner=owner)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()

    def get(route, *, principal="metadata", extra=None, method="GET", body=None):
        reader = next(r for r in readers if r["principal"] == principal)
        query = dict(source="wx-test", scope="test-only", workspace=reader["workspace"])
        query.update(extra or {})
        from urllib.parse import urlencode

        headers = {
            "Authorization": "Bearer " + Path(reader["token_file"]).read_text(),
            "X-Operator": principal,
        }
        data = json.dumps(body).encode() if body is not None else None
        if data:
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            f"http://127.0.0.1:{port}" + route + "?" + urlencode(query),
            data=data,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=5) as response:
                return response.status, response.read(), dict(response.headers)
        except urllib.error.HTTPError as error:
            return error.code, error.read(), dict(error.headers)

    get.service = server.native_service
    yield get, owner, change, config, path
    server.shutdown()
    server.server_close()
    thread.join()
    legacy.close()


@pytest.mark.parametrize(
    "route", ["original", "manifest", "chunk", "media", "derived", "materializations"]
)
def test_metadata_reader_cannot_read_body_or_media_before_owner_io(scoped, route):
    get, owner, change, _, _ = scoped
    code, raw, _ = get(
        "/native/" + route,
        extra=dict(
            reference=change["original"],
            version=change["version"],
            agent="analysis-lab",
            stage="dispatch",
            part_index=0,
            asset_id="unknown",
            parser_version="parser-1",
        ),
    )
    assert code == 403 and b"PRIVATE ORIGINAL" not in raw and owner.calls == []


def test_source_metadata_is_scoped_and_never_copies_body(scoped):
    get, owner, _, _, _ = scoped
    code, raw, _ = get("/native/changes")
    assert code == 200 and b"PRIVATE ORIGINAL" not in raw and owner.calls == []
    assert json.loads(raw)["source"] == "wx-test"
    assert get("/native/binding", extra={"scope": "other"})[0] == 403
    assert get("/native/ack", method="POST", body={})[0] == 403


def test_original_requires_actual_registered_agent_and_current_owner(scoped):
    get, owner, change, _, _ = scoped
    params = dict(
        reference=change["original"],
        version=change["version"],
        stage="dispatch",
        agent="analysis-lab",
    )
    code, raw, _ = get("/native/original", principal="original", extra=params)
    assert (
        code == 200
        and json.loads(raw)["text"] == "PRIVATE ORIGINAL"
        and len(owner.calls) == 2
    )
    owner.calls.clear()
    assert (
        get(
            "/native/original",
            principal="original",
            extra=dict(params, agent="unregistered"),
        )[0]
        == 403
    )
    assert owner.calls == []
    owner.mutate = True
    assert get("/native/original", principal="original", extra=params)[0] == 409


def test_unknown_asset_and_unregistered_scope_never_call_wx(scoped):
    get, owner, change, _, _ = scoped
    params = dict(
        reference=change["original"],
        version=change["version"],
        stage="dispatch",
        agent="analysis-lab",
        asset_id="not-indexed",
    )
    assert get("/native/media", principal="original", extra=params)[0] in {403, 404}
    assert owner.calls == []


def test_upstream_status_is_distinct_from_reachable_feed_and_grant(scoped):
    get, owner, change, _, _ = scoped
    owner.connected = False
    code, raw, _ = get(
        "/native/authority",
        extra=dict(stage="ingest", audience_workspace="core-workspace"),
    )
    status = json.loads(raw)
    assert code == 200 and status["grant"]["active"] is True
    assert status["collector"]["connection"] == "disconnected"
    assert get("/native/changes")[0] == 200
    assert (
        get(
            "/native/original",
            principal="original",
            extra=dict(
                reference=change["original"],
                version=change["version"],
                stage="dispatch",
                agent="analysis-lab",
            ),
        )[0]
        == 409
    )
    assert owner.calls == []


def test_collector_filters_before_owner_io_and_persists_unresolved_cursor(scoped):
    get, owner, _, config, _ = scoped
    rows = [
        dict(
            accountId="account",
            cursor="2",
            kind="message.committed",
            createdAt="2026-11-08T00:00:02Z",
            data=dict(
                threadId="other", direction="incoming", messageId="not-permitted"
            ),
        ),
        dict(
            accountId="account",
            cursor="3",
            kind="media.ready",
            createdAt="2026-11-08T00:00:03Z",
            data=dict(assetId="unknown-asset"),
        ),
        dict(
            accountId="account",
            cursor="4",
            kind="message.committed",
            createdAt="2026-11-08T00:00:04Z",
            data=dict(
                threadId="test@chatroom",
                direction="incoming",
                messageId="message-1",
                origin="live",
            ),
        ),
    ]
    Path(config["events"]).write_text("".join(json.dumps(r) + "\n" for r in rows))
    assert get.service.collect(config["events"]) == 3
    assert owner.calls == [("message", "message-1")]
    page = json.loads(get("/native/changes")[1])
    unknown = [r for r in page["items"] if r.get("kind") == "unresolved"]
    assert (
        len(unknown) == 1
        and "change" not in unknown[0]
        and "reference" not in unknown[0]
    )
    assert get.service.collect(config["events"]) == 0
    assert len(owner.calls) == 1
    status = json.loads(
        get(
            "/native/authority",
            extra=dict(stage="ingest", audience_workspace="core-workspace"),
        )[1]
    )
    assert status["grant"]["active"] is True
    assert get.service.last_success_at is not None


def test_profile_or_credential_drift_revokes_without_body_leak(scoped):
    get, owner, change, config, path = scoped
    params = dict(
        reference=change["original"],
        version=change["version"],
        stage="dispatch",
        agent="analysis-lab",
    )
    config["native"]["readers"][1]["revision"] = "approval-revoked"
    path.write_text(json.dumps(config))
    code, raw, _ = get("/native/original", principal="original", extra=params)
    assert code == 403 and b"PRIVATE ORIGINAL" not in raw and owner.calls == []


def test_worker_save_replay_and_receipt_lookup_do_not_reparse_or_read_recalled_body(
    scoped,
):
    from hashlib import sha256
    from enterprise_agent.wechat_native_store import NativeWechatStore

    get, owner, _, config, _ = scoped
    data = b"cached-image"
    owner.message_data = dict(
        owner.message_data,
        message_type="image",
        native_version="native-image",
        body="<xml/>",
        media=[
            dict(
                asset_id="image-1",
                kind="image",
                state="available",
                sha256=sha256(data).hexdigest(),
                byte_length=len(data),
                content_type="image/png",
            )
        ],
    )
    store = NativeWechatStore(
        config["database"],
        account=config["account"],
        thread=config["thread"],
        source=config["source"],
        scope=config["scope"],
        parser_version="parser-1",
        sequence_floor=0,
    )
    image = store.commit_native(
        owner.message_data, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )["change"]
    snap = store.snapshot(image["original"], image["version"])
    store.close()
    body = dict(
        reference=image["original"],
        version=image["version"],
        input_hash=snap["input_hash"],
        parser_version="parser-1",
        status="COMPLETE",
        content_text="Derived image text",
        parts=[{"text": "Derived image text"}],
        issues=[],
        media_hashes={"image-1": sha256(data).hexdigest()},
        operation_id="save-once",
    )
    params = dict(stage="materialize", agent="native-parser")
    code, raw, _ = get(
        "/native/materializations",
        principal="worker",
        extra=params,
        method="POST",
        body=body,
    )
    assert code == 200
    receipt = json.loads(raw)
    assert receipt["reference"] != image["original"]
    count = len(owner.calls)
    owner.message_data = dict(
        owner.message_data, recalled=True, native_version="recalled"
    )
    assert (
        json.loads(
            get(
                "/native/materializations",
                principal="worker",
                extra=params,
                method="POST",
                body=body,
            )[1]
        )
        == receipt
    )
    assert len(owner.calls) == count
    lookup = dict(params, operation_id="save-once")
    assert (
        json.loads(
            get("/native/materialization-operations", principal="worker", extra=lookup)[
                1
            ]
        )
        == receipt
    )
    assert (
        get(
            "/native/materialization-operations",
            principal="original",
            extra=dict(lookup, agent="analysis-lab", stage="display"),
        )[0]
        == 403
    )
    assert (
        get(
            "/native/materialization-operations",
            extra=dict(lookup, agent="analysis-lab", stage="display"),
        )[0]
        == 403
    )


def test_cached_binary_is_verified_and_no_store_without_unscoped_owner_asset_lookup(
    scoped,
):
    from hashlib import sha256
    from enterprise_agent.wechat_native_store import NativeWechatStore

    get, owner, _, config, _ = scoped
    data = b"only cached media"
    asset = dict(
        asset_id="accepted-image",
        kind="image",
        state="available",
        sha256=sha256(data).hexdigest(),
        byte_length=len(data),
        content_type="image/png",
    )
    owner.message_data = dict(
        owner.message_data,
        message_type="image",
        native_version="image-native",
        body=None,
        media=[asset],
    )
    owner.media_data = data
    store = NativeWechatStore(
        config["database"],
        account=config["account"],
        thread=config["thread"],
        source=config["source"],
        scope=config["scope"],
        parser_version="parser-1",
        sequence_floor=0,
    )
    change = store.commit_native(
        owner.message_data, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )["change"]
    store.close()
    params = dict(
        reference=change["original"],
        version=change["version"],
        stage="dispatch",
        agent="analysis-lab",
        asset_id="accepted-image",
    )
    code, raw, headers = get("/native/media", principal="original", extra=params)
    assert code == 200 and raw == data
    assert (
        headers["X-Content-SHA256"] == asset["sha256"]
        and headers["Cache-Control"] == "no-store"
    )
    owner.media_data = b"bad bytes"
    assert get("/native/media", principal="original", extra=params)[0] == 409


def test_authority_unknown_upstream_omits_collector_and_body_is_not_confirmed(scoped):
    get, owner, change, _, _ = scoped
    owner.connected = None
    code, raw, _ = get(
        "/native/authority",
        extra=dict(stage="ingest", audience_workspace="core-workspace"),
    )
    assert code == 200 and "collector" not in json.loads(raw)
    assert (
        get(
            "/native/original",
            principal="original",
            extra=dict(
                reference=change["original"],
                version=change["version"],
                stage="display",
                agent="analysis-lab",
            ),
        )[0]
        == 409
    )


def test_profile_generation_change_keeps_existing_reference_readable(scoped):
    get, owner, change, _, _ = scoped
    owner.message_data["native_version"] = "profile-generation-2"
    code, raw, _ = get(
        "/native/original",
        principal="original",
        extra=dict(
            reference=change["original"],
            version=change["version"],
            stage="dispatch",
            agent="analysis-lab",
        ),
    )
    assert code == 200
    assert json.loads(raw)["text"] == "PRIVATE ORIGINAL"


def test_unapproved_content_type_rejects_original_and_authority_before_owner_io(scoped):
    from enterprise_agent.wechat_native_store import NativeWechatStore

    get, owner, _, config, _ = scoped
    video = dict(
        owner.message_data, message_id="video-unapproved", message_type="video"
    )
    store = NativeWechatStore(
        config["database"],
        account=config["account"],
        thread=config["thread"],
        source=config["source"],
        scope=config["scope"],
        parser_version="parser-1",
        sequence_floor=0,
    )
    change = store.commit_native(
        video, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )["change"]
    store.close()
    params = dict(
        reference=change["original"],
        version=change["version"],
        stage="dispatch",
        agent="analysis-lab",
    )
    assert get("/native/original", principal="original", extra=params)[0] == 403
    assert (
        get(
            "/native/authority",
            principal="original",
            extra=dict(params, audience_workspace="oa-workspace"),
        )[0]
        == 403
    )
    assert owner.calls == []


def test_unknown_recall_and_missing_message_id_become_unresolved_without_owner_io(
    scoped,
):
    get, owner, _, config, _ = scoped
    rows = [
        dict(
            accountId="account",
            cursor="2",
            kind="message.recalled",
            data=dict(
                threadId="test@chatroom", messageId="not-accepted", serverId="unknown"
            ),
        ),
        dict(
            accountId="account",
            cursor="3",
            kind="message.committed",
            data=dict(threadId="test@chatroom", direction="incoming"),
        ),
    ]
    Path(config["events"]).write_text("".join(json.dumps(r) + "\n" for r in rows))
    assert get.service.collect(config["events"]) == 2
    assert owner.calls == []
    items = json.loads(get("/native/changes")[1])["items"]
    assert len([r for r in items if r.get("kind") == "unresolved"]) == 2


def test_unknown_original_index_is_not_found_without_owner_io(scoped):
    get, owner, _, _, _ = scoped
    params = dict(
        reference="not-accepted",
        version="not-known",
        stage="dispatch",
        agent="analysis-lab",
    )
    assert get("/native/original", principal="original", extra=params)[0] == 404
    assert owner.calls == []


def test_owner_body_restore_cannot_revive_indexed_tombstone_or_stall_cursor(scoped):
    from enterprise_agent.wechat_native_store import NativeWechatStore

    get, owner, _, config, _ = scoped
    store = NativeWechatStore(
        config["database"],
        account=config["account"],
        thread=config["thread"],
        source=config["source"],
        scope=config["scope"],
        parser_version="parser-1",
        sequence_floor=0,
    )
    tombstone = dict(owner.message_data, recalled=True)
    change = store.commit_native(
        tombstone, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )["change"]
    store.close()
    row = dict(
        accountId="account",
        cursor="3",
        kind="message.committed",
        data=dict(
            threadId="test@chatroom",
            direction="incoming",
            messageId="message-1",
            origin="live",
        ),
    )
    Path(config["events"]).write_text(json.dumps(row) + "\n")
    assert get.service.collect(config["events"]) == 1
    assert get.service.collect(config["events"]) == 0
    owner.calls.clear()
    params = dict(
        reference=change["original"],
        version=change["version"],
        stage="display",
        agent="analysis-lab",
    )
    assert get("/native/original", principal="original", extra=params)[0] == 409
    assert owner.calls == []
    changes = json.loads(get("/native/changes")[1])["items"]
    assert changes[-1]["change"]["kind"] == "recalled"


def test_actual_owner_nullable_recall_collects_to_tombstone_feed_and_never_revives(
    scoped,
):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from enterprise_agent.wechat_owner_client import WxOwnerClient
    from enterprise_agent.wechat_native_store import NativeWechatStore

    get, _, _, config, _ = scoped
    raw = dict(
        id="message-1",
        accountId="account",
        threadId="test@chatroom",
        senderId=None,
        serverId=None,
        direction=None,
        version="profile-generation-1",
        type=10000,
        body=None,
        createdAt=None,
        recall={"observedAt": "2026-11-08T00:00:02Z"},
    )
    calls = []
    owner_key = Path(config["native"]["owner"]["token_file"]).read_text()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            calls.append(self.path)
            assert self.headers["Authorization"] == "Bearer " + owner_key
            assert self.path == "/v1/accounts/account/messages/" + raw["id"]
            data = json.dumps(raw).encode()
            self.send_response(200)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    upstream = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=upstream.serve_forever, daemon=True)
    thread.start()
    get.service.owner = WxOwnerClient(
        f"http://127.0.0.1:{upstream.server_port}/v1",
        token_file=config["native"]["owner"]["token_file"],
        account="account",
        thread="test@chatroom",
    )

    def collect(cursor, kind):
        row = dict(
            accountId="account",
            cursor=str(cursor),
            kind=kind,
            createdAt=f"2026-11-08T00:00:0{cursor}Z",
            data=dict(
                threadId="test@chatroom",
                direction="incoming",
                messageId=raw["id"],
                origin="live",
            ),
        )
        with Path(config["events"]).open("a") as stream:
            stream.write(json.dumps(row) + "\n")
        assert get.service.collect(config["events"]) == 1

    try:
        collect(2, "message.recalled")
        items = json.loads(get("/native/changes")[1])["items"]
        recall_change = items[-1]["change"]
        assert recall_change["kind"] == "recalled"
        assert recall_change["business_at"] == "2026-11-08T00:00:00Z"
        store = NativeWechatStore(
            config["database"],
            account="account",
            thread="test@chatroom",
            source="wx-test",
            scope="test-only",
            parser_version="parser-1",
            sequence_floor=0,
        )
        snapshot = store.snapshot(recall_change["original"], recall_change["version"])
        assert snapshot["business_at"] is None and snapshot["direction"] is None
        assert snapshot["sender_id"] is None and snapshot["body"] is None
        store.close()
        raw["recall"]["observedAt"] = "2026-11-08T00:00:03Z"
        collect(3, "message.recalled")
        assert len(json.loads(get("/native/changes")[1])["items"]) == len(items)
        raw.update(
            type=1,
            direction="incoming",
            body="RESTORED PRIVATE BODY",
            recall=None,
            createdAt="2026-11-08T00:00:00Z",
        )
        collect(4, "message.committed")
        assert len(json.loads(get("/native/changes")[1])["items"]) == len(items)
        before_calls = list(calls)
        params = dict(
            reference=recall_change["original"],
            version=recall_change["version"],
            stage="display",
            agent="analysis-lab",
        )
        assert get("/native/original", principal="original", extra=params)[0] == 409
        assert calls == before_calls
        assert get.service.collect(config["events"]) == 0
        raw.update(
            id="unknown-time",
            type=1,
            direction="incoming",
            body="PRIVATE UNKNOWN TIME",
            createdAt=None,
            recall=None,
        )
        collect(5, "message.committed")
        unqualified = json.loads(get("/native/changes")[1])["items"][-1]
        assert set(unqualified) == {
            "event_id",
            "kind",
            "source_sequence",
            "event_cursor",
            "reason",
            "source",
            "scope",
        }
        assert (
            unqualified["kind"] == "unresolved" and unqualified["event_cursor"] == "5"
        )
        assert b"PRIVATE UNKNOWN TIME" not in get("/native/changes")[1]
        raw.update(
            type=10000,
            direction=None,
            body=None,
            recall={"observedAt": "2026-11-08T00:00:06Z"},
        )
        collect(6, "message.recalled")
        unknown_recalled_count = len(json.loads(get("/native/changes")[1])["items"])
        raw.update(
            type=1, direction="incoming", body="PRIVATE UNKNOWN RESTORED", recall=None
        )
        collect(7, "message.committed")
        assert (
            len(json.loads(get("/native/changes")[1])["items"])
            == unknown_recalled_count
        )
        assert get.service.collect(config["events"]) == 0
        raw.update(
            id="ordinary-system",
            type=10000,
            direction=None,
            body="ordinary system notice",
            recall=None,
            createdAt="2026-11-08T00:00:08Z",
        )
        collect(8, "message.committed")
        system_item = json.loads(get("/native/changes")[1])["items"][-1]
        assert system_item["qualification"] != "ready"
        assert system_item["change"]["kind"] != "recalled"
        assert system_item["dispatch_eligible"] is False
        raw.update(
            type=1,
            direction="incoming",
            body="ACTUAL NORMAL MESSAGE",
            senderId="sender",
            serverId="server-system",
        )
        collect(9, "message.committed")
        normal_item = json.loads(get("/native/changes")[1])["items"][-1]
        assert normal_item["change"]["kind"] != "recalled"
        assert normal_item["dispatch_eligible"] is True
    finally:
        upstream.shutdown()
        upstream.server_close()
        thread.join()


@pytest.mark.parametrize("kind", ["image", "voice", "file"])
def test_complete_media_text_representation_keeps_original_type_acl(scoped, kind):
    from hashlib import sha256
    from enterprise_agent.wechat_native_store import NativeWechatStore

    get, owner, _, config, _ = scoped
    data = b"cached-media"
    content = "PRIVATE DERIVED " + kind
    asset = dict(
        asset_id="asset-" + kind,
        kind=kind,
        state="available",
        sha256=sha256(data).hexdigest(),
        byte_length=len(data),
        content_type="application/octet-stream",
    )
    owner.message_data = dict(
        owner.message_data, message_type=kind, body=None, media=[asset]
    )
    store = NativeWechatStore(
        config["database"],
        account="account",
        thread="test@chatroom",
        source="wx-test",
        scope="test-only",
        parser_version="parser-1",
        sequence_floor=0,
    )
    change = store.commit_native(
        owner.message_data, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )["change"]
    snapshot = store.snapshot(change["original"], change["version"])
    store.close()
    payload = dict(
        reference=change["original"],
        version=change["version"],
        input_hash=snapshot["input_hash"],
        parser_version="parser-1",
        status="COMPLETE",
        content_text=content,
        parts=[{"text": content}],
        issues=[],
        media_hashes={asset["asset_id"]: asset["sha256"]},
        operation_id="materialized-" + kind,
    )
    status, raw, _ = get(
        "/native/materializations",
        principal="worker",
        method="POST",
        body=payload,
        extra=dict(stage="materialize", agent="native-parser"),
    )
    assert status == 200
    receipt = json.loads(raw)
    params = dict(
        reference=receipt["reference"],
        version=receipt["version"],
        stage="display",
        agent="analysis-lab",
    )
    for route in ["original", "manifest", "chunk", "derived"]:
        query = dict(params)
        if route == "chunk":
            query["part_index"] = 0
        elif route == "derived":
            query["parser_version"] = "parser-1"
        for principal in ["text-only", "metadata"]:
            owner.calls.clear()
            status, raw, _ = get("/native/" + route, principal=principal, extra=query)
            assert status == 403 and content.encode() not in raw and owner.calls == []
        status, raw, _ = get("/native/" + route, principal="original", extra=query)
        assert status == 200
        if route == "manifest":
            assert json.loads(raw)["kind"] == "text"
            assert json.loads(raw)["sha256"] == sha256(content.encode()).hexdigest()
        else:
            assert content.encode() in raw
        owner.calls.clear()
        status, raw, _ = get("/native/" + route, principal="image-only", extra=query)
        assert status == (200 if kind == "image" else 403)
        if kind != "image":
            assert content.encode() not in raw and owner.calls == []


def test_original_type_permission_does_not_implicitly_authorize_other_asset_type(
    scoped,
):
    from hashlib import sha256
    from enterprise_agent.wechat_native_store import NativeWechatStore

    get, owner, _, config, _ = scoped
    asset = dict(
        asset_id="embedded-image",
        kind="image",
        state="available",
        sha256=sha256(b"x").hexdigest(),
        byte_length=1,
        content_type="image/png",
    )
    owner.message_data = dict(
        owner.message_data, message_type="file", body=None, media=[asset]
    )
    store = NativeWechatStore(
        config["database"],
        account="account",
        thread="test@chatroom",
        source="wx-test",
        scope="test-only",
        parser_version="parser-1",
        sequence_floor=0,
    )
    change = store.commit_native(
        owner.message_data, event_cursor="2", observed_at="2026-11-08T00:00:02Z"
    )["change"]
    snapshot = store.snapshot(change["original"], change["version"])
    receipt = store.save_materialization(
        change["original"],
        change["version"],
        snapshot["input_hash"],
        "parser-1",
        "COMPLETE",
        "PRIVATE EMBEDDED IMAGE",
        [],
        [],
        {asset["asset_id"]: asset["sha256"]},
        "embedded-result",
    )
    store.close()
    params = dict(
        reference=receipt["reference"],
        version=receipt["version"],
        stage="display",
        agent="analysis-lab",
    )
    for route in ["original", "manifest", "chunk", "derived", "authority"]:
        query = dict(params)
        if route == "chunk":
            query["part_index"] = 0
        elif route == "derived":
            query["parser_version"] = "parser-1"
        elif route == "authority":
            query["audience_workspace"] = "file-only-workspace"
        owner.calls.clear()
        status, raw, _ = get("/native/" + route, principal="file-only", extra=query)
        assert (
            status == 403 and b"PRIVATE EMBEDDED IMAGE" not in raw and owner.calls == []
        )
    assert get("/native/original", principal="original", extra=params)[0] == 200


def test_content_type_approval_revoked_during_read_never_releases_body(scoped):
    get, owner, change, config, path = scoped
    original_read = owner.message

    def revoke_after_owner_read(message_id):
        result = original_read(message_id)
        config["native"]["readers"][1]["content_types"] = ["image"]
        path.write_text(json.dumps(config))
        return result

    owner.message = revoke_after_owner_read
    params = dict(
        reference=change["original"],
        version=change["version"],
        stage="display",
        agent="analysis-lab",
    )
    status, raw, _ = get("/native/original", principal="original", extra=params)
    assert status == 403 and b"PRIVATE ORIGINAL" not in raw
    assert owner.calls


@pytest.mark.parametrize(
    "principal,route,agent",
    [
        ("metadata", "/native/materializations", "native-parser"),
        ("worker", "/native/materializations", "unregistered"),
        ("worker", "/native/original", "native-parser"),
        ("worker", "/native/unknown", "native-parser"),
    ],
)
def test_post_is_fully_authorized_before_waiting_for_any_body(
    scoped, principal, route, agent
):
    from urllib.parse import urlencode

    _, owner, _, config, _ = scoped
    reader = next(r for r in config["native"]["readers"] if r["principal"] == principal)
    query = urlencode(
        dict(
            source="wx-test",
            scope="test-only",
            workspace=reader["workspace"],
            stage="materialize",
            agent=agent,
        )
    )
    token = Path(reader["token_file"]).read_text()
    with socket.create_connection(
        ("127.0.0.1", config["listen_port"]), timeout=1
    ) as connection:
        connection.settimeout(0.8)
        connection.sendall(
            (
                f"POST {route}?{query} HTTP/1.0\r\nHost: localhost\r\n"
                f"Authorization: Bearer {token}\r\nX-Operator: {principal}\r\n"
                "Content-Type: application/json\r\nContent-Length: 100\r\n\r\n"
            ).encode()
        )
        response = connection.recv(4096)
        assert b" 403 " in response
    assert owner.calls == []


@pytest.mark.parametrize("phase", ["body", "headers"])
def test_slow_drip_has_absolute_budget_and_same_server_recovers(
    scoped, monkeypatch, phase
):
    import time
    from urllib.parse import urlencode
    from enterprise_agent import wechat_source

    monkeypatch.setattr(wechat_source, "REQUEST_READ_SECONDS", 0.4, raising=False)
    get, _, _, config, _ = scoped
    reader = config["native"]["readers"][2]
    query = urlencode(
        dict(
            source="wx-test",
            scope="test-only",
            workspace=reader["workspace"],
            stage="materialize",
            agent="native-parser",
        )
    )
    token = Path(reader["token_file"]).read_text()
    connection = socket.create_connection(
        ("127.0.0.1", config["listen_port"]), timeout=2
    )
    connection.settimeout(2)
    if phase == "body":
        opening = (
            f"POST /native/materializations?{query} HTTP/1.0\r\nHost: localhost\r\n"
            f"Authorization: Bearer {token}\r\nX-Operator: worker\r\n"
            "Content-Type: application/json\r\nContent-Length: 100\r\n\r\n"
        )
    else:
        opening = "GET /native/binding HTTP/1.0\r\nHost: localhost\r\nX-Drip: "
    connection.sendall(opening.encode())

    def drip():
        try:
            for _ in range(12):
                connection.sendall(b" ")
                time.sleep(0.1)
            if phase == "headers":
                connection.sendall(b"\r\n\r\n")
            connection.shutdown(socket.SHUT_WR)
        except OSError:
            pass

    sender = Thread(target=drip, daemon=True)
    started = time.monotonic()
    sender.start()
    try:
        connection.recv(4096)
        assert time.monotonic() - started < 1
    finally:
        connection.close()
        sender.join(timeout=2)
    assert get("/native/binding")[0] == 200
    Path(config["events"]).write_text("")
    assert get.service.collect(config["events"]) == 0


def test_header_budget_is_bounded_and_does_not_count_buffered_body(scoped, monkeypatch):
    from urllib.parse import urlencode
    from enterprise_agent import wechat_source

    get, owner, _, config, _ = scoped
    monkeypatch.setattr(wechat_source, "REQUEST_HEADER_BYTES", 1024)
    reader = config["native"]["readers"][2]
    token = Path(reader["token_file"]).read_text()
    query = urlencode(
        dict(
            source="wx-test",
            scope="test-only",
            workspace=reader["workspace"],
            stage="materialize",
            agent="native-parser",
        )
    )
    body = json.dumps({"not_materialization": "x" * 12000}).encode()
    headers = (
        f"POST /native/materializations?{query} HTTP/1.0\r\nHost: localhost\r\n"
        f"Authorization: Bearer {token}\r\nX-Operator: worker\r\n"
        f"Content-Type: application/json\r\nContent-Length: {len(body)}\r\n\r\n"
    ).encode()
    assert len(headers) < 1024
    with socket.create_connection(
        ("127.0.0.1", config["listen_port"]), timeout=1
    ) as connection:
        connection.sendall(headers + body)
        assert b" 409 " in connection.recv(4096)
    with socket.create_connection(
        ("127.0.0.1", config["listen_port"]), timeout=1
    ) as connection:
        connection.sendall(b"GET /native/binding HTTP/1.0\r\nX-Large: " + b"x" * 2048)
        assert connection.recv(4096) == b""
    assert owner.calls == []
    assert get("/native/binding")[0] == 200


def test_authorized_oversized_body_is_rejected_before_body_io(scoped):
    from urllib.parse import urlencode

    get, owner, _, config, _ = scoped
    reader = config["native"]["readers"][2]
    token = Path(reader["token_file"]).read_text()
    query = urlencode(
        dict(
            source="wx-test",
            scope="test-only",
            workspace=reader["workspace"],
            stage="materialize",
            agent="native-parser",
        )
    )
    with socket.create_connection(
        ("127.0.0.1", config["listen_port"]), timeout=1
    ) as connection:
        connection.sendall(
            (
                f"POST /native/materializations?{query} HTTP/1.0\r\nHost: localhost\r\n"
                f"Authorization: Bearer {token}\r\nX-Operator: worker\r\n"
                "Content-Type: application/json\r\nContent-Length: 33554433\r\n\r\n"
            ).encode()
        )
        assert b" 413 " in connection.recv(4096)
    assert owner.calls == []
    assert get("/native/binding")[0] == 200
