"""Injected Core boundary, real owner HTTP and the existing single-writer Host."""

from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from enterprise_agent.producer import Producer
from enterprise_agent.workflow import Workflow
from test_enterprise_agent_1324 import grant
from test_enterprise_agent_host_1389 import saved_change


def page(items=None, *, previous=None, next_cursor="core:1", page_id="core-page-1"):
    change = saved_change()
    change["source"] = "fixture-payments"
    value = dict(
        page_id=page_id,
        source="fixture-payments",
        scope="finance-read",
        complete_page=True,
        previous_cursor=previous,
        next_cursor=next_cursor,
        gaps=[],
        items=items
        if items is not None
        else [dict(event_id="core-event-1", envelope=change)],
    )
    value["page_sha256"] = sha256(
        json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode()
    ).hexdigest()
    return value


@pytest.fixture
def producer(tmp_path):
    app = Workflow(
        tmp_path / "state.sqlite",
        workspace="test-workspace",
        coordinator="main-agent",
        assistants=["finance-assistant"],
        authorize=grant,
    )
    producer = Producer(app, rule_version="fixture", model_version="none")
    try:
        yield producer
    finally:
        app.close()


def test_native_page_candidates_cursor_and_receipts_commit_together(producer):
    from enterprise_agent.native_ingress import NativeIngress

    class Owner:
        source = "fixture-payments"
        scope = "finance-read"

        def authorize(self, source, stage, agent=None):
            return grant(source, stage, agent)

        def authorize_evidence(self, event, stage, agent=None):
            return grant(event["source"], stage, agent)

        def read_descriptor(self, event, *, include_history=False):
            assert include_history is True
            change = page()["items"][0]["envelope"]
            return dict(
                reference=change["original"],
                version=change["version"],
                projection_hash=change["projection_hash"],
                kind=change["kind"],
                original_available=change.get("original_available", True),
            )

    class Identity:
        def consumer_binding(self):
            return dict(
                endpoint="https://synthetic-core.example.invalid",
                workspace="synthetic-workspace",
                bot_uuid="4f8736ca-57d8-450a-859e-a7ce9e3d34a8",
                source="fixture-payments",
                scope="finance-read",
                flavor="finance",
            )

    ingress = NativeIngress(Owner(), transport=Identity())
    incoming = page()
    producer.prepare("fixture-payments", incoming, native_ingress=ingress)
    state = producer.workflow._read()
    coverage = producer.coverage("fixture-payments")
    assert len(producer.candidates()) == 1
    assert coverage["cursor"] == "core:1"
    assert coverage["native_ingress"]["ack_pending"] is True
    receipts = coverage["native_ingress"]["receipts"]
    assert receipts[0]["event_id"] == "core-event-1"
    assert receipts[0]["source"] == "fixture-payments"
    assert receipts[0]["record"] == incoming["items"][0]["envelope"]["record"]
    assert receipts[0]["version"] == "owner-v1"
    assert receipts[0]["status"] == "accepted"
    assert len(receipts[0]["receipt_id"]) == 64
    producer.prepare("fixture-payments", incoming, native_ingress=ingress)
    assert producer.workflow._read() == state


@pytest.fixture
def core_http():
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from threading import Thread
    from urllib.request import Request, urlopen

    change = saved_change()
    first = dict(
        page_id="page-1",
        source=change["source"],
        scope=change["scope"],
        complete_page=True,
        previous_cursor=None,
        next_cursor="core:1",
        gaps=[],
        items=[dict(event_id="event-1", envelope=change)],
    )
    first["page_sha256"] = sha256(
        json.dumps(
            first, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        ).encode()
    ).hexdigest()
    state = dict(
        page=first,
        reads=0,
        acks=[],
        lookups=[],
        receipts={},
        lose_ack=False,
        unknown_ack=False,
        unknown_lookup=False,
        pages={},
    )

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_POST(self):
            assert self.headers["Authorization"] == "Bearer fake-core-boundary-token"
            body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
            if self.path == "/fixture/read":
                state["reads"] += 1
                value = deepcopy(state["page"])
                if body["cursor"] != state["page"]["previous_cursor"]:
                    value.update(
                        page_id="empty-page",
                        previous_cursor=body["cursor"],
                        next_cursor=body["cursor"],
                        items=[],
                    )
                    value["page_sha256"] = sha256(
                        json.dumps(
                            {k: v for k, v in value.items() if k != "page_sha256"},
                            sort_keys=True,
                            separators=(",", ":"),
                            ensure_ascii=False,
                        ).encode()
                    ).hexdigest()
                state["pages"][value["page_id"]] = deepcopy(value)
            elif self.path == "/fixture/lookup":
                state["lookups"].append(body["event_id"])
                value = (
                    None
                    if state["unknown_lookup"]
                    else state["receipts"].get(body["event_id"])
                )
            else:
                assert self.path == "/fixture/ack"
                known_page = state["pages"][body["page_id"]]
                assert known_page["page_sha256"] == body["page_sha256"]
                state["acks"].append(deepcopy(body))
                for receipt in body["receipts"]:
                    state["receipts"][receipt["event_id"]] = receipt
                if state["lose_ack"]:
                    state["lose_ack"] = False
                    self.connection.close()
                    return
                value = (
                    None
                    if state["unknown_ack"]
                    else dict(
                        page_id=body["page_id"],
                        next_cursor=state.get(
                            "wrong_ack_cursor", known_page["next_cursor"]
                        ),
                        status="accepted",
                    )
                )
            raw = json.dumps(value).encode()
            self.send_response(200)
            self.end_headers()
            self.wfile.write(raw)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()

    class Transport:
        def consumer_binding(self):
            return dict(
                dict(
                    endpoint=f"http://127.0.0.1:{server.server_port}",
                    workspace="synthetic-core-workspace",
                    bot_uuid="4f8736ca-57d8-450a-859e-a7ce9e3d34a8",
                    source="wecom-fixture",
                    scope="finance-read",
                    flavor=state.get("synthetic_flavor", "finance"),
                ),
                **state.get("consumer_override", {}),
            )

        def call(self, route, body):
            request = Request(
                f"http://127.0.0.1:{server.server_port}/fixture/" + route,
                data=json.dumps(body).encode(),
                headers={
                    "Authorization": "Bearer fake-core-boundary-token",
                    "Content-Type": "application/json",
                },
            )
            with urlopen(request, timeout=2) as response:
                return json.loads(response.read())

        def read_router_page(self, cursor, limit, *, authorize):
            value = self.call("read", dict(cursor=cursor, limit=limit))
            for item in value["items"]:
                authorize(item["envelope"])
            return value

        def lookup_router_receipt(self, event_id, *, authorize):
            return self.call("lookup", dict(event_id=event_id))

        def ack_router_page(self, page_id, page_sha256, receipts, *, authorize):
            return self.call(
                "ack", dict(page_id=page_id, page_sha256=page_sha256, receipts=receipts)
            )

    try:
        yield Transport(), state
    finally:
        server.shutdown()
        server.server_close()
        thread.join()


@pytest.fixture
def host_factory(tmp_path, core_http):
    from enterprise_agent.native_ingress import NativeIngress
    from enterprise_agent.host import Host
    from enterprise_agent.source_http import HttpSource, ReadOnlyGd
    from enterprise_agent.producer import ExactGoalRule
    from test_enterprise_agent_host_1389 import owner_server, APPROVED_OWNERS
    from test_enterprise_agent_1324 import Workspace

    transport, core = core_http
    native = Workspace()
    opened = []
    with owner_server() as (base, owner_calls, owner):
        finance = HttpSource(
            base + "/source",
            source="wecom-fixture",
            scope="finance-read",
            workspace="test-workspace",
            principal="fixture-source-reader",
            token="source-fixture-token",
        )
        rule = ExactGoalRule(
            ReadOnlyGd(base + "/mcp", "readonly-mcp-token-0123456789abcdef"),
            version="fixture",
            allowed_owners=APPROVED_OWNERS,
        )

        def descriptor(event):
            matches = [
                c for c in owner["changes"] if c["original"] == event["evidence"]
            ]
            if len(matches) != 1:
                raise ValueError("owner_reference_unavailable")
            change = matches[0]
            return dict(
                reference=change["original"],
                version=change["version"],
                projection_hash=change["projection_hash"],
                kind=change["kind"],
                original_available=change.get("original_available", True),
            )

        def open_host(*, flavor="finance"):
            core["synthetic_flavor"] = flavor
            ingress = NativeIngress(
                finance,
                transport=transport,
                descriptor_reader=descriptor,
                flavor=flavor,
            )
            app = Workflow(
                tmp_path / "host.sqlite",
                workspace="test-workspace",
                coordinator="main-agent",
                assistants=["finance-assistant"],
                authorize=ingress.authorize,
                authorize_evidence=ingress.authorize_evidence,
            )
            producer = Producer(app, rule_version="fixture", model_version="none")
            host = Host(producer, sources=[ingress], workspace=native, admit=rule)
            opened.append((host, app))
            return host, ingress

        try:
            yield open_host, core, native, owner
        finally:
            for host, app in opened:
                if not host._lock.closed:
                    host.close()
                try:
                    app.close()
                except Exception:
                    pass


def step(host):
    from enterprise_agent.host import Limits

    return host.step(now="2026-11-10T00:00:00Z", limits=Limits(seconds=5))


def test_real_fake_core_http_ack_follows_atomic_commit_and_preserves_original_ids(
    host_factory,
):
    open_host, core, native, _ = host_factory
    host, _ = open_host()
    assert step(host)["sources"]["wecom-fixture"] == "success"
    coverage = host.producer.coverage("wecom-fixture")
    assert coverage["native_ingress"]["ack_pending"] is False
    assert core["acks"][0]["receipts"] == coverage["native_ingress"]["receipts"]
    candidate = host.producer.candidates()[0]
    assert candidate["change"] == core["page"]["items"][0]["envelope"]
    assert (
        candidate["change"]["record"] == "msg-17"
        and candidate["change"]["version"] == "owner-v1"
    )
    assert len(native.events) == 1


def test_commit_before_ack_crash_recovers_same_page_without_reprepare_or_duplicate_dispatch(
    host_factory, monkeypatch
):
    open_host, core, native, _ = host_factory
    host, ingress = open_host()

    class Crash(RuntimeError):
        pass

    monkeypatch.setattr(
        ingress,
        "_recover_ack",
        lambda *_: (_ for _ in ()).throw(Crash("after_commit_before_ack")),
    )
    with pytest.raises(Crash):
        step(host)
    assert len(host.producer.candidates()) == 1
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"] is True
    )
    assert not core["acks"] and not native.events
    host.close()
    host.workflow.close()
    restarted, _ = open_host()
    step(restarted)
    assert core["reads"] == 1 and len(native.events) == 1
    assert (
        restarted.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"]
        is False
    )
    step(restarted)
    assert len(native.events) == 1


def test_crash_before_commit_replays_the_entire_page_and_never_acks_rolled_back_candidates(
    host_factory, monkeypatch
):
    from contextlib import contextmanager

    open_host, core, native, _ = host_factory
    host, _ = open_host()
    original = host.workflow._transaction

    class Crash(RuntimeError):
        pass

    @contextmanager
    def fail_prepare():
        with original() as state:
            yield state
            if state["producer"]["candidates"]:
                raise Crash("before_commit")

    monkeypatch.setattr(host.workflow, "_transaction", fail_prepare)
    with pytest.raises(Crash):
        step(host)
    assert host.producer.candidates() == []
    reserved = host.producer.coverage("wecom-fixture")
    assert reserved["cursor"] is None and reserved["status"] == "initialized"
    assert reserved["native_ingress"]["consumer"]["version"] == 1
    assert "receipts" not in reserved["native_ingress"]
    assert "ack_pending" not in reserved["native_ingress"]
    assert not core["acks"] and not native.events
    monkeypatch.setattr(host.workflow, "_transaction", original)
    step(host)
    assert (
        core["reads"] == 2
        and len(host.producer.candidates()) == 1
        and len(native.events) == 1
    )


def test_ack_response_loss_uses_lookup_and_same_receipt_without_repreparing(
    host_factory,
):
    open_host, core, native, _ = host_factory
    core["lose_ack"] = True
    host, _ = open_host()
    step(host)
    pending = host.producer.coverage("wecom-fixture")["native_ingress"]
    assert pending["ack_pending"] is True and len(native.events) == 1
    first = deepcopy(core["acks"][0])
    host.close()
    host.workflow.close()
    restarted, _ = open_host()
    step(restarted)
    assert core["reads"] == 1 and core["acks"][1] == first
    assert core["lookups"] == ["event-1", "event-1"]
    assert (
        restarted.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"]
        is False
    )
    assert len(native.events) == 1


def test_lookup_unknown_or_existing_event_receipt_never_substitutes_for_page_ack(
    host_factory,
):
    open_host, core, native, _ = host_factory
    host, _ = open_host()
    core.update(unknown_ack=True, unknown_lookup=True)
    step(host)
    step(host)
    assert core["reads"] == 1 and len(core["acks"]) == 2
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"] is True
    )
    core["unknown_lookup"] = False
    step(host)
    assert (
        core["reads"] == 1
        and host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"]
        is True
    )
    core["unknown_ack"] = False
    step(host)
    assert (
        core["reads"] == 1
        and host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"]
        is False
    )
    assert len(native.events) == 1


def test_native_poll_uses_the_same_host_lock_and_never_starts_another_writer(
    host_factory,
):
    import fcntl

    open_host, core, _, _ = host_factory
    first, _ = open_host()
    second, _ = open_host()
    fcntl.flock(first._lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    try:
        assert step(second) == dict(status="busy")
        assert core["reads"] == 0 and not core["acks"]
    finally:
        fcntl.flock(first._lock, fcntl.LOCK_UN)


def resign(value):
    from enterprise_agent.native_ingress import sourcepage_digest

    value["page_sha256"] = sourcepage_digest(value)
    return value


@pytest.mark.parametrize(
    "fault", ["hash", "scope", "version", "descriptor_hash", "kind"]
)
def test_unbound_or_owner_unproven_page_never_commits_or_acks(host_factory, fault):
    open_host, core, _, _ = host_factory
    incoming = core["page"]
    change = incoming["items"][0]["envelope"]
    if fault == "hash":
        incoming["page_sha256"] = "0" * 64
    elif fault == "scope":
        incoming["scope"] = "unapproved-scope"
        resign(incoming)
    elif fault == "version":
        change["version"] = "forged-version"
        change["saved"]["version"] = "forged-version"
        resign(incoming)
    elif fault == "descriptor_hash":
        change["projection_hash"] = "c" * 64
        resign(incoming)
    elif fault == "kind":
        change["kind"] = "baseline"
        resign(incoming)
    else:
        change["original_available"] = False
        resign(incoming)
    host, _ = open_host()
    step(host)
    assert host.producer.candidates() == []
    assert not core["acks"]
    assert host.producer.coverage("wecom-fixture").get("cursor") is None


@pytest.mark.parametrize("fault", ["payload", "event_rebinding"])
def test_accepted_event_identity_and_payload_cannot_change_on_another_page(
    host_factory, fault
):
    open_host, core, native, owner = host_factory
    host, _ = open_host()
    step(host)
    incoming = deepcopy(core["page"])
    incoming.update(page_id="page-2", previous_cursor="core:1", next_cursor="core:2")
    if fault == "payload":
        incoming["items"][0]["envelope"]["saved"]["message"]["sender_user_id"] = (
            "another-sender"
        )
    else:
        incoming["items"][0]["event_id"] = "different-event-for-same-source-version"
    core["page"] = resign(incoming)
    step(host)
    assert host.producer.coverage("wecom-fixture")["cursor"] == "core:1"
    assert len(core["acks"]) == 1 and len(native.events) == 1
    assert len(host.producer.candidates()) == 1


@pytest.mark.parametrize("state", ["pending", "unknown_sender", "recalled"])
def test_pending_unknown_sender_and_recall_are_retained_without_new_dispatch(
    host_factory, state
):
    open_host, core, native, owner = host_factory
    host, _ = open_host()
    if state == "recalled":
        step(host)
        incoming = deepcopy(core["page"])
        change = incoming["items"][0]["envelope"]
        incoming.update(
            page_id="page-2", previous_cursor="core:1", next_cursor="core:2"
        )
        incoming["items"][0]["event_id"] = "event-recall-2"
        change.update(
            kind="recalled",
            version="owner-v2",
            sequence=2,
            original="wecom:message/msg-17/owner-v2",
            original_available=False,
        )
        change["saved"].update(
            version=change["version"], sequence=2, original=change["original"]
        )
        change["saved"]["message"].update(
            action="recall", message_type="revoke", recalled_message_id="msg-17"
        )
    else:
        incoming = deepcopy(core["page"])
        change = incoming["items"][0]["envelope"]
        if state == "pending":
            change["original_available"] = False
        else:
            change["saved"]["message"]["sender_identity_type"] = "UNKNOWN"
    core["page"] = resign(incoming)
    owner["changes"] = [deepcopy(change)]
    step(host)
    candidate = next(
        c
        for c in host.producer.candidates()
        if c["change"]["version"] == change["version"]
    )
    assert candidate["change"] == change
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"]
        is False
    )
    assert core["acks"][-1]["receipts"][0]["status"] == "accepted"
    assert len(native.events) == (1 if state == "recalled" else 0)
    if state == "recalled":
        assert host.workflow.matters()[0]["status"] == "recorded"


def test_receipt_lookup_conflict_never_gets_acked_or_fetches_another_page(host_factory):
    open_host, core, _, _ = host_factory
    core["unknown_ack"] = True
    host, _ = open_host()
    step(host)
    receipt = core["receipts"]["event-1"]
    receipt["receipt_id"] = "0" * 64
    step(host)
    assert core["reads"] == 1 and len(core["acks"]) == 1
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"] is True
    )


def test_owner_historical_metadata_can_only_downgrade_core_availability(host_factory):
    open_host, core, native, owner = host_factory
    old = deepcopy(core["page"]["items"][0]["envelope"])
    old["original_available"] = False
    owner["changes"] = [old]
    owner["current_references"] = []  # Its original body is no longer current.
    host, _ = open_host()
    step(host)
    assert host.producer.candidates()[0]["change"]["original_available"] is False
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"]
        is False
    )
    assert not native.events
    assert core["page"]["items"][0]["envelope"].get("original_available", True) is True
    assert core["acks"][0]["receipts"][0]["status"] == "accepted"


def test_core_unavailable_is_not_upgraded_by_current_owner_descriptor(host_factory):
    open_host, core, native, owner = host_factory
    core["page"]["items"][0]["envelope"]["original_available"] = False
    resign(core["page"])
    assert owner["changes"][0].get("original_available", True) is True
    host, _ = open_host()
    step(host)
    assert host.producer.candidates()[0]["change"]["original_available"] is False
    assert not native.events


def test_accepted_old_reference_can_ack_after_restart_without_starving_the_recall_page(
    host_factory,
):
    from enterprise_agent.source_http import SourceUnavailable
    from test_enterprise_agent_1324 import response

    open_host, core, native, owner = host_factory
    core["lose_ack"] = True
    host, ingress = open_host()
    step(host)
    old_state = host.workflow._read()
    old_event = next(iter(old_state["matters"].values()))["event"]
    old_action = next(iter(old_state["outbox"].values()))
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"] is True
    )
    recall = deepcopy(core["page"])
    change = recall["items"][0]["envelope"]
    recall.update(page_id="recall-page", previous_cursor="core:1", next_cursor="core:2")
    recall["items"][0]["event_id"] = "recall-event"
    change.update(
        kind="recalled",
        version="owner-v2",
        sequence=2,
        original="wecom:message/msg-17/owner-v2",
        original_available=False,
    )
    change["saved"].update(
        version=change["version"], sequence=2, original=change["original"]
    )
    change["saved"]["message"].update(
        action="recall", message_type="revoke", recalled_message_id="msg-17"
    )
    core["page"] = resign(recall)
    owner["changes"] = [deepcopy(change)]  # No old current descriptor is available.
    owner["current_references"] = [change["original"]]
    with pytest.raises(SourceUnavailable):
        ingress.read_original(old_event, agent="finance-assistant")
    with pytest.raises(ValueError):
        host.workflow.receive(
            response(
                old_action, '{"decision":"delegate","assistant":"finance-assistant"}'
            )
        )
    host.close()
    host.workflow.close()
    restarted, _ = open_host()
    step(restarted)
    assert core["reads"] == 1  # Recover the committed old page first, without repull.
    assert (
        restarted.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"]
        is False
    )
    assert len(native.events) == 1
    step(restarted)
    assert core["reads"] == 2
    assert restarted.producer.coverage("wecom-fixture")["cursor"] == "core:2"
    assert restarted.workflow.matters()[0]["status"] == "recorded"
    assert len(native.events) == 1
    assert {receipt["version"] for receipt in core["receipts"].values()} == {
        "owner-v1",
        "owner-v2",
    }


def test_true_idle_is_not_persisted_or_acked_and_restart_can_receive_a_new_message(
    host_factory,
):
    open_host, core, native, _ = host_factory
    initial = deepcopy(core["page"])
    core["page"].update(page_id="idle-0", items=[], next_cursor="0")
    resign(core["page"])
    host, _ = open_host()
    step(host)
    assert not core["acks"] and not native.events
    coverage = host.producer.coverage("wecom-fixture")
    assert coverage["cursor"] == "0"
    assert coverage["native_ingress"]["source"] == "wecom-fixture"
    assert coverage["native_ingress"]["scope"] == "finance-read"
    assert "ack_pending" not in coverage["native_ingress"]
    host.close()
    host.workflow.close()
    restarted, _ = open_host()
    step(restarted)
    assert not core["acks"]
    initial.update(previous_cursor="0", next_cursor="core:1")
    core["page"] = resign(initial)
    step(restarted)
    assert len(core["acks"]) == 1 and len(native.events) == 1


def gap_page(core):
    value = deepcopy(core["page"])
    value.update(
        page_id="gap-page",
        items=[],
        gaps=[
            dict(
                event_id="gap-event",
                reason="native_unresolved",
                source="wecom-fixture",
                scope="finance-read",
            )
        ],
    )
    return resign(value)


def test_gap_only_needs_page_ack_and_gap_audit_survives_good_pages_and_idle(
    host_factory,
):
    open_host, core, native, _ = host_factory
    original = deepcopy(core["page"])
    core["page"] = gap_page(core)
    host, _ = open_host()
    step(host)
    coverage = host.producer.coverage("wecom-fixture")
    assert len(core["acks"]) == 1 and core["acks"][0]["receipts"] == []
    assert host.producer.candidates() == []
    assert coverage["status"] == "missing_page"
    assert (
        coverage["native_ingress"]["gap_audit"]["gap-event"]["status"] == "unresolved"
    )
    assert (
        len(coverage["gaps"]) == 1
        and isinstance(coverage["gaps"][0], str)
        and len(coverage["gaps"][0]) <= 200
    )
    original.update(page_id="good-page", previous_cursor="core:1", next_cursor="core:2")
    core["page"] = resign(original)
    step(host)
    after = host.producer.coverage("wecom-fixture")
    assert after["gaps"] == coverage["gaps"] and after["status"] == "missing_page"
    assert len(native.events) == 1
    step(host)
    idle = host.producer.coverage("wecom-fixture")
    assert idle["gaps"] == coverage["gaps"] and idle["status"] == "missing_page"
    assert len(core["acks"]) == 2


def test_pending_zero_receipt_page_has_a_persisted_scope_fence(host_factory):
    open_host, core, _, _ = host_factory
    core["page"] = gap_page(core)
    core["unknown_ack"] = True
    host, ingress = open_host()
    step(host)
    pending = host.producer.coverage("wecom-fixture")["native_ingress"]
    assert pending["source"] == "wecom-fixture" and pending["scope"] == "finance-read"
    assert pending["ack_pending"] is True and pending["receipts"] == []
    ingress.scope = "another-scope"
    core["unknown_ack"] = False
    before = len(core["acks"])
    step(host)
    assert len(core["acks"]) == before
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"] is True
    )


@pytest.mark.parametrize(
    "fault", ["cross_item_gap", "duplicate_gap", "wrong_gap_scope", "combined_limit"]
)
def test_native_gap_event_ids_scope_and_combined_limit_are_strict(host_factory, fault):
    open_host, core, _, _ = host_factory
    value = gap_page(core)
    if fault in {"cross_item_gap", "combined_limit"}:
        value["items"] = deepcopy(core["page"]["items"])
        if fault == "cross_item_gap":
            value["gaps"][0]["event_id"] = value["items"][0]["event_id"]
    elif fault == "duplicate_gap":
        value["gaps"].append(deepcopy(value["gaps"][0]))
    else:
        value["gaps"][0]["scope"] = "wrong-scope"
    core["page"] = resign(value)
    host, _ = open_host()
    if fault == "combined_limit":
        from enterprise_agent.host import Limits

        host.step(now="2026-11-10T00:00:00Z", limits=Limits(page_size=1, seconds=5))
    else:
        step(host)
    assert host.producer.candidates() == [] and not core["acks"]


def test_wrong_page_cursor_ack_never_clears_pending_even_when_event_lookup_is_accepted(
    host_factory,
):
    open_host, core, _, _ = host_factory
    core["wrong_ack_cursor"] = "another-cursor"
    host, _ = open_host()
    step(host)
    assert core["receipts"]["event-1"]["status"] == "accepted"
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"] is True
    )
    step(host)
    assert core["reads"] == 1
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"] is True
    )
    core.pop("wrong_ack_cursor")
    step(host)
    assert (
        host.producer.coverage("wecom-fixture")["native_ingress"]["ack_pending"]
        is False
    )


def test_idle_null_next_cursor_is_not_accepted_as_an_initialized_core_cursor(
    host_factory,
):
    open_host, core, _, _ = host_factory
    core["page"].update(items=[], gaps=[], next_cursor=None)
    resign(core["page"])
    host, _ = open_host()
    step(host)
    assert (
        not core["acks"]
        and host.producer.coverage("wecom-fixture").get("cursor") is None
    )


def test_native_ingress_never_reuses_a_legacy_finance_cursor(host_factory):
    open_host, core, _, _ = host_factory
    host, _ = open_host()
    change = deepcopy(core["page"]["items"][0]["envelope"])
    host.producer.prepare(
        "wecom-fixture",
        dict(
            source="wecom-fixture",
            scope="finance-read",
            complete_page=True,
            previous_cursor=None,
            next_cursor="finance-owner:8",
            gaps=[],
            items=[change],
        ),
    )
    step(host)
    assert core["reads"] == 0 and not core["acks"]
    assert host.producer.coverage("wecom-fixture")["cursor"] == "finance-owner:8"


def test_a_gap_is_only_resolved_by_the_same_owner_proven_event_and_keeps_audit_history(
    host_factory,
):
    open_host, core, _, _ = host_factory
    good = deepcopy(core["page"])
    core["page"] = gap_page(core)
    host, _ = open_host()
    step(host)
    before = host.producer.coverage("wecom-fixture")["native_ingress"]["gap_audit"][
        "gap-event"
    ]
    good.update(page_id="resolved-page", previous_cursor="core:1", next_cursor="core:2")
    good["items"][0]["event_id"] = "gap-event"
    core["page"] = resign(good)
    step(host)
    after = host.producer.coverage("wecom-fixture")
    audit = after["native_ingress"]["gap_audit"]["gap-event"]
    assert audit["first_page_id"] == before["first_page_id"]
    assert audit["first_page_sha256"] == before["first_page_sha256"]
    assert audit["status"] == "accepted_metadata"
    assert audit["receipt_id"] == core["receipts"]["gap-event"]["receipt_id"]
    assert after["gaps"] == []


@pytest.mark.parametrize(
    "flavor,code",
    [
        ("finance", "history_before_feed_unverified"),
        ("finance", "original_unavailable"),
        ("native_wechat", "history_before_activation_unverified"),
        ("native_wechat", "original_unavailable"),
    ],
)
def test_owner_source_gap_codes_are_selected_by_trusted_flavor(flavor, code):
    from enterprise_agent.native_ingress import validate_page

    incoming = page(items=[])
    incoming["gaps"] = [
        dict(
            event_id="owner-gap",
            reason="owner_source_gap",
            source="fixture-payments",
            scope="finance-read",
            code=code,
        )
    ]
    resign(incoming)
    assert (
        validate_page(
            incoming,
            source="fixture-payments",
            scope="finance-read",
            previous_cursor=None,
            flavor=flavor,
        )
        == incoming
    )


@pytest.mark.parametrize(
    "flavor,code",
    [
        ("finance", "history_before_activation_unverified"),
        ("native_wechat", "history_before_feed_unverified"),
        ("finance", "arbitrary-owner-text"),
        ("native_wechat", "everything_is_fine"),
    ],
)
def test_wrong_flavor_or_unknown_owner_gap_code_cannot_be_treated_as_complete(
    flavor, code
):
    from enterprise_agent.native_ingress import validate_page

    incoming = page(items=[])
    incoming["gaps"] = [
        dict(
            event_id="owner-gap",
            reason="owner_source_gap",
            source="fixture-payments",
            scope="finance-read",
            code=code,
        )
    ]
    resign(incoming)
    with pytest.raises(ValueError):
        validate_page(
            incoming,
            source="fixture-payments",
            scope="finance-read",
            previous_cursor=None,
            flavor=flavor,
        )


def test_owner_source_gap_good_idle_same_database_reopen_keeps_audit_and_dispatches_only_new_message(
    host_factory,
):
    open_host, core, native, owner = host_factory
    first_good = deepcopy(core["page"])
    core["page"] = gap_page(core)
    core["page"]["gaps"][0].update(
        reason="owner_source_gap", code="original_unavailable"
    )
    resign(core["page"])
    host, _ = open_host()
    step(host)
    initial = deepcopy(host.producer.coverage("wecom-fixture"))
    assert (
        initial["native_ingress"]["gap_audit"]["gap-event"]["code"]
        == "original_unavailable"
    )
    first_good.update(
        page_id="good-before-reopen", previous_cursor="core:1", next_cursor="core:2"
    )
    core["page"] = resign(first_good)
    step(host)
    step(host)
    assert len(native.events) == 1
    assert len(core["acks"]) == 2
    before_reopen = deepcopy(host.producer.coverage("wecom-fixture"))
    host.close()
    host.workflow.close()
    reopened, _ = open_host()
    step(reopened)
    after_reopen = reopened.producer.coverage("wecom-fixture")
    assert after_reopen["gaps"] == initial["gaps"] == before_reopen["gaps"]
    assert (
        after_reopen["native_ingress"]["gap_audit"]
        == before_reopen["native_ingress"]["gap_audit"]
    )
    assert after_reopen["status"] == "missing_page"
    assert len(core["acks"]) == 2 and len(native.events) == 1
    new = deepcopy(first_good["items"][0]["envelope"])
    new.update(
        record="msg-new",
        version="owner-v2",
        sequence=2,
        original="wecom:message/msg-new/owner-v2",
    )
    new["saved"].update(version=new["version"], sequence=2, original=new["original"])
    new["saved"]["message"]["message_id"] = "msg-new"
    next_page = deepcopy(first_good)
    next_page.update(
        page_id="good-after-reopen",
        previous_cursor="core:2",
        next_cursor="core:3",
        items=[dict(event_id="event-new", envelope=new)],
    )
    core["page"] = resign(next_page)
    owner["changes"].append(deepcopy(new))
    step(reopened)
    step(reopened)
    assert len(native.events) == 2 and len(core["acks"]) == 3
    final = reopened.producer.coverage("wecom-fixture")
    assert final["gaps"] == initial["gaps"] and final["status"] == "missing_page"
    assert "gap-event" not in core["receipts"]


def test_native_wechat_owner_gap_flavor_is_enforced_by_poll_and_persisted_across_rebuild(
    host_factory,
):
    open_host, core, _, _ = host_factory
    core["page"] = gap_page(core)
    core["page"]["gaps"][0].update(
        reason="owner_source_gap", code="history_before_activation_unverified"
    )
    resign(core["page"])
    host, _ = open_host(flavor="native_wechat")
    step(host)
    coverage = host.producer.coverage("wecom-fixture")
    assert coverage["native_ingress"]["flavor"] == "native_wechat"
    assert (
        coverage["native_ingress"]["gap_audit"]["gap-event"]["code"]
        == "history_before_activation_unverified"
    )
    host.close()
    host.workflow.close()
    wrong, _ = open_host(flavor="finance")
    before = core["reads"]
    step(wrong)
    assert core["reads"] == before


@pytest.mark.parametrize(
    "previous,next_cursor", [(None, "core:999"), ("core:1", "core:999")]
)
def test_idle_cannot_advance_or_invent_the_core_cursor_even_with_a_valid_page_digest(
    previous, next_cursor
):
    from enterprise_agent.native_ingress import validate_page

    incoming = page(items=[], previous=previous, next_cursor=next_cursor)
    with pytest.raises(ValueError, match="invalid_native_ingress_page"):
        validate_page(
            incoming,
            source="fixture-payments",
            scope="finance-read",
            previous_cursor=previous,
        )


@pytest.mark.parametrize("mode", ["pending", "idle"])
@pytest.mark.parametrize(
    "field,value",
    [
        ("endpoint", "https://another-core.example.invalid"),
        ("workspace", "other-core-workspace"),
        ("bot_uuid", "854c9117-ef1a-4abb-969f-6252f86c0be9"),
    ],
)
def test_same_database_reopen_in_another_consumer_domain_never_reads_or_acks_core(
    host_factory, mode, field, value
):
    open_host, core, _, _ = host_factory
    if mode == "pending":
        core["unknown_ack"] = True
    else:
        core["page"].update(items=[], gaps=[], next_cursor="0")
        resign(core["page"])
    host, _ = open_host()
    step(host)
    before = deepcopy(host.workflow._read())
    counts = (core["reads"], len(core["acks"]), len(core["lookups"]))
    host.close()
    host.workflow.close()
    core["consumer_override"] = {field: value}
    restarted, ingress = open_host()
    with pytest.raises(ValueError, match="native_consumer"):
        ingress.poll(restarted.producer, limit=100)
    assert restarted.workflow._read() == before
    assert (core["reads"], len(core["acks"]), len(core["lookups"])) == counts


def test_legacy_native_state_without_consumer_identity_requires_explicit_migration(
    host_factory,
):
    open_host, core, _, _ = host_factory
    host, ingress = open_host()
    step(host)
    with host.workflow._transaction() as state:
        state["producer"]["coverage"]["wecom-fixture"]["native_ingress"].pop(
            "consumer", None
        )
    legacy = deepcopy(host.workflow._read())
    count = core["reads"]
    with pytest.raises(ValueError, match="native_consumer"):
        ingress.poll(host.producer, limit=100)
    assert host.workflow._read() == legacy and core["reads"] == count


def test_host_reports_consumer_mismatch_before_scheduler_or_coverage_writes(
    host_factory,
):
    open_host, core, _, _ = host_factory
    core["unknown_ack"] = True
    host, _ = open_host()
    step(host)
    before = deepcopy(host.workflow._read())
    counts = (core["reads"], len(core["acks"]), len(core["lookups"]))
    host.close()
    host.workflow.close()
    core["consumer_override"] = {"workspace": "other-core-workspace"}
    restarted, _ = open_host()
    result = step(restarted)
    assert result["sources"]["wecom-fixture"] == "native_consumer_conflict"
    assert restarted.workflow._read() == before
    assert (core["reads"], len(core["acks"]), len(core["lookups"])) == counts


def test_missing_consumer_identity_and_owner_denial_never_reserve_a_domain(producer):
    from enterprise_agent.native_ingress import NativeIngress

    class Owner:
        source = "fixture-payments"
        scope = "finance-read"

        def authorize(self, *_):
            raise ValueError("owner_denied")

    class Missing:
        pass

    before = deepcopy(producer.workflow._read())
    with pytest.raises(ValueError, match="native_consumer_identity_required"):
        NativeIngress(Owner(), transport=Missing()).poll(producer, limit=100)

    class Identity:
        def consumer_binding(self):
            return dict(
                endpoint="https://synthetic-core.example.invalid",
                workspace="synthetic-workspace",
                bot_uuid="4f8736ca-57d8-450a-859e-a7ce9e3d34a8",
                source="fixture-payments",
                scope="finance-read",
                flavor="finance",
            )

    with pytest.raises(ValueError, match="owner_denied"):
        NativeIngress(Owner(), transport=Identity()).poll(producer, limit=100)
    assert producer.workflow._read() == before


def test_a_legacy_coverage_row_without_any_native_fence_cannot_be_bootstrapped(
    producer,
):
    from enterprise_agent.native_ingress import NativeIngress

    class Identity:
        def consumer_binding(self):
            return dict(
                endpoint="https://synthetic-core.example.invalid",
                workspace="synthetic-workspace",
                bot_uuid="4f8736ca-57d8-450a-859e-a7ce9e3d34a8",
                source="fixture-payments",
                scope="finance-read",
                flavor="finance",
            )

    class Owner:
        source = "fixture-payments"
        scope = "finance-read"

    producer.record_coverage("fixture-payments", "disabled")
    before = deepcopy(producer.workflow._read())
    with pytest.raises(ValueError, match="native_consumer_migration_required"):
        NativeIngress(Owner(), transport=Identity()).poll(producer, limit=100)
    assert producer.workflow._read() == before


@pytest.mark.parametrize("initialized", [False, True])
def test_host_idle_jump_rejection_never_advances_persisted_cursor_or_creates_ack(
    host_factory, initialized
):
    open_host, core, _, _ = host_factory
    host, _ = open_host()
    if initialized:
        core["page"].update(items=[], gaps=[], next_cursor="0")
        resign(core["page"])
        step(host)
    before_cursor = (host.producer.coverage("wecom-fixture") or {}).get("cursor")
    core["page"].update(
        page_id="forged-idle",
        previous_cursor=before_cursor,
        next_cursor="core:999",
        items=[],
        gaps=[],
    )
    resign(core["page"])
    step(host)
    after = host.producer.coverage("wecom-fixture")
    assert after["cursor"] == before_cursor
    assert "ack_pending" not in after["native_ingress"]
    assert "receipts" not in after["native_ingress"]
    assert host.producer.candidates() == [] and core["acks"] == []
