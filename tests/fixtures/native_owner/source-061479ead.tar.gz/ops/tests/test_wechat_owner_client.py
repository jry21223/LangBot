"""Bounded owner reads over the existing wx API, using synthetic HTTP only."""

from hashlib import sha256
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
from threading import Thread

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture
def owner(tmp_path):
    data = b"cached-image-fixture"
    asset = dict(
        id="asset-1",
        accountId="account-1",
        messageId="msg-1",
        kind="image",
        state="available",
        sha256=sha256(data).hexdigest(),
        byteLength=len(data),
        contentType="image/png",
    )
    message = dict(
        id="msg-1",
        accountId="account-1",
        threadId="test@chatroom",
        senderId="sender",
        serverId="77",
        direction="incoming",
        version="native-v1",
        type=3,
        body="<xml/>",
        recall=None,
        createdAt="2026-11-08T00:00:00Z",
    )
    state = dict(
        message=message, asset=asset, data=data, calls=[], mutate_after_content=False
    )

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            state["calls"].append(self.path)
            assert (
                self.headers["Authorization"]
                == "Bearer synthetic-owner-token-0123456789"
            )
            if self.path.endswith("/accounts/account-1"):
                value = state.get(
                    "account",
                    dict(
                        id="account-1",
                        authenticated=True,
                        contactSyncReady=True,
                        connection="online",
                        incomingTransport="native_push",
                        nickname="PRIVATE-NAME",
                    ),
                )
            elif self.path.endswith("/messages/msg-1"):
                value = state["message"]
            elif self.path.endswith("/messages/msg-1/media"):
                value = {"items": [state["asset"]]}
            elif self.path.endswith("/media/asset-1"):
                value = state["asset"]
            elif self.path.endswith("/media/asset-1/content"):
                raw = state["data"]
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                if state.get("generation_after_content"):
                    state["message"] = dict(state["message"], version="generation-2")
                if state["mutate_after_content"]:
                    state["message"] = dict(
                        state["message"],
                        version="native-v2",
                        type=10000,
                        recall={"observedAt": "2026-11-08T00:00:03Z"},
                    )
                return
            else:
                self.send_error(404)
                return
            raw = json.dumps(value).encode()
            self.send_response(200)
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    token = tmp_path / "owner-token"
    token.write_text("synthetic-owner-token-0123456789")
    token.chmod(0o600)
    from enterprise_agent.wechat_owner_client import WxOwnerClient

    client = WxOwnerClient(
        f"http://127.0.0.1:{server.server_port}/v1",
        token_file=str(token),
        account="account-1",
        thread="test@chatroom",
    )
    yield client, state, token
    server.shutdown()
    server.server_close()
    thread.join()


def test_exact_owner_cached_media_and_normalized_native_message(owner):
    client, state, _ = owner
    message = client.message("msg-1")
    assert (
        message["account_id"] == "account-1" and message["thread_id"] == "test@chatroom"
    )
    assert (
        message["native_version"] == "native-v1" and message["message_type"] == "image"
    )
    assert client.media("msg-1", message["media"][0]) == state["data"]
    assert all("/v1/accounts/account-1/" in p for p in state["calls"])
    assert not any("/consumers/" in p or "/sends" in p for p in state["calls"])


def test_wrong_thread_is_rejected_before_asset_lookup(owner):
    client, state, _ = owner
    state["message"]["threadId"] = "private-other@chatroom"
    with pytest.raises(ValueError, match="owner_unavailable"):
        client.message("msg-1")
    assert state["calls"] == ["/v1/accounts/account-1/messages/msg-1"]


@pytest.mark.parametrize(
    "fault", ["asset_binding", "content_hash", "recalled_after", "credential_rotation"]
)
def test_owner_drift_or_bad_media_never_returns_bytes(owner, fault):
    client, state, token = owner
    expected = client.message("msg-1")["media"][0]
    if fault == "asset_binding":
        state["asset"]["messageId"] = "another"
    elif fault == "content_hash":
        state["data"] = b"tampered"
    elif fault == "recalled_after":
        state["mutate_after_content"] = True
    else:
        token.write_text("rotated-owner-token-0123456789")
    with pytest.raises(ValueError, match="owner_unavailable"):
        client.media("msg-1", expected)


def test_unrelated_profile_generation_does_not_invalidate_same_media(owner):
    client, state, _ = owner
    expected = client.message("msg-1")["media"][0]
    state["generation_after_content"] = True
    assert client.media("msg-1", expected) == state["data"]
    assert state["message"]["version"] == "generation-2"


def test_status_uses_fresh_runtime_facts_and_never_returns_name(owner):
    client, state, _ = owner
    facts = client.status()
    assert facts["account"] == "account-1"
    assert facts["authenticated"] is True and facts["connection"] == "online"
    assert set(facts) == {
        "account",
        "authenticated",
        "connection",
        "incoming_transport",
        "contact_sync_ready",
        "observed_at",
    }
    state["account"] = {"id": "account-1", "authenticated": True}
    assert client.status() is None
    state["account"] = dict(
        id="other-account",
        authenticated=True,
        contactSyncReady=True,
        connection="online",
        incomingTransport="native_push",
    )
    assert client.status() is None


def test_missing_generation_and_malformed_asset_fail_closed(owner):
    client, state, _ = owner
    state["message"]["version"] = None
    with pytest.raises(ValueError, match="owner_unavailable"):
        client.message("msg-1")
    state["message"]["version"] = "g1"
    state["asset"]["state"] = []
    with pytest.raises(ValueError, match="owner_unavailable"):
        client.message("msg-1")


def test_native_recall_tombstone_accepts_nullable_facts_and_ignores_observed_time(
    owner,
):
    client, state, _ = owner
    state["message"].update(
        type=10000,
        direction=None,
        createdAt=None,
        senderId=None,
        serverId=None,
        body=None,
        recall={"observedAt": "2026-11-08T00:00:00Z"},
    )
    before = client.message("msg-1")
    state["message"]["recall"]["observedAt"] = "2026-11-08T00:01:00Z"
    after = client.message("msg-1")
    assert before == after
    assert before["recalled"] is True and before["direction"] is None
    assert before["body"] is None and before["business_at"] is None
    assert before["media"] == []
    assert not any(p.endswith("/media") for p in state["calls"])


def test_system_notice_type_alone_does_not_establish_recall(owner):
    client, state, _ = owner
    state["message"].update(
        type=10000, direction=None, body="ordinary system notice", recall=None
    )
    message = client.message("msg-1")
    assert message["message_type"] == "unsupported" and message["recalled"] is False
    assert message["media"] == []
    assert not any(path.endswith("/media") for path in state["calls"])


@pytest.mark.parametrize(
    "recall",
    [
        {},
        {"observedAt": "now"},
        {"observedAt": 42},
        {"observedAt": "2026-11-08T00:00:02Z", "target": "other-message"},
        {"observedAt": "2026-11-08T00:00:02Z", "recalledAt": "not-a-date"},
        {"observedAt": "2026-11-08T00:00:02Z", "replacementText": []},
        {"observedAt": "2026-11-08T00:00:02Z", "replacementText": "x" * 16385},
    ],
)
def test_malformed_or_invented_recall_marker_never_confirms_tombstone(owner, recall):
    client, state, _ = owner
    state["message"].update(type=10000, direction=None, recall=recall)
    with pytest.raises(ValueError, match="owner_unavailable"):
        client.message("msg-1")
    assert not any(path.endswith("/media") for path in state["calls"])


@pytest.mark.parametrize(
    "field,value",
    [
        ("id", "other-message"),
        ("accountId", "other-account"),
        ("threadId", "other@chatroom"),
    ],
)
def test_recall_marker_must_be_bound_to_requested_message_account_and_thread(
    owner, field, value
):
    client, state, _ = owner
    state["message"].update(
        type=10000, direction=None, recall={"observedAt": "2026-11-08T00:00:02Z"}
    )
    state["message"][field] = value
    with pytest.raises(ValueError, match="owner_unavailable"):
        client.message("msg-1")


def test_recall_marker_on_non_system_native_type_is_rejected(owner):
    client, state, _ = owner
    state["message"]["recall"] = {"observedAt": "2026-11-08T00:00:02Z"}
    with pytest.raises(ValueError, match="owner_unavailable"):
        client.message("msg-1")
