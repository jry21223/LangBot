from pathlib import Path
import sys

import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from enterprise_agent.wechat_native_projection import SavedNativeWechat
from enterprise_agent.wechat_native_store import NativeWechatStore

NOW='2026-11-08T03:00:00Z'


def candidate(tmp_path, kind='image', baseline=False, recalled=False):
    source=NativeWechatStore(tmp_path/'source.sqlite',account='a',thread='t',source='wx',scope='test',parser_version='pin-v1')
    message=dict(account_id='a',thread_id='t',message_id='m',sender_id='s',server_id='1',message_type=kind,
                 direction='incoming',native_version='n1',body='text',media=[],recalled=recalled,business_at=NOW)
    item=source.commit_native(message,event_cursor='1',observed_at=NOW,baseline=baseline)
    source.close()
    return dict(source='wx',scope='test',change=item['change'])


def selection():
    return dict(goal='observation:test',confirmed=True,intent='action',candidates=[])


def test_pending_native_image_is_not_text_or_completed_analysis(tmp_path):
    c=candidate(tmp_path)
    result=SavedNativeWechat().project(c,selection())
    assert result['evidence'].startswith('wechat-native:message/')
    assert result['evidence_details']['message_type']=='image'
    assert result['review_required'] is True and result['confirmed'] is False
    assert result['approval_status']=='not_applicable'


def test_baseline_does_not_dispatch_and_recall_is_owner_cancellation_state(tmp_path):
    c=candidate(tmp_path,'text',baseline=True)
    result=SavedNativeWechat().project(c,selection())
    assert result['intent']=='reference' and result['confirmed'] is False
    c['change']['kind']='recalled'
    c['change']['original_available']=False
    c['change']['saved']['body_available']=False
    assert SavedNativeWechat().owner_state(c)==dict(recalled=True,incomplete=True)


def test_native_reference_cannot_be_read_as_the_legacy_journal(tmp_path):
    c=candidate(tmp_path,'text')
    c['change']['original']=c['change']['original'].replace('wechat-native:', 'wechat:')
    with pytest.raises(ValueError,match='invalid_saved_native_wechat'):
        SavedNativeWechat().project(c,selection())
