"""Owner metadata is authenticated independently of a cached ingress page."""
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
import sys
from threading import Thread
from urllib.parse import parse_qs, urlsplit

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from enterprise_agent.source_http import HttpSource, SourceUnavailable


@pytest.fixture
def owner():
    event = dict(source="finance", scope="test-chat", version="wr-2", evidence="wecom:message/abc/wr-2")
    grant = dict(source="finance", scope="test-chat", principal="owner-reader", workspace="oa-workspace",
                 revision="grant-1", active=True, read_only=True, workspace_allowed=True, agent=None)
    state = dict(descriptor=dict(reference=event["evidence"], version="wr-2", projection_hash="a" * 64,
                                 kind="changed", original_available=False), calls=[], revision="grant-1", rotate=False)

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_):
            pass

        def do_GET(self):
            route = urlsplit(self.path).path
            query = parse_qs(urlsplit(self.path).query)
            state["calls"].append((route, query))
            assert self.headers["Authorization"] == "Bearer synthetic-descriptor-token-0123456789"
            assert self.headers["X-Operator"] == "owner-reader"
            assert query["source"] == ["finance"] and query["scope"] == ["test-chat"]
            assert query["workspace"] == ["oa-workspace"]
            if route == "/authority":
                value = dict(grant, revision=state["revision"])
            elif route == "/descriptor":
                value = deepcopy(state["descriptor"])
            elif route == "/source-binding":
                value = {k: grant[k] for k in ("source", "scope", "principal", "workspace", "revision")}
                value.update(corp_id="corp-real", origin="owner_source_binding")
                value.update(state.get("binding_override", {}))
            else:
                self.send_error(404)
                return
            raw = json.dumps(value).encode()
            self.send_response(200)
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            if route != "/authority" and state["rotate"]:
                state["revision"] = "grant-2"
            self.wfile.write(raw)

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    source = HttpSource(f"http://127.0.0.1:{server.server_port}", source="finance", scope="test-chat",
                        workspace="oa-workspace", principal="owner-reader",
                        token="synthetic-descriptor-token-0123456789")
    yield source, event, state
    server.shutdown()
    server.server_close()
    thread.join()


@pytest.mark.parametrize("history", [False, True])
def test_descriptor_preserves_owner_fields_without_reading_original(owner, history):
    source, event, state = owner
    assert source.read_descriptor(event, include_history=history) == state["descriptor"]
    assert state["calls"][1][1]["include_history"] == [str(history).lower()]
    assert [r for r, _ in state["calls"]] == ["/authority", "/descriptor", "/authority"]


@pytest.mark.parametrize("replacement", [
    {"version": "wr-fake"}, {"reference": "other:reference"}, {"projection_hash": "bad"},
    {"original_available": 1}, {"kind": "unknown"}, {"kind": []},
    {"content": "PRIVATE-MUST-NOT-ESCAPE"},
])
def test_descriptor_rejects_invalid_or_nonmetadata_owner_response(owner, replacement):
    source, event, state = owner
    state["descriptor"].update(replacement)
    with pytest.raises(SourceUnavailable, match="^source_unavailable$"):
        source.read_descriptor(event, include_history=True)


def test_source_binding_is_owner_corp_and_preserves_grant_body(owner):
    source, _, _ = owner
    assert source.read_source_binding() == dict(source="finance", scope="test-chat", principal="owner-reader",
        workspace="oa-workspace", revision="grant-1", corp_id="corp-real", origin="owner_source_binding")


@pytest.mark.parametrize("method", ["descriptor", "binding"])
def test_metadata_read_rejects_grant_rotation(owner, method):
    source, event, state = owner
    state["rotate"] = True
    with pytest.raises(SourceUnavailable):
        source.read_descriptor(event) if method == "descriptor" else source.read_source_binding()


def test_descriptor_rejects_cross_scope_and_non_boolean_mode_before_io(owner):
    source, event, state = owner
    for value in (dict(event, scope="other-chat"), dict(event, source="other-source")):
        with pytest.raises(SourceUnavailable):
            source.read_descriptor(value)
    with pytest.raises(SourceUnavailable):
        source.read_descriptor(event, include_history="true")
    assert state["calls"] == []


@pytest.mark.parametrize("replacement", [{"workspace": "langbot-workspace"}, {"principal": "other-reader"},
    {"revision": "other"}, {"origin": "request_config"}, {"corp_id": ""}, {"secret": "PRIVATE"}])
def test_binding_rejects_wrong_audience_or_untrusted_owner_fields(owner, replacement):
    source, _, state = owner
    state["binding_override"] = replacement
    with pytest.raises(SourceUnavailable):
        source.read_source_binding()
