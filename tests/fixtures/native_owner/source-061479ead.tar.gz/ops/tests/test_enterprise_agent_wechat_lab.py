"""Personal WeChat source stays distinct from Finance archive and business authority."""

from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def test_personal_text_projection_retains_native_identity_without_claiming_employee():
    from enterprise_agent.wechat_projection import SavedWechat

    candidate = {
        "source": "wechat-lab",
        "scope": "approved-test-group",
        "change": {
            "record": "a" * 64,
            "version": "b" * 64,
            "sequence": 427,
            "business_at": "2026-11-04T14:00:00Z",
            "observed_at": "2026-11-04T14:00:01Z",
            "original": "wechat:message/" + "a" * 64 + "/" + "b" * 64,
            "saved": {
                "account_id": "lab-test",
                "thread_id": "approved-test@chatroom",
                "message_id": "msg_native_17",
                "sender_id": "wxid_test",
                "server_id": "remote-17",
                "message_type": "text",
                "direction": "incoming",
                "body_available": True,
            },
        },
    }
    selection = dict(
        goal="research:lab", confirmed=True, intent="action", candidates=[]
    )
    event = SavedWechat().project(candidate, selection)
    assert event["source"] == "wechat-lab"
    assert event["evidence_details"]["account_id"] == "lab-test"
    assert event["evidence_details"]["message_id"] == "msg_native_17"
    assert "sender_identity_type" not in event["evidence_details"]
    assert "body" not in event
    assert event["confirmed"] is True
    candidate["change"]["saved"]["direction"] = "outgoing"
    with pytest.raises(ValueError, match="invalid_saved_wechat"):
        SavedWechat().project(candidate, selection)


def test_source_journal_filters_account_group_and_outgoing_and_survives_restart(
    tmp_path,
):
    import json
    from enterprise_agent.wechat_source import WechatJournal

    journal = WechatJournal(
        tmp_path / "source.sqlite",
        account="lab-test",
        thread="test@chatroom",
        start_cursor=10,
    )
    events = tmp_path / "events.jsonl"
    rows = [
        dict(accountId="other", cursor="11", kind="message.committed", data={}),
        dict(
            accountId="lab-test",
            cursor="12",
            kind="message.committed",
            data=dict(
                threadId="other@chatroom", direction="incoming", messageId="private"
            ),
        ),
        dict(
            accountId="lab-test",
            cursor="13",
            kind="message.committed",
            data=dict(threadId="test@chatroom", direction="outgoing", messageId="sent"),
        ),
        dict(
            accountId="lab-test",
            cursor="14",
            kind="message.committed",
            createdAt="2026-11-04T14:00:01Z",
            data=dict(
                threadId="test@chatroom", direction="incoming", messageId="native17"
            ),
        ),
    ]
    events.write_text("".join(json.dumps(row) + "\n" for row in rows))
    requested = []

    def read_message(thread, message):
        requested.append((thread, message))
        return dict(
            accountId="lab-test",
            threadId=thread,
            id=message,
            direction="incoming",
            createdAt="2026-11-04T14:00:00Z",
            senderId="wxid_test",
            serverId="17",
            type=1,
            body="AW-LAB-ROUTER-001 分析此测试文本",
        )

    journal.collect(events, read_message)
    page = journal.page(None, source="wechat-lab", scope="test-group", limit=100)
    assert requested == [("test@chatroom", "native17")]
    assert len(page["items"]) == 1
    assert "AW-LAB" not in json.dumps(page)
    item = page["items"][0]
    assert (
        journal.original(item["original"])["content"]
        == "AW-LAB-ROUTER-001 分析此测试文本"
    )
    journal.close()
    journal = WechatJournal(
        tmp_path / "source.sqlite",
        account="lab-test",
        thread="test@chatroom",
        start_cursor=10,
    )
    journal.collect(events, read_message)
    assert (
        len(
            journal.page(None, source="wechat-lab", scope="test-group", limit=100)[
                "items"
            ]
        )
        == 1
    )
    assert (
        journal.page(
            page["next_cursor"], source="wechat-lab", scope="test-group", limit=100
        )["items"]
        == []
    )
    assert len(requested) == 1
    journal.close()


@pytest.mark.parametrize("mixed", [False, True])
def test_host_accepts_personal_source_without_borrowing_business_ownership(
    tmp_path, monkeypatch, mixed
):
    import json
    import os
    from enterprise_agent.run_host import open_host

    config = json.loads(
        (Path(__file__).parents[1] / "enterprise_agent/host.example.json").read_text()
    )
    tmp_path.chmod(0o700)
    connector = tmp_path / "connector.json"
    connector.write_text(
        json.dumps(
            dict(
                workspace=config["workspace"],
                endpoint=config["workspace_endpoint"],
                model=config["model_version"],
            )
        )
    )
    connector.chmod(0o600)
    config.update(
        enabled=True,
        owner_uid=os.getuid(),
        state=str(tmp_path / "workflow.sqlite"),
        connector_config=str(connector),
        gd=None,
    )
    config["sources"][0].update(
        kind="personal-wechat", source="wechat-lab", goal_assignee_ids=[]
    )
    monkeypatch.setenv("EA_WORKSPACE_TOKEN", "fixture-workspace-credential-012345")
    monkeypatch.setenv("EA_SOURCE_READ_TOKEN", "fixture-source-credential-012345")
    monkeypatch.delenv("EA_GD_READ_TOKEN", raising=False)
    if mixed:
        config["gd"] = dict(endpoint="https://mcp.example.invalid/mcp", token_env="EA_GD_READ_TOKEN")
        monkeypatch.setenv("EA_GD_READ_TOKEN", "fixture-goal-credential-0123456789abcdef")
        config["sources"].append(dict(config["sources"][0], kind="wecom", source="wecom-approved",
            goal_assignee_ids=["approved-owner"]))
    host, _ = open_host(config)
    try:
        assert (
            host.producer.projectors["wechat-lab"].version == "personal-wechat-text-v1"
        )
        assert host.admission(dict(source="wechat-lab", scope=config["sources"][0]["scope"])) is None
        with pytest.raises(ValueError, match="source_unavailable"):
            host.admission(dict(source="unknown", scope="unknown"))
    finally:
        host.close()
        host.workflow.close()
    config["sources"][0]["kind"] = "wecom"
    config["state"] = str(tmp_path / "invalid-workflow.sqlite")
    with pytest.raises(ValueError, match="invalid_goal_configuration|goal_ownership_binding_required"):
        open_host(config)


@pytest.mark.parametrize("policy", ["missing", "wecom-borrows-personal", "scoped"])
def test_mixed_host_requires_source_bound_goal_catalog(tmp_path, monkeypatch, policy):
    import json
    import os
    from enterprise_agent.run_host import open_host
    config = json.loads((Path(__file__).parents[1] / "enterprise_agent/host.example.json").read_text())
    tmp_path.chmod(0o700)
    connector, reader, key = (tmp_path / name for name in ("connector.json", "reader.json", "key"))
    key.write_bytes(b"fixture-private-input-key-at-least-32-bytes")
    personal = dict(config["sources"][0], kind="personal-wechat", source="wechat-lab", goal_assignee_ids=[])
    enterprise = dict(config["sources"][0], kind="wecom", source="wecom-approved")
    config.update(enabled=True, owner_uid=os.getuid(), state=str(tmp_path / "state.sqlite"),
        connector_config=str(connector), sources=[personal, enterprise],
        understanding=dict(enabled=True, reader_config=str(reader), reviewers=[]))
    goals = [dict(id="research:wechat", kind="research", status="OPEN", clues={}, reporters=[]),
        dict(id="gd:42", kind="research", status="OPEN", clues={}, reporters=[], gd_code="GD-TEST-42")]
    input_config = dict(version=1, owner_uid=os.getuid(), state=config["state"], input_key_file=str(key),
        sources=[{**{k: item[k] for k in ("source", "scope", "principal", "endpoint")},
                  "workspace": config["workspace"], "token_file": str(tmp_path / "unused-token")}
                 for item in config["sources"]], goals=goals)
    if policy != "missing":
        input_config["goal_scopes"] = [
            dict(source=personal["source"], scope=personal["scope"], goal_ids=["research:wechat"], require_gd=False),
            dict(source=enterprise["source"], scope=enterprise["scope"],
                 goal_ids=["gd:42"] if policy == "scoped" else ["research:wechat"], require_gd=policy == "scoped")]
    reader.write_text(json.dumps(input_config))
    connector.write_text(json.dumps(dict(workspace=config["workspace"], endpoint=config["workspace_endpoint"],
        model=config["model_version"], originalReader=dict(
            executable=str(Path(__file__).parents[1].resolve() / "enterprise_agent/input_reader.py"), config=str(reader)))))
    for path in (connector, reader, key):
        path.chmod(0o600)
    for variable in ("EA_WORKSPACE_TOKEN", "EA_SOURCE_READ_TOKEN", "EA_GD_READ_TOKEN"):
        monkeypatch.setenv(variable, "fixture-only-token-0123456789abcdef")
    if policy != "scoped":
        with pytest.raises(ValueError, match="invalid_source_goal_catalog"):
            open_host(config)
    else:
        host, _ = open_host(config)
        try:
            assert host.understanding is not None
        finally:
            host.close()
            host.workflow.close()


@pytest.mark.parametrize("section,field,value", [
    ("source", "endpoint", "ftp://source.example.invalid"),
    ("source", "token_env", "not a valid variable"),
    ("source", "source", "source with spaces"),
    ("source", "scope", "scope with spaces"),
    ("source", "principal", "principal with spaces"),
    ("gd", "endpoint", "not-a-url"),
    ("gd", "token_env", "not a valid variable"),
])
def test_static_admission_rejects_invalid_adapter_configuration_without_io(section, field, value, monkeypatch):
    import json
    from enterprise_agent.run_host import validate_source_admission
    import enterprise_agent.source_http as transport
    config = json.loads((Path(__file__).parents[1] / "enterprise_agent/host.example.json").read_text())
    target = config["sources"][0] if section == "source" else config["gd"]
    target[field] = value

    def forbidden(*args, **kwargs):
        raise AssertionError("static qualification performed network I/O")

    monkeypatch.setattr(transport, "open_http", forbidden)
    with pytest.raises(ValueError):
        validate_source_admission(config)


@pytest.mark.parametrize("mutation", ["missing", "relative", "empty", "nonstring", "extra"])
def test_static_admission_rejects_invalid_reader_token_binding(mutation):
    import json
    from enterprise_agent.run_host import validate_source_admission
    config = json.loads((Path(__file__).parents[1] / "enterprise_agent/host.example.json").read_text())
    item = config["sources"][0]
    binding = {**{key: item[key] for key in ("source", "scope", "principal", "endpoint")},
               "workspace": config["workspace"], "token_file": "/private/fixture.token"}
    if mutation == "missing":
        binding.pop("token_file")
    elif mutation == "extra":
        binding["model_url"] = "https://unexpected.example.invalid"
    else:
        binding["token_file"] = {"relative": "relative.token", "empty": "", "nonstring": None}[mutation]
    with pytest.raises(ValueError, match="private_input_configuration_required"):
        validate_source_admission(config, dict(sources=[binding], goals=[]))


def test_source_http_rechecks_scope_agent_and_revocation(tmp_path):
    import json
    from queue import Queue
    import socket
    from threading import Event, Thread
    from enterprise_agent.wechat_source import WechatJournal, source_server
    from enterprise_agent.source_http import HttpSource, SourceUnavailable

    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    token = tmp_path / "token"
    token.write_text("test-read-credential-" + "x" * 32)
    token.chmod(0o600)
    config = dict(
        version=1,
        enabled=True,
        account="lab-test",
        thread="approved@chatroom",
        start_cursor=10,
        events=str(tmp_path / "events"),
        wx="/fixed/wx-lab",
        database=str(tmp_path / "journal.sqlite"),
        listen_port=port,
        source="wechat-lab",
        scope="test-group",
        workspace="test-workspace",
        principal="test-reader",
        agents=["router-lab", "analysis-lab"],
        read_token_file=str(token),
    )
    file = tmp_path / "config.json"
    file.write_text(json.dumps(config))
    file.chmod(0o600)
    ready, stopped = Queue(), Event()

    def serve():
        journal = WechatJournal(
            config["database"],
            account="lab-test",
            thread=config["thread"],
            start_cursor=10,
        )
        server = source_server(str(file), journal)
        server.timeout = 0.1
        ready.put(True)
        try:
            while not stopped.is_set():
                server.handle_request()
        finally:
            server.server_close()
            journal.close()

    thread = Thread(target=serve, daemon=True)
    thread.start()
    ready.get(timeout=5)
    source = HttpSource(
        "http://127.0.0.1:" + str(port),
        source="wechat-lab",
        scope="test-group",
        workspace="test-workspace",
        principal="test-reader",
        token=token.read_text(),
    )
    try:
        assert source.read_changes()["next_cursor"] == "10"
        assert (
            source.authorize("wechat-lab", "dispatch", "router-lab")["agent"]
            == "router-lab"
        )
        with pytest.raises(SourceUnavailable):
            source.authorize("wechat-lab", "dispatch", "unapproved-agent")
        config["enabled"] = False
        file.write_text(json.dumps(config))
        with pytest.raises(SourceUnavailable):
            source.authorize("wechat-lab", "result", "router-lab")
    finally:
        stopped.set()
        thread.join(timeout=5)


def test_result_reply_reuses_original_send_key_after_unknown_and_restart(tmp_path):
    from enterprise_agent.wechat_reply import WechatReplies

    matter = dict(
        id="matter-17",
        revision="revision-1",
        status="read_only_result",
        event=dict(
            source="wechat-lab",
            scope="test-group",
            goal="research:lab",
            evidence_details=dict(account_id="lab-test", thread_id="test@chatroom"),
        ),
        result=dict(
            content="企微只通知内部人员，由人工接管。",
            event_id="native-result-17",
            agent="analysis-lab",
        ),
    )
    options = dict(
        account="lab-test",
        thread="test@chatroom",
        source="wechat-lab",
        scope="test-group",
        goal="research:lab",
        assistant="analysis-lab",
    )
    replies = WechatReplies(tmp_path / "replies.sqlite", **options)
    calls = []

    def send(thread, text, key):
        calls.append((thread, text, key))
        raise TimeoutError()

    def lookup(key):
        assert key == calls[0][2]
        return dict(
            accountId="lab-test",
            destination="test@chatroom",
            id="send-17",
            state="accepted",
            serverId="remote-17",
        )

    assert replies.deliver(matter, send, qualify=lambda: True)["status"] == "unknown"
    replies.close()
    replies = WechatReplies(tmp_path / "replies.sqlite", **options)
    assert replies.deliver(matter, send, qualify=lambda: True)["status"] == "unknown"
    receipt = replies.deliver(matter, send, qualify=lambda: True, lookup=lookup)
    assert receipt["status"] == "accepted"
    assert replies.deliver(matter, send, qualify=lambda: True) == receipt
    assert len(calls) == 1
    matter["event"]["evidence_details"]["thread_id"] = "unapproved@chatroom"
    with pytest.raises(ValueError, match="unapproved_reply"):
        replies.deliver(matter, send, qualify=lambda: True)
    assert len(calls) == 1
    replies.close()


def test_reply_rechecks_authority_and_current_result_before_calling_send(tmp_path):
    from enterprise_agent.wechat_reply import WechatReplies

    matter = dict(
        id="matter-17",
        revision="revision-1",
        status="read_only_result",
        event=dict(
            source="wechat-lab",
            scope="test-group",
            goal="research:lab",
            evidence_details=dict(account_id="lab-test", thread_id="test@chatroom"),
        ),
        result=dict(content="测试结论", event_id="native-result", agent="analysis-lab"),
    )
    replies = WechatReplies(
        tmp_path / "replies.sqlite",
        account="lab-test",
        thread="test@chatroom",
        source="wechat-lab",
        scope="test-group",
        goal="research:lab",
        assistant="analysis-lab",
    )
    calls = []
    receipt = replies.deliver(
        matter, lambda *args: calls.append(args), qualify=lambda: False
    )
    assert receipt["status"] == "held"
    assert calls == []
    replies.close()
